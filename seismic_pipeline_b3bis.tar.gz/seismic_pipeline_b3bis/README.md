# seismic_pipeline_b3bis — Configuration régionale

**Phase B3-bis** du projet Meteorite Scout AI.

Système de configuration régionale qui permet au pipeline sismique de basculer
entre pays (Italie, Maroc, USA, ...) en ne modifiant qu'un fichier YAML —
**aucune ligne de code Python à toucher**.

---

## Installation

```bash
pip install -r requirements.txt
```

Dépendances :
- `pydantic >= 2.5`
- `pyyaml >= 6.0`
- `pytest >= 7.4` (tests uniquement)

---

## Usage rapide

```python
from config import load_region_config

# Charger une région
cfg = load_region_config("italy")

# Accéder aux paramètres
print(cfg.region.name)                       # 'italy'
print(cfg.preprocessing.bandpass_low_hz)     # 2.0
print(cfg.detection.trigger_threshold)       # 3.5

# Itérer sur les data centers par priorité
for dc in cfg.get_data_centers_by_priority():
    print(f"{dc.name}: {dc.url}")
```

---

## Régions livrées

| Région | Statut accès | Cas de test |
|---|---|---|
| `italy` | ✅ 100% ouvert (INGV) | Cavezzo, Olivieri 2023 |
| `morocco` | 🟡 Mode dégradé (WM/MO bloqués) | Tiflet, Tamdakht, Tissint |
| `usa` | ✅ 100% ouvert (IRIS) | Sutter's Mill, Hamburg |

---

## Tests

```bash
# Tests unitaires complets (22 tests)
python -m pytest tests/ -v

# Smoke tests (8 tests, sans pytest)
python tests/test_smoke_b3bis.py

# Validation FDSN sur cible (à exécuter sur VPS Hostinger)
python validate_fdsn_access.py --region italy
python validate_fdsn_access.py --region morocco
python validate_fdsn_access.py --region usa
```

---

## Ajouter une région

1. Créer `config/regions/<nom>.yaml` (s'inspirer d'`italy.yaml`)
2. Vérifier : `python -c "from config import load_region_config; load_region_config('<nom>')"`
3. **Aucune modification de code Python.**

---

## Documentation

- `docs/PHASE_B3bis_RAPPORT.md` — rapport complet, justifications, validation
- `docs/MIGRATION_GUIDE.md` — intégration dans `seismic_pipeline` v7 → v8
