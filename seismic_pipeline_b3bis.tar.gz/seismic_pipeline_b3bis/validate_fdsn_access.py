"""validate_fdsn_access.py — Validation accès FDSN pour une région donnée.

À lancer sur le VPS Hostinger (ou tout environnement avec accès Internet
sortant). Vérifie que les data centers déclarés répondent et que les
stations attendues existent.

Usage :
    python validate_fdsn_access.py --region italy
    python validate_fdsn_access.py --region morocco
    python validate_fdsn_access.py --region usa

Sortie :
    - Statut HTTP de chaque data center
    - Nombre de stations trouvées par réseau dans une bbox de test
    - Verdict global PASS/FAIL

Note : nécessite uniquement urllib (stdlib), pas d'ObsPy. Ce script est
un "ping" léger des endpoints FDSN, pas une acquisition complète.
"""
from __future__ import annotations

import argparse
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import AuthType, load_region_config  # noqa: E402

# Bounding boxes de test par région.
# Pour Maroc : volontairement large car les stations utilisées en mode
# dégradé sont distantes (Espagne centrale, Tamanrasset Algérie, Tenerife).
TEST_BBOX = {
    "italy":   {"minlat": 40.0, "maxlat": 46.0, "minlon": 7.0, "maxlon": 14.0},
    "morocco": {"minlat": 20.0, "maxlat": 42.0, "minlon": -20.0, "maxlon": 10.0},
    "usa":     {"minlat": 32.0, "maxlat": 42.0, "minlon": -125.0, "maxlon": -115.0},
}


def query_station_count(
    base_url: str, network: str, bbox: dict, timeout: int = 30
) -> tuple[bool, str, int]:
    """Interroge l'endpoint /station/1/query pour compter les stations.

    Returns:
        (success, message, station_count)
    """
    params = {
        "network": network,
        "level": "station",
        "format": "text",
        "minlatitude": bbox["minlat"],
        "maxlatitude": bbox["maxlat"],
        "minlongitude": bbox["minlon"],
        "maxlongitude": bbox["maxlon"],
    }
    url = f"{base_url}/fdsnws/station/1/query?{urllib.parse.urlencode(params)}"

    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            status = resp.status
            body = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        if exc.code == 204:
            return True, "204 No Content (réseau OK, 0 station dans bbox)", 0
        return False, f"HTTP {exc.code} : {exc.reason}", 0
    except urllib.error.URLError as exc:
        return False, f"Erreur réseau : {exc.reason}", 0
    except Exception as exc:  # noqa: BLE001
        return False, f"{type(exc).__name__} : {exc}", 0

    # FDSN : 204 No Content = requête valide mais aucune station dans bbox.
    # Certains serveurs renvoient 204 via HTTPError (cf. except ci-dessus),
    # d'autres via une réponse normale avec body vide.
    if status == 204:
        return True, "204 No Content (réseau OK, 0 station dans bbox)", 0

    if status != 200:
        return False, f"Status HTTP inattendu : {status}", 0

    # Comptage des lignes non-commentaires (format=text de FDSN).
    # Si le body est vide alors que status=200, c'est aussi un succès "0 station".
    lines = [ln for ln in body.splitlines() if ln and not ln.startswith("#")]
    if not lines:
        return True, f"OK ({status}, body vide = 0 station dans bbox)", 0
    return True, f"OK ({status})", len(lines)


def validate_region(region_name: str) -> int:
    """Valide l'accès FDSN pour une région donnée.

    Returns:
        Code de sortie : 0 si tout OK, 1 sinon.
    """
    print("=" * 70)
    print(f"VALIDATION FDSN — Région : {region_name.upper()}")
    print("=" * 70)

    cfg = load_region_config(region_name)
    bbox = TEST_BBOX.get(region_name)
    if bbox is None:
        print(f"[KO] Pas de bbox de test définie pour '{region_name}'")
        return 1

    print(f"\nBbox de test : lat=[{bbox['minlat']},{bbox['maxlat']}] "
          f"lon=[{bbox['minlon']},{bbox['maxlon']}]\n")

    failures = 0
    skipped = 0

    # 1. Test des data centers (priorité ascendante)
    print("--- Data centers ---")
    for dc in cfg.get_data_centers_by_priority():
        if dc.auth.type != AuthType.NONE:
            print(
                f"  [SKIP] {dc.name:15s} ({dc.url}) — auth={dc.auth.type.value} "
                f"(non testable sans credentials)"
            )
            skipped += 1
            continue
        # Ping minimal : on demande la station list sans réseau spécifique
        success, msg, _ = query_station_count(
            dc.url,
            network="*",
            bbox=bbox,
            timeout=dc.timeout_seconds,
        )
        status = "[OK]" if success else "[KO]"
        print(f"  {status} {dc.name:15s} {msg}")
        if not success:
            failures += 1

    # 2. Test des réseaux ouverts (sans auth)
    print("\n--- Réseaux ouverts ---")
    for net in cfg.networks:
        dc = cfg.get_data_center(net.data_center)
        if dc.auth.type != AuthType.NONE:
            print(
                f"  [SKIP] {net.code:4s} via {dc.name:10s} — auth requise "
                f"({dc.auth.type.value})"
            )
            skipped += 1
            continue
        success, msg, count = query_station_count(
            dc.url, net.code, bbox, timeout=dc.timeout_seconds
        )
        status = "[OK]" if success else "[KO]"
        print(f"  {status} {net.code:4s} via {dc.name:10s} → {count:4d} stations  {msg}")
        if not success:
            failures += 1

    # 3. Verdict
    print("\n" + "=" * 70)
    if failures == 0:
        print(f"[OK] Validation FDSN PASSÉE (skipped={skipped} pour auth)")
        return 0
    print(f"[KO] {failures} échec(s) — voir détails ci-dessus")
    return 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--region",
        required=True,
        choices=["italy", "morocco", "usa"],
        help="Nom de la région à valider",
    )
    args = parser.parse_args()
    return validate_region(args.region)


if __name__ == "__main__":
    sys.exit(main())
