"""test_config_loader.py — Tests unitaires du système de config régionale.

Couvre :
- Chargement des 3 régions livrées (italy, morocco, usa)
- Validation Pydantic (champs requis, types, contraintes)
- Détection des erreurs (YAML mal formé, références incohérentes)
- Mécanisme d'overrides
- Méthodes utilitaires (get_data_center, tri par priorité)

Lancement :
    pytest tests/test_config_loader.py -v
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from config import (
    ConfigValidationError,
    NetworkDensity,
    RegionNotFoundError,
    YamlParseError,
    list_available_regions,
    load_region_config,
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def package_config_dir() -> Path:
    """Répertoire des configs livrées avec le package."""
    return Path(__file__).parent.parent / "config" / "regions"


@pytest.fixture
def tmp_config_dir(tmp_path: Path) -> Path:
    """Répertoire temporaire pour configs de test."""
    cfg_dir = tmp_path / "regions"
    cfg_dir.mkdir()
    return cfg_dir


@pytest.fixture
def minimal_valid_yaml() -> str:
    """YAML minimal valide pour tester le loader."""
    return textwrap.dedent("""
        schema_version: "1.0"
        region:
          name: testland
          iso_code: TL
          timezone: UTC
        data_centers:
          - name: test_dc
            url: https://example.org
            auth:
              type: none
            priority: 1
        networks:
          - code: XX
            operator: Test Operator
            data_center: test_dc
            max_radius_km: 500
            expected_density: medium
    """).strip()


# =============================================================================
# Tests des configs livrées
# =============================================================================

class TestProductionConfigs:
    """Vérifie que les 3 configs livrées sont valides et cohérentes."""

    def test_italy_loads(self, package_config_dir: Path) -> None:
        cfg = load_region_config("italy", config_dir=package_config_dir)
        assert cfg.region.name == "italy"
        assert cfg.region.iso_code == "IT"

    def test_italy_has_ingv(self, package_config_dir: Path) -> None:
        cfg = load_region_config("italy", config_dir=package_config_dir)
        ingv = cfg.get_data_center("ingv")
        assert "ingv.it" in ingv.url
        assert ingv.auth.type.value == "none"

    def test_italy_iv_network_dense(self, package_config_dir: Path) -> None:
        """Le réseau IV (INGV) doit être marqué dense."""
        cfg = load_region_config("italy", config_dir=package_config_dir)
        iv = next(n for n in cfg.networks if n.code == "IV")
        assert iv.expected_density == NetworkDensity.DENSE
        assert iv.max_radius_km <= 800

    def test_morocco_loads(self, package_config_dir: Path) -> None:
        cfg = load_region_config("morocco", config_dir=package_config_dir)
        assert cfg.region.name == "morocco"
        assert cfg.region.iso_code == "MA"

    def test_morocco_excludes_wm_ave(self, package_config_dir: Path) -> None:
        """WM.AVE doit être exclue (station fermée 2011)."""
        cfg = load_region_config("morocco", config_dir=package_config_dir)
        wm = next(n for n in cfg.networks if n.code == "WM")
        assert "AVE" in wm.excluded_stations

    def test_morocco_geofon_requires_edugain(self, package_config_dir: Path) -> None:
        """GEOFON doit être configuré pour eduGAIN cappuccino (blocage actuel)."""
        cfg = load_region_config("morocco", config_dir=package_config_dir)
        geofon = cfg.get_data_center("geofon")
        assert geofon.auth.type.value == "edugain_cappuccino"
        assert geofon.auth.idp_url is not None

    def test_usa_loads(self, package_config_dir: Path) -> None:
        cfg = load_region_config("usa", config_dir=package_config_dir)
        assert cfg.region.name == "usa"
        assert len(cfg.networks) >= 3  # CI, BK, NN au minimum

    def test_all_regions_listed(self, package_config_dir: Path) -> None:
        regions = list_available_regions(config_dir=package_config_dir)
        assert "italy" in regions
        assert "morocco" in regions
        assert "usa" in regions


# =============================================================================
# Tests des erreurs
# =============================================================================

class TestErrorHandling:
    def test_unknown_region_raises(self, package_config_dir: Path) -> None:
        with pytest.raises(RegionNotFoundError) as exc_info:
            load_region_config("atlantis", config_dir=package_config_dir)
        # Le message doit indiquer les régions disponibles
        assert "atlantis" in str(exc_info.value).lower() or "introuvable" in str(exc_info.value).lower()

    def test_malformed_yaml(self, tmp_config_dir: Path) -> None:
        bad_yaml = tmp_config_dir / "bad.yaml"
        bad_yaml.write_text("not: valid: yaml: [unclosed", encoding="utf-8")
        with pytest.raises(YamlParseError):
            load_region_config("bad", config_dir=tmp_config_dir)

    def test_yaml_root_not_dict(self, tmp_config_dir: Path) -> None:
        list_yaml = tmp_config_dir / "listroot.yaml"
        list_yaml.write_text("- just\n- a\n- list\n", encoding="utf-8")
        with pytest.raises(YamlParseError):
            load_region_config("listroot", config_dir=tmp_config_dir)

    def test_missing_required_fields(
        self, tmp_config_dir: Path
    ) -> None:
        incomplete = tmp_config_dir / "incomplete.yaml"
        incomplete.write_text(
            'schema_version: "1.0"\nregion:\n  name: x\n', encoding="utf-8"
        )
        with pytest.raises(ConfigValidationError):
            load_region_config("incomplete", config_dir=tmp_config_dir)

    def test_network_references_unknown_data_center(
        self, tmp_config_dir: Path, minimal_valid_yaml: str
    ) -> None:
        # On modifie le réseau pour pointer vers un DC inexistant
        bad = minimal_valid_yaml.replace(
            "data_center: test_dc", "data_center: ghost_dc"
        )
        (tmp_config_dir / "broken.yaml").write_text(bad, encoding="utf-8")
        with pytest.raises(ConfigValidationError) as exc_info:
            load_region_config("broken", config_dir=tmp_config_dir)
        assert "ghost_dc" in str(exc_info.value)

    def test_invalid_url_rejected(
        self, tmp_config_dir: Path, minimal_valid_yaml: str
    ) -> None:
        bad = minimal_valid_yaml.replace(
            "url: https://example.org", "url: ftp://example.org"
        )
        (tmp_config_dir / "ftpbad.yaml").write_text(bad, encoding="utf-8")
        with pytest.raises(ConfigValidationError):
            load_region_config("ftpbad", config_dir=tmp_config_dir)

    def test_lta_must_exceed_sta(
        self, tmp_config_dir: Path, minimal_valid_yaml: str
    ) -> None:
        bad = minimal_valid_yaml + "\ndetection:\n  sta_window_s: 30.0\n  lta_window_s: 1.0\n"
        (tmp_config_dir / "stabad.yaml").write_text(bad, encoding="utf-8")
        with pytest.raises(ConfigValidationError) as exc_info:
            load_region_config("stabad", config_dir=tmp_config_dir)
        assert "LTA" in str(exc_info.value) or "lta" in str(exc_info.value)

    def test_bandpass_high_must_exceed_low(
        self, tmp_config_dir: Path, minimal_valid_yaml: str
    ) -> None:
        bad = (
            minimal_valid_yaml
            + "\npreprocessing:\n  bandpass_low_hz: 10.0\n  bandpass_high_hz: 2.0\n"
        )
        (tmp_config_dir / "bpbad.yaml").write_text(bad, encoding="utf-8")
        with pytest.raises(ConfigValidationError):
            load_region_config("bpbad", config_dir=tmp_config_dir)


# =============================================================================
# Tests des overrides
# =============================================================================

class TestOverrides:
    def test_override_simple_field(self, package_config_dir: Path) -> None:
        cfg = load_region_config(
            "italy",
            config_dir=package_config_dir,
            overrides={"detection": {"trigger_threshold": 5.0}},
        )
        assert cfg.detection.trigger_threshold == 5.0

    def test_override_preserves_other_fields(
        self, package_config_dir: Path
    ) -> None:
        """Override partiel ne doit pas effacer les champs non touchés."""
        cfg = load_region_config(
            "italy",
            config_dir=package_config_dir,
            overrides={"detection": {"trigger_threshold": 5.0}},
        )
        # sta_window_s n'a pas été surchargé → valeur originale préservée
        assert cfg.detection.sta_window_s == 1.0

    def test_override_rejects_invalid_value(
        self, package_config_dir: Path
    ) -> None:
        with pytest.raises(ConfigValidationError):
            load_region_config(
                "italy",
                config_dir=package_config_dir,
                overrides={"detection": {"trigger_threshold": -1.0}},
            )


# =============================================================================
# Tests des méthodes utilitaires
# =============================================================================

class TestUtilityMethods:
    def test_get_networks_by_priority(self, package_config_dir: Path) -> None:
        """Les réseaux denses doivent être en tête."""
        cfg = load_region_config("italy", config_dir=package_config_dir)
        ordered = cfg.get_networks_by_priority()
        # IV (dense) doit venir avant MN (sparse)
        codes = [n.code for n in ordered]
        assert codes.index("IV") < codes.index("MN")

    def test_get_data_centers_by_priority(self, package_config_dir: Path) -> None:
        cfg = load_region_config("morocco", config_dir=package_config_dir)
        ordered = cfg.get_data_centers_by_priority()
        priorities = [dc.priority for dc in ordered]
        assert priorities == sorted(priorities)

    def test_get_data_center_unknown_raises(
        self, package_config_dir: Path
    ) -> None:
        cfg = load_region_config("italy", config_dir=package_config_dir)
        with pytest.raises(KeyError):
            cfg.get_data_center("nonexistent")
