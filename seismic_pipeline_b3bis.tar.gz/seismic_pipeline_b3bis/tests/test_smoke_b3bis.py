"""test_smoke_b3bis.py — Smoke tests Phase B3-bis (style v7).

8 vérifications fondamentales, exécutables sans pytest :
    python tests/test_smoke_b3bis.py

Sortie attendue :
    [OK] Test 1/8 : ...
    ...
    [OK] Tous les smoke tests passés (8/8)
"""
from __future__ import annotations

import sys
from pathlib import Path

# Ajout du package au sys.path pour exécution standalone
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import (  # noqa: E402
    ConfigValidationError,
    NetworkDensity,
    RegionNotFoundError,
    list_available_regions,
    load_region_config,
)


def test_1_three_regions_available() -> None:
    regions = list_available_regions()
    assert set(regions) >= {"italy", "morocco", "usa"}, (
        f"Régions livrées incomplètes : {regions}"
    )


def test_2_italy_loads_and_dense() -> None:
    cfg = load_region_config("italy")
    assert cfg.region.iso_code == "IT"
    iv = next(n for n in cfg.networks if n.code == "IV")
    assert iv.expected_density == NetworkDensity.DENSE


def test_3_morocco_geofon_blocked() -> None:
    """La config Maroc doit refléter le blocage WM (eduGAIN requis)."""
    cfg = load_region_config("morocco")
    geofon = cfg.get_data_center("geofon")
    assert geofon.auth.type.value == "edugain_cappuccino"


def test_4_morocco_ave_excluded() -> None:
    cfg = load_region_config("morocco")
    wm = next(n for n in cfg.networks if n.code == "WM")
    assert "AVE" in wm.excluded_stations


def test_5_unknown_region_fails() -> None:
    try:
        load_region_config("atlantis")
    except RegionNotFoundError:
        return
    raise AssertionError("RegionNotFoundError attendue mais non levée")


def test_6_overrides_work() -> None:
    cfg = load_region_config(
        "italy", overrides={"detection": {"trigger_threshold": 7.0}}
    )
    assert cfg.detection.trigger_threshold == 7.0


def test_7_invalid_override_rejected() -> None:
    try:
        load_region_config(
            "italy", overrides={"detection": {"trigger_threshold": -1.0}}
        )
    except ConfigValidationError:
        return
    raise AssertionError("ConfigValidationError attendue mais non levée")


def test_8_network_priority_dense_first() -> None:
    cfg = load_region_config("italy")
    ordered = cfg.get_networks_by_priority()
    # IV (dense) avant MN (sparse)
    codes = [n.code for n in ordered]
    assert codes.index("IV") < codes.index("MN")


def main() -> int:
    tests = [
        ("Régions disponibles (italy/morocco/usa)", test_1_three_regions_available),
        ("Italie : INGV chargé, réseau IV dense", test_2_italy_loads_and_dense),
        ("Maroc : GEOFON marqué eduGAIN cappuccino", test_3_morocco_geofon_blocked),
        ("Maroc : WM.AVE exclue (fermée 2011)", test_4_morocco_ave_excluded),
        ("Région inconnue → RegionNotFoundError", test_5_unknown_region_fails),
        ("Overrides appliqués correctement", test_6_overrides_work),
        ("Override invalide → ConfigValidationError", test_7_invalid_override_rejected),
        ("Tri réseaux : dense avant sparse", test_8_network_priority_dense_first),
    ]
    failures = 0
    for i, (name, fn) in enumerate(tests, 1):
        try:
            fn()
            print(f"[OK] Test {i}/{len(tests)} : {name}")
        except Exception as exc:  # noqa: BLE001
            print(f"[KO] Test {i}/{len(tests)} : {name}")
            print(f"     → {type(exc).__name__}: {exc}")
            failures += 1

    print()
    if failures == 0:
        print(f"[OK] Tous les smoke tests passés ({len(tests)}/{len(tests)})")
        return 0
    print(f"[KO] {failures}/{len(tests)} test(s) échoué(s)")
    return 1


if __name__ == "__main__":
    sys.exit(main())
