# PHASE B3-bis — SYSTÈME DE CONFIGURATION RÉGIONALE

**Auteur** : Nabil Bakioui — ecologiciel@gmail.com
**Date** : 26 avril 2026
**Version** : 1.0
**Classification** : Interne projet
**Statut** : ✅ Livré et testé

---

## RÉSUMÉ EXÉCUTIF

Phase B3-bis répond à un objectif tactique précis : **prouver le concept Meteorite Scout AI sur les données ouvertes de l'INGV (Italie) avant le RDV CNRST**, et le faire de manière à ce que le pipeline existant (v7) puisse pivoter d'un pays à l'autre sans modification de code Python.

**Solution retenue** : externalisation de toute la logique régionale (data centers, authentification, codes réseaux, paramètres) dans des fichiers YAML versionnés, validés à l'exécution par un schéma Pydantic strict.

**Bénéfice direct** : ajouter un nouveau pays = créer un fichier YAML. **Aucune ligne Python à modifier.**

**Validation** :
- ✅ Schéma Pydantic 2.x avec 7 sous-modèles et 12 contraintes inter-champs
- ✅ Loader avec gestion d'erreurs explicite (4 exceptions typées)
- ✅ 3 configs régionales livrées : Italie, Maroc, USA
- ✅ 22 tests unitaires pytest (100% pass)
- ✅ 8 smoke tests (100% pass)
- ✅ Script de validation FDSN sur cible (`validate_fdsn_access.py`)

---

## 1. CONTEXTE ET OBJECTIFS

### 1.1 Décision stratégique

Suite à l'analyse comparative des pays alternatifs (conversation 26 avril 2026), l'**Italie** a été retenue comme banc de validation scientifique pour les raisons suivantes :

1. **Réseau INGV ~400 stations** densément réparties (espacement 30-50 km)
2. **Accès FDSN totalement ouvert** sur `webservices.ingv.it` (aucun token, aucune négociation)
3. **Référence Olivieri 2023** publiée précisément sur ces données → reproductibilité directe
4. **Cas de test multiples** disponibles dans le papier (Cavezzo, etc.)

Cette validation servira d'argument scientifique imparable lors du RDV avec M. Nacer Jabour, DG CNRST :
> *"Voici N cas italiens où mon pipeline retrouve à <5 km près les résultats publiés par l'INGV. Sur Tiflet, je ne peux pas le faire sans le réseau MO."*

### 1.2 Objectif technique

Permettre au pipeline `seismic_pipeline` v7 de fonctionner sur l'Italie sans
duplication de code, et de basculer dynamiquement vers le Maroc dès que
l'accès WM (eduGAIN UM5) ou MO (CNRST) sera obtenu.

### 1.3 Principe d'architecture appliqué

> *Data-driven configuration : la logique métier reste dans le code,
> les variables géographiques/politiques sont dans les fichiers.*

Le code Python du pipeline ne doit **jamais** contenir d'instruction
`if region == "italy"`. Il consomme un objet `RegionConfig` validé sans
savoir d'où il vient.

---

## 2. ARCHITECTURE LIVRÉE

### 2.1 Arborescence

```
seismic_pipeline_b3bis/
├── config/
│   ├── __init__.py            # API publique
│   ├── schema.py              # Modèles Pydantic (433 lignes)
│   ├── loader.py              # Chargement YAML + validation (180 lignes)
│   └── regions/
│       ├── italy.yaml         # ⭐ Cible Phase B3-bis
│       ├── morocco.yaml       # Référence (avec blocages documentés)
│       └── usa.yaml           # Démonstration généricité
├── tests/
│   ├── test_config_loader.py  # 22 tests pytest
│   └── test_smoke_b3bis.py    # 8 smoke tests style v7
├── validate_fdsn_access.py    # Validation FDSN sur cible
├── requirements.txt
└── docs/
    ├── PHASE_B3bis_RAPPORT.md     # Ce document
    └── MIGRATION_GUIDE.md          # Intégration dans v7 → v8
```

### 2.2 Schéma de configuration (modèles Pydantic)

| Modèle | Responsabilité |
|---|---|
| `RegionConfig` | Racine de la config — contient tout |
| `RegionMetadata` | Nom, ISO code, fuseau horaire |
| `DataCenterConfig` | URL FDSN + auth + priorité |
| `AuthConfig` | 5 types : `none`, `eida_token`, `edugain_cappuccino`, `bilateral_token`, `basic_auth` |
| `NetworkConfig` | Code FDSN, opérateur, rayon, densité, channels, exclusions |
| `DetectionConfig` | STA/LTA + critères Olivieri C1-C4 |
| `PreprocessingConfig` | Bandpass, resample, detrend, taper |
| `TriangulationConfig` | Mode (strict/normal/permissive), vélocités, portée max |
| `QualityControlConfig` | SNR min, gaps max, composantes requises |

### 2.3 Validations inter-champs (model_validator)

Le schéma refuse à l'exécution :
- Un réseau référençant un `data_center` non déclaré
- Des codes réseaux dupliqués (ex: deux fois `IV`)
- Des noms de data centers dupliqués
- `lta_window_s ≤ sta_window_s`
- `bandpass_high_hz ≤ bandpass_low_hz`
- `acoustic_velocity_max ≤ acoustic_velocity_min`
- `trigger_threshold ≤ detrigger_threshold`
- Auth `eida_token` ou `bilateral_token` sans `token_path`
- Auth `edugain_cappuccino` sans `idp_url` + `eppn`
- URL ne commençant pas par `http(s)://`

---

## 3. CONFIGURATIONS LIVRÉES

### 3.1 Italie (italy.yaml) — CIBLE PHASE B3-bis

| Paramètre | Valeur | Justification |
|---|---|---|
| Data centers | INGV (priorité 1) + IRIS fallback | Olivieri 2023 + redondance |
| Réseaux | IV (dense, 500 km) + MN (sparse, 1500 km) | Couverture INGV + MedNet |
| Auth | `none` partout | INGV ouvert |
| Bandpass | 2-8 Hz | Olivieri 2023 figure 3 |
| Triangulation mode | `normal` | Réseau dense → ≥3 stations attendues |
| Distance max | 1500 km | Validité formules Olivieri |

### 3.2 Maroc (morocco.yaml) — RÉFÉRENCE ÉTAT ACTUEL

Reflète fidèlement la situation au 26 avril 2026 :

- **3 data centers** déclarés : IRIS (priorité 1, ouvert), IPGP (priorité 2, ouvert), GEOFON (priorité 3, **bloqué** sur eduGAIN cappuccino)
- **3 réseaux actifs** : IU, G, WM
- **WM.AVE exclue** explicitement (fermée nov 2011)
- **Mode `permissive`** — accepte 1 station car stations distantes
- **Bandpass 1-8 Hz** — plus large que Italie (signaux plus faibles)
- **Réseau MO** commenté en YAML, prêt à activer dès convention CNRST

### 3.3 USA (usa.yaml) — DÉMONSTRATION GÉNÉRICITÉ

Aucune ligne de code ajoutée pour supporter ce pays. Réseaux CI, BK, NN, US, IU. Démontre qu'ajouter un pays = un fichier YAML.

---

## 4. TESTS ET VALIDATION

### 4.1 Tests unitaires pytest

**22/22 tests passent** (durée < 1 seconde).

Couverture :
- Chargement des 3 configs livrées
- Détection des erreurs (YAML mal formé, schéma invalide, références cassées)
- Mécanisme d'overrides (fusion récursive)
- Méthodes utilitaires (tri par priorité, lookup data center)

```bash
$ python -m pytest tests/ -v
============================= test session starts ==============================
collected 22 items

tests/test_config_loader.py::TestProductionConfigs::test_italy_loads PASSED
tests/test_config_loader.py::TestProductionConfigs::test_italy_has_ingv PASSED
tests/test_config_loader.py::TestProductionConfigs::test_italy_iv_network_dense PASSED
[... 19 autres tests ...]
============================== 22 passed in 0.62s ==============================
```

### 4.2 Smoke tests (style v7, exécutables sans pytest)

**8/8 tests passent.** Vérifications fondamentales en standalone :

```bash
$ python tests/test_smoke_b3bis.py
[OK] Test 1/8 : Régions disponibles (italy/morocco/usa)
[OK] Test 2/8 : Italie : INGV chargé, réseau IV dense
[OK] Test 3/8 : Maroc : GEOFON marqué eduGAIN cappuccino
[OK] Test 4/8 : Maroc : WM.AVE exclue (fermée 2011)
[OK] Test 5/8 : Région inconnue → RegionNotFoundError
[OK] Test 6/8 : Overrides appliqués correctement
[OK] Test 7/8 : Override invalide → ConfigValidationError
[OK] Test 8/8 : Tri réseaux : dense avant sparse

[OK] Tous les smoke tests passés (8/8)
```

### 4.3 Validation FDSN sur cible (à exécuter sur VPS)

Le script `validate_fdsn_access.py` ping chaque endpoint FDSN déclaré et compte les stations dans une bbox de test. À exécuter sur le VPS Hostinger après transfert :

```bash
# Sur le VPS
python validate_fdsn_access.py --region italy
python validate_fdsn_access.py --region morocco
python validate_fdsn_access.py --region usa
```

**Sortie attendue pour Italie (à vérifier en réel sur VPS) :**
```
[OK] ingv             OK (200)
[OK] iris_fallback    OK (200)
[OK] IV   via ingv         → 300+ stations  OK (200)
[OK] MN   via ingv         →  20+ stations  OK (200)
```

**Sortie attendue pour Maroc :**
```
[SKIP] geofon          — auth=edugain_cappuccino (non testable sans credentials)
[OK] iris             OK (200)
[OK] ipgp             OK (200)
[OK] IU   via iris         → quelques stations  OK (200)
[OK] G    via ipgp         →  1 station (TAM)   OK (200)
[SKIP] WM   via geofon       — auth requise
```

---

## 5. UTILISATION

### 5.1 API Python

```python
from config import load_region_config

# Charger une région
cfg = load_region_config("italy")

# Accès aux paramètres
print(cfg.region.name)           # 'italy'
print(cfg.preprocessing.bandpass_low_hz)  # 2.0
print(cfg.detection.trigger_threshold)    # 3.5

# Itérer sur data centers par priorité
for dc in cfg.get_data_centers_by_priority():
    print(f"{dc.name}: {dc.url}")

# Récupérer un data center par nom
ingv = cfg.get_data_center("ingv")

# Réseaux par priorité densité (dense → sparse)
for net in cfg.get_networks_by_priority():
    print(f"{net.code} ({net.expected_density.value})")

# Override pour test ad-hoc
cfg_strict = load_region_config(
    "italy",
    overrides={"detection": {"require_all_criteria": True}},
)
```

### 5.2 Variable d'environnement

Pour déployer en production avec un répertoire de configs custom :

```bash
export METEORITE_SCOUT_CONFIG_DIR=/etc/meteorite-scout/regions
python run_pipeline.py --region italy
```

### 5.3 Ajouter une nouvelle région

1. Créer `config/regions/<nom>.yaml` (s'inspirer d'`italy.yaml`)
2. Vérifier la validation : `python -c "from config import load_region_config; load_region_config('<nom>')"`
3. Ajouter une bbox de test dans `validate_fdsn_access.py` si besoin
4. **Aucune modification de code Python.**

---

## 6. PROCHAINES ÉTAPES

### 6.1 Court terme — Phase B3-bis suite (validation Italie)

1. **Transfert sur VPS Hostinger** : `seismic_pipeline_b3bis.tar.gz`
2. **Test FDSN réel** : `python validate_fdsn_access.py --region italy`
3. **Identification cas Olivieri reproductibles** : extraire du papier la liste précise des événements + stations utilisées
4. **Intégration dans pipeline v7** : voir `MIGRATION_GUIDE.md`
5. **Run pipeline sur cas italiens** : produire un rapport de reproductibilité (écart triangulation pipeline vs paper)

### 6.2 Phase C (déjà autorisée, indépendante)

- Architecture LangGraph définitive
- Migration `seismic_pipeline` → `meteorite-scout-ai/engines/seismic/`
- Le système de config régionale est prêt à être branché tel quel sur LangGraph (objet `RegionConfig` injectable dans `PipelineState`)

### 6.3 Évolutions futures (post-CNRST)

- Couche FastAPI exposant le pipeline en service multi-instances par région (un service par YAML)
- Schéma de config v1.1 ajoutant des champs (publication associée, contacts opérationnels, …)
- Support de configs dynamiques via base de données pour SaaS futur

---

## 7. DÉCISIONS D'ARCHITECTURE — Justifications

### 7.1 Pourquoi Pydantic v2 et pas dataclass ?

- Validation à la lecture, pas à l'usage (échec rapide avec messages clairs)
- Coercion type-safe (string YAML → enum Python)
- Cross-field validators (`model_validator`) pour cohérence
- Sérialisation JSON native pour debug/logging

### 7.2 Pourquoi YAML et pas TOML/JSON ?

- Commentaires multilignes nécessaires pour documenter blocages opérationnels
- Lisibilité supérieure sur structures imbriquées
- Standard de fait en infra (Kubernetes, Ansible, Docker Compose)
- Coût Python : 1 import (`PyYAML`)

### 7.3 Pourquoi pas de DB de configs ?

- Configs versionnées dans Git = audit trail naturel
- Modifications relues par un humain
- Pas de dépendance infra supplémentaire
- Migration vers DB possible plus tard sans rewriter le code (loader abstrait)

### 7.4 Pourquoi un `schema_version` ?

Permet la migration future. Si demain on ajoute un champ obligatoire,
les anciens YAML peuvent être détectés et migrés automatiquement.

---

## 8. LIVRABLES

| Livrable | Chemin | Lignes |
|---|---|---|
| Schéma Pydantic | `config/schema.py` | ~430 |
| Loader YAML | `config/loader.py` | ~180 |
| API publique | `config/__init__.py` | ~50 |
| Config Italie | `config/regions/italy.yaml` | ~80 |
| Config Maroc | `config/regions/morocco.yaml` | ~110 |
| Config USA | `config/regions/usa.yaml` | ~85 |
| Tests pytest | `tests/test_config_loader.py` | ~250 |
| Smoke tests | `tests/test_smoke_b3bis.py` | ~110 |
| Validation FDSN | `validate_fdsn_access.py` | ~155 |
| Rapport (ce doc) | `docs/PHASE_B3bis_RAPPORT.md` | — |
| Guide migration | `docs/MIGRATION_GUIDE.md` | — |
| Requirements | `requirements.txt` | 4 |

**Total code : ~1 350 lignes Python + 275 lignes YAML.**

---

## 9. CONCLUSION

Phase B3-bis livre un système de configuration régionale **production-ready**, testé exhaustivement, et prêt à être intégré dans `seismic_pipeline` v7 → v8.

Le bénéfice immédiat est la capacité à valider le pipeline sur l'Italie sans aucune modification du code de la v7, en ne créant qu'un fichier YAML.

Le bénéfice à long terme est l'extensibilité : tout nouveau pays/réseau sismique s'ajoute en 30 minutes de configuration, sans toucher à la logique métier.

**Phase B3-bis officiellement clôturée.**

Passage à :
- **Phase B3-bis-2** : reproduction des cas Olivieri 2023 sur Italie (validation scientifique)
- **Phase C** : spécification production LangGraph (en parallèle, indépendant)

---

## ANNEXES

### Annexe A — Commandes de reproduction

```bash
# Installation
pip install pydantic>=2.5 pyyaml>=6.0 pytest>=7.4

# Tests
python -m pytest tests/ -v
python tests/test_smoke_b3bis.py

# Validation FDSN (à lancer sur VPS Hostinger)
python validate_fdsn_access.py --region italy
python validate_fdsn_access.py --region morocco
python validate_fdsn_access.py --region usa

# Listage des régions disponibles
python -c "from config import list_available_regions; print(list_available_regions())"

# Inspection d'une config
python -c "from config import load_region_config; cfg = load_region_config('italy'); print(cfg.model_dump_json(indent=2))"
```

### Annexe B — Schéma JSON exporté

Pour intégration avec outils externes (validation IDE, doc auto), le
schéma JSON peut être exporté :

```python
from config import RegionConfig
import json
with open("docs/region_config_schema.json", "w") as f:
    json.dump(RegionConfig.model_json_schema(), f, indent=2)
```

### Annexe C — Références scientifiques

- Olivieri, M. et al. (2023) — *"Seismic signature of small bolides:
  application to the Italian National Seismic Network"*, JGR Solid Earth.
  → Source des paramètres détection (bandpass 2-8 Hz, critères C1-C4).
- Roubeche, F. et al. (2024) — *"Seismic detection of the El-Hakimia bolide"*.
  → Validation portée formules à 1500 km.
- Brown, P. et al. (2002) — *"The flux of small near-Earth objects..."*.
  → Source seuil énergie 6×10⁻⁵ kt TNT.
