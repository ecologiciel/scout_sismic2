# GUIDE DE MIGRATION — seismic_pipeline v7 → v8

**Objectif** : intégrer le système de configuration régionale (Phase B3-bis) dans le module `seismic_pipeline` v7 existant, sans casser les tests smoke 8/8.

**Date** : 26 avril 2026
**Auteur** : Nabil Bakioui

---

## 1. PRINCIPE DE MIGRATION

Le module v7 actuel contient des valeurs en dur dans 3 endroits identifiables :

1. **`acquisition.py`** — URLs des data centers FDSN, codes réseaux
2. **`preprocessing.py`** — paramètres bandpass, detrend, taper
3. **`detection.py` / `triangulation.py`** — seuils STA/LTA, vélocités, distances

La migration consiste à :
1. Ajouter le package `config/` au module
2. Faire passer le `RegionConfig` aux constructeurs des classes existantes
3. Remplacer les constantes en dur par `cfg.<section>.<champ>`

**Aucune classe ni fonction n'est supprimée.** Aucun test smoke v7 ne doit casser.

---

## 2. PROCÉDURE PAS À PAS

### Étape 1 — Copier le package config dans seismic_pipeline

```bash
cd seismic_pipeline_v7/
cp -r ../seismic_pipeline_b3bis/config ./
cp ../seismic_pipeline_b3bis/validate_fdsn_access.py ./
```

Mettre à jour `requirements.txt` :

```
# Existant v7
obspy>=1.5.0
numpy>=1.24
scipy>=1.10
requests>=2.31

# Ajouts B3-bis
pydantic>=2.5,<3.0
PyYAML>=6.0,<7.0
```

### Étape 2 — Modifier `pipeline.py` (orchestration)

**Avant (v7)** :
```python
class SeismicPipeline:
    def __init__(self):
        self.acquisition = AcquisitionEngine()
        self.preprocessor = Preprocessor()
        self.detector = Detector()
        # ...
```

**Après (v8)** :
```python
from config import RegionConfig, load_region_config

class SeismicPipeline:
    def __init__(self, region: str | RegionConfig = "morocco"):
        # Acceptation flexible : nom de région OU objet RegionConfig
        if isinstance(region, str):
            self.config = load_region_config(region)
        else:
            self.config = region

        # Injection de la config dans chaque module
        self.acquisition = AcquisitionEngine(self.config)
        self.preprocessor = Preprocessor(self.config)
        self.detector = Detector(self.config)
        self.triangulator = Triangulator(self.config)
        # ... etc
```

### Étape 3 — Modifier `acquisition.py`

**Avant (v7, valeurs en dur)** :
```python
DATA_CENTERS = {
    "iris": "https://service.iris.edu",
    "geofon": "https://geofon.gfz-potsdam.de",
    # ...
}

class AcquisitionEngine:
    def fetch_waveforms(self, network, station, channel, ...):
        for dc_name, url in DATA_CENTERS.items():
            # ...
```

**Après (v8, config-driven)** :
```python
from config import RegionConfig, AuthType

class AcquisitionEngine:
    def __init__(self, config: RegionConfig):
        self.config = config

    def fetch_waveforms(self, network, station, channel, starttime, endtime):
        # On récupère le data center qui héberge ce réseau
        net_cfg = next(
            (n for n in self.config.networks if n.code == network), None
        )
        if net_cfg is None:
            raise ValueError(f"Réseau {network} non déclaré dans la config")
        if station in net_cfg.excluded_stations:
            logger.info(f"Station {network}.{station} exclue par config")
            return None

        dc = self.config.get_data_center(net_cfg.data_center)
        client = self._build_client(dc)
        return client.get_waveforms(
            network, station, "*", channel, starttime, endtime
        )

    def _build_client(self, dc):
        from obspy.clients.fdsn import Client
        if dc.auth.type == AuthType.NONE:
            return Client(base_url=dc.url, timeout=dc.timeout_seconds)
        elif dc.auth.type == AuthType.EIDA_TOKEN:
            with open(dc.auth.token_path) as f:
                token = f.read().strip()
            return Client(base_url=dc.url, eida_token=token,
                          timeout=dc.timeout_seconds)
        # ... autres types
        else:
            raise NotImplementedError(f"Auth {dc.auth.type} non implémentée")
```

### Étape 4 — Modifier `preprocessing.py`

**Avant** :
```python
BANDPASS_LOW = 1.0
BANDPASS_HIGH = 8.0

class Preprocessor:
    def process(self, stream):
        stream.detrend("linear")
        stream.taper(0.05)
        stream.filter("bandpass", freqmin=BANDPASS_LOW, freqmax=BANDPASS_HIGH)
        return stream
```

**Après** :
```python
class Preprocessor:
    def __init__(self, config: RegionConfig):
        self.cfg = config.preprocessing

    def process(self, stream):
        stream.detrend(self.cfg.detrend_method)
        stream.taper(self.cfg.taper_percentage)
        stream.filter(
            "bandpass",
            freqmin=self.cfg.bandpass_low_hz,
            freqmax=self.cfg.bandpass_high_hz,
        )
        if self.cfg.resample_target_hz:
            stream.resample(self.cfg.resample_target_hz)
        return stream
```

### Étape 5 — Modifier `detection.py`, `triangulation.py`, etc.

Même pattern : injection de `config` au constructeur, lecture des champs via `self.cfg`. Voir `seismic_pipeline_b3bis/config/schema.py` pour la liste exhaustive des champs disponibles.

### Étape 6 — Modifier `run_test.py` (CLI)

**Avant** :
```python
parser.add_argument("--case", choices=["tamdakht", "tiflet", "traspena", "chelyabinsk"])
```

**Après** :
```python
parser.add_argument("--case", required=True)
parser.add_argument(
    "--region",
    default="morocco",
    help="Région (italy, morocco, usa, ...)"
)
# Dans le main :
pipeline = SeismicPipeline(region=args.region)
result = pipeline.run(case_data)
```

Usage :
```bash
# Maroc (comportement v7 préservé)
python run_test.py --case tiflet

# Italie (nouveau)
python run_test.py --case cavezzo --region italy
```

---

## 3. STRATÉGIE DE TEST DURANT LA MIGRATION

### 3.1 Préserver les smoke tests v7

Les 8 smoke tests v7 doivent continuer à passer. **Astuce** : faire de
`SeismicPipeline()` (sans argument) un alias pour `SeismicPipeline(region="morocco")` afin que les anciens tests fonctionnent sans modification.

### 3.2 Ajouter des smoke tests v8

Dupliquer les 4 cas v7 (Tamdakht, Tiflet, Traspena, Chelyabinsk) avec
`region="morocco"` explicite, puis ajouter des cas Italie.

### 3.3 Test d'isolation

Vérifier qu'aucune valeur ne fuit d'une région à l'autre :

```python
def test_no_state_leak_between_regions():
    pipe_it = SeismicPipeline(region="italy")
    pipe_ma = SeismicPipeline(region="morocco")
    assert pipe_it.preprocessor.cfg.bandpass_low_hz == 2.0
    assert pipe_ma.preprocessor.cfg.bandpass_low_hz == 1.0
    # Aucune contamination entre instances
```

---

## 4. ANTI-PATTERNS À ÉVITER

### ❌ NE PAS faire

**1. `if region == "italy"` dans le code Python**
```python
# MAUVAIS
if self.config.region.name == "italy":
    bandpass_low = 2.0
else:
    bandpass_low = 1.0
```
La logique conditionnelle géographique appartient au YAML, pas au code.

**2. Constantes globales modifiables**
```python
# MAUVAIS
BANDPASS_LOW = 1.0  # Modifié dynamiquement par load_region_config()
```
Cause des bugs de partage d'état entre instances. Toujours injecter via
constructeur.

**3. Configs en dur dans les tests**
```python
# MAUVAIS
def test_detection():
    detector = Detector()
    detector.threshold = 3.5  # Magic number
```
Utiliser `load_region_config(...)` ou un YAML de test dédié.

### ✅ Faire à la place

**1. Toute la logique régionale dans le YAML**

**2. Configs immutables passées au constructeur**

**3. Fixtures pytest pour les configs de test**
```python
@pytest.fixture
def italy_config():
    return load_region_config("italy")

def test_detection(italy_config):
    detector = Detector(italy_config)
    # ...
```

---

## 5. CHECKLIST DE LIVRAISON v8

Avant de packager `seismic_pipeline_v8.tar.gz` :

- [ ] Package `config/` copié et fonctionnel (smoke tests B3-bis 8/8)
- [ ] `requirements.txt` à jour (pydantic + pyyaml)
- [ ] `pipeline.py` accepte `region: str | RegionConfig`
- [ ] `acquisition.py`, `preprocessing.py`, `detection.py`, `triangulation.py` lisent depuis config
- [ ] `run_test.py` accepte `--region`
- [ ] Smoke tests v7 (8/8) toujours passent (sans argument = morocco)
- [ ] Nouveaux smoke tests v8 ajoutés (4 cas × 2 régions au minimum)
- [ ] Test d'isolation entre régions OK
- [ ] `validate_fdsn_access.py --region italy` retourne PASS sur VPS
- [ ] Documentation mise à jour (`README.md` mentionne `--region`)

---

## 6. RECOMMANDATION POUR CLAUDE CODE

Quand tu transfères ce projet à Claude Code pour Phase C, fournis-lui :

1. Le tar.gz v7 actuel (référence)
2. Le tar.gz B3-bis (nouveau système)
3. Ce guide de migration (`MIGRATION_GUIDE.md`)
4. Les rapports `PHASE_B1_FORMULES_MAITRES.md`, `PHASE_B3_RAPPORT_FINAL.md`, `PHASE_B3bis_RAPPORT.md`
5. Le brief explicite : *"Migrer seismic_pipeline v7 vers v8 selon MIGRATION_GUIDE.md, en intégrant le package config/ de B3-bis. Préserver les 8 smoke tests v7. Ajouter des smoke tests pour la région italy."*

Claude Code performera mieux avec ces livrables complets et un brief précis qu'avec une description floue.

---

## 7. EFFORT ESTIMÉ

| Tâche | Durée |
|---|---|
| Copie package + requirements | 5 min |
| Refactor `pipeline.py` | 30 min |
| Refactor `acquisition.py` | 1-2 h (le plus complexe à cause de l'auth) |
| Refactor `preprocessing.py` | 30 min |
| Refactor `detection.py` | 30 min |
| Refactor `triangulation.py` | 30 min |
| Refactor autres (`altitude.py`, `energy.py`) | 1 h |
| Adaptation `run_test.py` | 30 min |
| Tests v7 préservés + nouveaux v8 | 1-2 h |
| **Total estimé** | **~6-8 heures** |

Faisable en une journée Claude Code avec un bon brief.
