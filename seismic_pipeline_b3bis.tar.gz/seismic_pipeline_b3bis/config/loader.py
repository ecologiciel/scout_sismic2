"""loader.py — Chargement et validation des configs régionales YAML.

Responsabilités :
- Localiser le fichier YAML d'une région donnée
- Parser le YAML en respectant le schéma Pydantic
- Produire des messages d'erreur exploitables (chemin du champ fautif)
- Supporter les overrides pour tests

Usage standard :
    from config.loader import load_region_config
    cfg = load_region_config("italy")

Usage avec répertoire custom (tests) :
    cfg = load_region_config("italy", config_dir="/tmp/test_configs")

Usage avec override de champs (tests) :
    cfg = load_region_config(
        "italy",
        overrides={"detection": {"trigger_threshold": 5.0}},
    )

Phase B3-bis — Meteorite Scout AI
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import ValidationError

from .schema import RegionConfig

logger = logging.getLogger(__name__)


# =============================================================================
# Exceptions explicites
# =============================================================================

class ConfigError(Exception):
    """Erreur générique de configuration régionale."""


class RegionNotFoundError(ConfigError):
    """Fichier YAML de la région introuvable."""


class ConfigValidationError(ConfigError):
    """Le YAML est syntaxiquement OK mais ne respecte pas le schéma."""


class YamlParseError(ConfigError):
    """Le fichier YAML est mal formé."""


# =============================================================================
# Localisation des configs
# =============================================================================

DEFAULT_CONFIG_DIR = Path(__file__).parent / "regions"


def _resolve_config_dir(config_dir: Optional[str | Path]) -> Path:
    """Détermine le répertoire de configs, par ordre de priorité :

    1. Argument explicite `config_dir`
    2. Variable d'environnement `METEORITE_SCOUT_CONFIG_DIR`
    3. Répertoire par défaut `<package>/regions/`
    """
    if config_dir is not None:
        return Path(config_dir).expanduser().resolve()

    env_dir = os.environ.get("METEORITE_SCOUT_CONFIG_DIR")
    if env_dir:
        return Path(env_dir).expanduser().resolve()

    return DEFAULT_CONFIG_DIR


def list_available_regions(config_dir: Optional[str | Path] = None) -> list[str]:
    """Retourne la liste des régions disponibles dans le répertoire."""
    cfg_dir = _resolve_config_dir(config_dir)
    if not cfg_dir.is_dir():
        return []
    return sorted(
        p.stem for p in cfg_dir.glob("*.yaml") if not p.stem.startswith("_")
    )


# =============================================================================
# Merge récursif pour overrides
# =============================================================================

def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Fusion récursive de deux dicts (override gagne sur les conflits)."""
    result = dict(base)
    for key, value in override.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
        ):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


# =============================================================================
# Chargement principal
# =============================================================================

def load_region_config(
    region_name: str,
    config_dir: Optional[str | Path] = None,
    overrides: Optional[dict[str, Any]] = None,
) -> RegionConfig:
    """Charge et valide la configuration d'une région.

    Args:
        region_name: Nom court (ex: 'italy', 'morocco', 'usa').
            Casse insensible côté fichier (cherche `<region>.yaml`).
        config_dir: Répertoire des YAML (défaut : `<package>/regions/`).
        overrides: Dict de surcharge fusionné après lecture du YAML.
            Utile pour tests / runs ad-hoc sans modifier les fichiers.

    Returns:
        Objet `RegionConfig` validé.

    Raises:
        RegionNotFoundError: Le fichier YAML n'existe pas.
        YamlParseError: Le YAML est mal formé.
        ConfigValidationError: Le contenu ne respecte pas le schéma.
    """
    region_name = region_name.strip().lower()
    cfg_dir = _resolve_config_dir(config_dir)
    yaml_path = cfg_dir / f"{region_name}.yaml"

    logger.debug("Chargement config région='%s' depuis %s", region_name, yaml_path)

    if not yaml_path.is_file():
        available = list_available_regions(config_dir)
        raise RegionNotFoundError(
            f"Configuration introuvable : {yaml_path}\n"
            f"Régions disponibles : {available or '(aucune)'}"
        )

    # 1. Lecture YAML brut
    try:
        with yaml_path.open("r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)
    except yaml.YAMLError as exc:
        raise YamlParseError(
            f"YAML mal formé dans {yaml_path}\n  → {exc}"
        ) from exc

    if not isinstance(raw, dict):
        raise YamlParseError(
            f"{yaml_path} : la racine doit être un mapping (dict), "
            f"reçu {type(raw).__name__}"
        )

    # 2. Application des overrides éventuels
    if overrides:
        raw = _deep_merge(raw, overrides)
        logger.debug("Overrides appliqués : %s", list(overrides.keys()))

    # 3. Validation Pydantic
    try:
        config = RegionConfig.model_validate(raw)
    except ValidationError as exc:
        raise ConfigValidationError(
            f"Erreurs de schéma dans {yaml_path} :\n{_format_validation_errors(exc)}"
        ) from exc

    logger.info(
        "Config '%s' chargée : %d data centers, %d réseaux",
        config.region.name,
        len(config.data_centers),
        len(config.networks),
    )
    return config


def _format_validation_errors(exc: ValidationError) -> str:
    """Formatte les erreurs Pydantic en texte lisible (chemin → message)."""
    lines = []
    for err in exc.errors():
        loc = ".".join(str(p) for p in err["loc"])
        msg = err["msg"]
        lines.append(f"  • {loc} : {msg}")
    return "\n".join(lines)


# =============================================================================
# API publique
# =============================================================================

__all__ = [
    "load_region_config",
    "list_available_regions",
    "ConfigError",
    "RegionNotFoundError",
    "ConfigValidationError",
    "YamlParseError",
]
