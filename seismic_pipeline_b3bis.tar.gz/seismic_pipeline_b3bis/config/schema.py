"""schema.py — Schéma Pydantic des configurations régionales.

Ce module définit la structure des fichiers YAML décrivant l'accès
sismique d'une région donnée (data centers, réseaux, paramètres
détection/prétraitement/triangulation).

Le code Python du pipeline ne contient AUCUNE valeur en dur liée à un
pays particulier. Toute la logique géographique/politique d'accès est
encapsulée dans ces objets de configuration validés à l'exécution.

Usage :
    from config.loader import load_region_config
    cfg = load_region_config("italy")
    pipeline = SeismicPipeline(cfg)

Phase B3-bis — Meteorite Scout AI
Auteur : Nabil Bakioui (ecologiciel@gmail.com)
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


# =============================================================================
# Enumérations contraintes
# =============================================================================

class AuthType(str, Enum):
    """Type d'authentification supporté par un data center FDSN."""

    NONE = "none"                       # Ouvert (IRIS, INGV, IPGP)
    EIDA_TOKEN = "eida_token"           # Token EIDA (B2ACCESS)
    EDUGAIN_CAPPUCCINO = "edugain_cappuccino"  # eduGAIN niveau cappuccino (WM)
    BILATERAL_TOKEN = "bilateral_token"  # Token bilatéral (CNRST/MO)
    BASIC_AUTH = "basic_auth"           # Login/password classique


class NetworkDensity(str, Enum):
    """Densité attendue d'un réseau (impacte la stratégie de recherche)."""

    DENSE = "dense"           # < 50 km entre stations (INGV, USArray)
    MEDIUM = "medium"         # 50-150 km (Maroc avec MO, Espagne)
    SPARSE = "sparse"         # > 150 km (réseaux globaux IU, G)


class TriangulationMode(str, Enum):
    """Mode de triangulation autorisé selon nb stations disponibles."""

    STRICT = "strict"           # Refuse < 3 stations
    NORMAL = "normal"           # Mode dégradé 2 stations OK
    PERMISSIVE = "permissive"   # Accepte 1 station (cercle d'incertitude)


# =============================================================================
# Sous-modèles
# =============================================================================

class AuthConfig(BaseModel):
    """Configuration d'authentification d'un data center.

    Pour `type=NONE` : aucun champ supplémentaire.
    Pour `type=EIDA_TOKEN` : `token_path` requis.
    Pour `type=EDUGAIN_CAPPUCCINO` : `idp_url` + `eppn` requis.
    Pour `type=BILATERAL_TOKEN` : `token_path` requis.
    Pour `type=BASIC_AUTH` : `username` + `password_env_var` requis.
    """

    model_config = ConfigDict(extra="forbid")

    type: AuthType = Field(..., description="Type d'authentification")
    token_path: Optional[str] = Field(
        None,
        description="Chemin absolu vers le fichier token (EIDA/bilatéral)",
    )
    idp_url: Optional[str] = Field(
        None, description="URL IdP eduGAIN (ex: https://idp.um5.ac.ma)"
    )
    eppn: Optional[str] = Field(
        None, description="eduPersonPrincipalName (ex: nabil@um5.ac.ma)"
    )
    username: Optional[str] = Field(None, description="Login HTTP basic auth")
    password_env_var: Optional[str] = Field(
        None,
        description="Nom de variable d'environnement contenant le mot de passe",
    )

    @model_validator(mode="after")
    def _check_required_fields(self) -> "AuthConfig":
        """Valide la cohérence des champs selon le type d'auth."""
        if self.type == AuthType.NONE:
            return self
        if self.type in (AuthType.EIDA_TOKEN, AuthType.BILATERAL_TOKEN):
            if not self.token_path:
                raise ValueError(f"`token_path` requis pour type={self.type.value}")
        if self.type == AuthType.EDUGAIN_CAPPUCCINO:
            if not (self.idp_url and self.eppn):
                raise ValueError(
                    "`idp_url` et `eppn` requis pour eduGAIN cappuccino"
                )
        if self.type == AuthType.BASIC_AUTH:
            if not (self.username and self.password_env_var):
                raise ValueError(
                    "`username` et `password_env_var` requis pour basic auth"
                )
        return self


class DataCenterConfig(BaseModel):
    """Configuration d'un data center FDSN.

    Plusieurs data centers peuvent être déclarés par région avec un ordre
    de priorité ; le pipeline les essaie séquentiellement en cas d'échec.
    """

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., min_length=2, description="Identifiant court (ex: 'ingv')")
    url: str = Field(..., description="Base URL FDSN (sans /fdsnws final)")
    auth: AuthConfig = Field(..., description="Configuration d'authentification")
    priority: int = Field(
        1, ge=1, le=10, description="Priorité d'essai (1=premier, 10=dernier)"
    )
    timeout_seconds: int = Field(
        30, ge=5, le=300, description="Timeout HTTP par requête"
    )
    notes: Optional[str] = Field(
        None, description="Commentaires opérationnels (statut, contact, etc.)"
    )

    @field_validator("url")
    @classmethod
    def _validate_url(cls, v: str) -> str:
        if not v.startswith(("http://", "https://")):
            raise ValueError("L'URL doit commencer par http:// ou https://")
        return v.rstrip("/")  # Normalisation : pas de slash final


class NetworkConfig(BaseModel):
    """Configuration d'un réseau sismique (code FDSN à 1-2 caractères)."""

    model_config = ConfigDict(extra="forbid")

    code: str = Field(
        ...,
        min_length=1,
        max_length=2,
        description="Code FDSN officiel (ex: 'IV', 'MO', 'WM')",
    )
    operator: str = Field(..., description="Organisme exploitant (ex: 'INGV')")
    data_center: str = Field(
        ..., description="Nom du data center hébergeant ce réseau"
    )
    max_radius_km: float = Field(
        ..., gt=0, le=20000, description="Rayon max recherche stations"
    )
    expected_density: NetworkDensity = Field(
        NetworkDensity.MEDIUM, description="Densité attendue du réseau"
    )
    channels_priority: list[str] = Field(
        default_factory=lambda: ["HHZ", "BHZ", "EHZ"],
        description="Channels par ordre de préférence (Z-component focus)",
    )
    excluded_stations: list[str] = Field(
        default_factory=list,
        description="Stations à exclure (ex: stations fermées WM.AVE)",
    )

    @field_validator("code")
    @classmethod
    def _validate_code(cls, v: str) -> str:
        v = v.upper()
        if not v.isalnum():
            raise ValueError(f"Code réseau invalide : '{v}' (alphanumérique requis)")
        return v


class DetectionConfig(BaseModel):
    """Paramètres de détection STA/LTA + critères Olivieri 2023."""

    model_config = ConfigDict(extra="forbid")

    algorithm: str = Field(
        "olivieri_4_criteria",
        description="Algorithme de détection (référence à un module Python)",
    )
    sta_window_s: float = Field(
        1.0, gt=0, le=60, description="Fenêtre Short-Term Average (secondes)"
    )
    lta_window_s: float = Field(
        30.0, gt=1, le=600, description="Fenêtre Long-Term Average (secondes)"
    )
    trigger_threshold: float = Field(
        3.5, gt=1.0, description="Seuil ratio STA/LTA pour déclenchement"
    )
    detrigger_threshold: float = Field(
        1.5, gt=0.5, description="Seuil retour à la normale"
    )
    require_all_criteria: bool = Field(
        False,
        description="True = exiger les 4 critères Olivieri C1-C4 (strict)",
    )
    min_energy_kt_tnt: float = Field(
        6e-5,
        gt=0,
        description="Seuil énergie minimale détectable (Brown 2007)",
    )

    @model_validator(mode="after")
    def _check_thresholds(self) -> "DetectionConfig":
        if self.lta_window_s <= self.sta_window_s:
            raise ValueError("LTA window doit être > STA window")
        if self.trigger_threshold <= self.detrigger_threshold:
            raise ValueError("trigger_threshold doit être > detrigger_threshold")
        return self


class PreprocessingConfig(BaseModel):
    """Paramètres ObsPy de prétraitement du signal."""

    model_config = ConfigDict(extra="forbid")

    bandpass_low_hz: float = Field(
        2.0, gt=0, lt=50, description="Filtre bandpass borne basse"
    )
    bandpass_high_hz: float = Field(
        8.0, gt=0, le=100, description="Filtre bandpass borne haute"
    )
    resample_target_hz: Optional[float] = Field(
        100.0, description="Fréquence rééchantillonnage cible (None = pas de resample)"
    )
    detrend_method: str = Field(
        "linear", description="Méthode detrend ObsPy ('linear', 'demean', 'simple')"
    )
    taper_percentage: float = Field(
        0.05, ge=0, le=0.5, description="Fraction de taper aux extrémités"
    )

    @model_validator(mode="after")
    def _check_bandpass(self) -> "PreprocessingConfig":
        if self.bandpass_high_hz <= self.bandpass_low_hz:
            raise ValueError("bandpass_high_hz doit être > bandpass_low_hz")
        return self


class TriangulationConfig(BaseModel):
    """Paramètres de triangulation isochrone et mode dégradé."""

    model_config = ConfigDict(extra="forbid")

    mode: TriangulationMode = Field(
        TriangulationMode.NORMAL, description="Tolérance nombre de stations"
    )
    min_stations: int = Field(
        3, ge=1, le=10, description="Nb minimal de stations pour triangulation pleine"
    )
    degraded_radius_km: float = Field(
        100.0,
        gt=0,
        description="Rayon d'incertitude en mode dégradé 1-2 stations",
    )
    rayleigh_velocity_ms: float = Field(
        2000.0,
        gt=500,
        lt=5000,
        description="Vitesse onde Rayleigh couplage atmosphère/sol",
    )
    acoustic_velocity_min_ms: float = Field(
        800.0,
        gt=100,
        description="Vitesse acoustique apparente min (critère C4)",
    )
    acoustic_velocity_max_ms: float = Field(
        1500.0,
        gt=500,
        description="Vitesse acoustique apparente max (critère C4)",
    )
    max_distance_km: float = Field(
        1500.0,
        gt=0,
        description="Portée max formules Olivieri (au-delà = hors validité)",
    )

    @model_validator(mode="after")
    def _check_velocities(self) -> "TriangulationConfig":
        if self.acoustic_velocity_max_ms <= self.acoustic_velocity_min_ms:
            raise ValueError(
                "acoustic_velocity_max_ms doit être > acoustic_velocity_min_ms"
            )
        return self


class QualityControlConfig(BaseModel):
    """Filtres qualité appliqués aux waveforms et détections."""

    model_config = ConfigDict(extra="forbid")

    reject_if_snr_below: float = Field(
        1.0, gt=0, description="Rejet si SNR < ce seuil"
    )
    reject_if_gaps_above_seconds: float = Field(
        5.0, ge=0, description="Rejet si gaps cumulés > ce seuil dans la fenêtre"
    )
    require_three_components: bool = Field(
        False,
        description="True = exiger Z+N+E ; False = Z seul accepté",
    )


class RegionMetadata(BaseModel):
    """Métadonnées descriptives de la région (pas de logique métier)."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Nom court (ex: 'italy', 'morocco')")
    iso_code: str = Field(
        ..., min_length=2, max_length=3, description="Code ISO 3166-1 alpha-2/3"
    )
    timezone: str = Field(
        ..., description="Fuseau IANA (ex: 'Europe/Rome', 'Africa/Casablanca')"
    )
    description: Optional[str] = Field(
        None, description="Description libre (contexte, statut)"
    )


# =============================================================================
# Modèle racine
# =============================================================================

class RegionConfig(BaseModel):
    """Configuration complète d'une région pour le pipeline sismique.

    C'est l'objet racine produit par le loader et consommé par
    `SeismicPipeline`. Contient TOUTES les variables géographiques /
    politiques d'accès / paramètres locaux nécessaires au run.

    Schéma versionné : `schema_version` permet la migration future.
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: str = Field(
        "1.0", description="Version du schéma de config (semver-like)"
    )
    region: RegionMetadata
    data_centers: list[DataCenterConfig] = Field(
        ..., min_length=1, description="Au moins un data center requis"
    )
    networks: list[NetworkConfig] = Field(
        ..., min_length=1, description="Au moins un réseau requis"
    )
    detection: DetectionConfig = Field(default_factory=DetectionConfig)
    preprocessing: PreprocessingConfig = Field(default_factory=PreprocessingConfig)
    triangulation: TriangulationConfig = Field(default_factory=TriangulationConfig)
    quality_control: QualityControlConfig = Field(
        default_factory=QualityControlConfig
    )

    @model_validator(mode="after")
    def _check_data_center_references(self) -> "RegionConfig":
        """Vérifie que chaque réseau référence un data center déclaré."""
        declared_dcs = {dc.name for dc in self.data_centers}
        for net in self.networks:
            if net.data_center not in declared_dcs:
                raise ValueError(
                    f"Réseau {net.code} référence le data center "
                    f"'{net.data_center}' non déclaré. "
                    f"Data centers disponibles : {sorted(declared_dcs)}"
                )
        return self

    @model_validator(mode="after")
    def _check_unique_data_center_names(self) -> "RegionConfig":
        names = [dc.name for dc in self.data_centers]
        if len(names) != len(set(names)):
            raise ValueError(f"Noms data centers dupliqués : {names}")
        return self

    @model_validator(mode="after")
    def _check_unique_network_codes(self) -> "RegionConfig":
        codes = [net.code for net in self.networks]
        if len(codes) != len(set(codes)):
            raise ValueError(f"Codes réseaux dupliqués : {codes}")
        return self

    def get_data_center(self, name: str) -> DataCenterConfig:
        """Retourne le data center par son nom (lève KeyError sinon)."""
        for dc in self.data_centers:
            if dc.name == name:
                return dc
        raise KeyError(f"Data center '{name}' introuvable dans la config")

    def get_networks_by_priority(self) -> list[NetworkConfig]:
        """Retourne les réseaux triés par densité (dense → medium → sparse).

        Heuristique : on essaie d'abord les réseaux denses (plus probable
        d'avoir 3+ stations à courte distance).
        """
        density_order = {
            NetworkDensity.DENSE: 0,
            NetworkDensity.MEDIUM: 1,
            NetworkDensity.SPARSE: 2,
        }
        return sorted(
            self.networks,
            key=lambda n: (density_order[n.expected_density], n.max_radius_km),
        )

    def get_data_centers_by_priority(self) -> list[DataCenterConfig]:
        """Retourne les data centers triés par priorité ascendante."""
        return sorted(self.data_centers, key=lambda dc: dc.priority)
