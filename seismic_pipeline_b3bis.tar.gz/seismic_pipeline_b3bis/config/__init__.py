"""config — Système de configuration régionale du pipeline sismique.

Phase B3-bis du projet Meteorite Scout AI.

API publique :
    load_region_config(name)  → RegionConfig validée
    list_available_regions()  → liste des régions installées

Exemple :
    >>> from config import load_region_config
    >>> cfg = load_region_config("italy")
    >>> cfg.region.name
    'italy'
    >>> [n.code for n in cfg.networks]
    ['IV', 'MN']
"""
from .loader import (
    ConfigError,
    ConfigValidationError,
    RegionNotFoundError,
    YamlParseError,
    list_available_regions,
    load_region_config,
)
from .schema import (
    AuthConfig,
    AuthType,
    DataCenterConfig,
    DetectionConfig,
    NetworkConfig,
    NetworkDensity,
    PreprocessingConfig,
    QualityControlConfig,
    RegionConfig,
    RegionMetadata,
    TriangulationConfig,
    TriangulationMode,
)

__all__ = [
    # Loader
    "load_region_config",
    "list_available_regions",
    "ConfigError",
    "ConfigValidationError",
    "RegionNotFoundError",
    "YamlParseError",
    # Schema
    "RegionConfig",
    "RegionMetadata",
    "DataCenterConfig",
    "AuthConfig",
    "AuthType",
    "NetworkConfig",
    "NetworkDensity",
    "DetectionConfig",
    "PreprocessingConfig",
    "TriangulationConfig",
    "TriangulationMode",
    "QualityControlConfig",
]

__version__ = "1.0.0"
