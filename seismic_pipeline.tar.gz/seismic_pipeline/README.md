# Pipeline sismique — Meteorite Scout AI

Module indépendant de détection et triangulation de bolides météoritiques
à partir de données sismiques publiques (protocole FDSN).

**Destination finale** : sera intégré dans `meteorite-scout-ai/engines/seismic/`
comme épine dorsale des modes MANUAL_FALL, AUTO_SEISMIC et ARCHEO_SEISMIC.

---

## Référence scientifique

Ce module implémente les formules extraites dans la **Phase B1** à partir de
3 publications de référence :

1. **Olivieri et al. (2023)** — Italie 5 mars 2022, 61 stations
   *Scientific Reports* 13, 21135. DOI: 10.1038/s41598-023-48396-8

2. **Roubeche et al. (2024)** — El-Hakimia Algérie 7 mai 2023, 14 stations
   *Pure and Applied Geophysics*. DOI: 10.1007/s00024-025-03730-1

3. **Andrade et al. (2023)** — Traspena Espagne 18 janvier 2021, 3 stations
   *MNRAS* 518(3), 3850-3876. DOI: 10.1093/mnras/stac2911

Document maître complet : `docs/PHASE_B1_FORMULES_MAITRES.md`

---

## Installation

### Prérequis

- Python 3.9 ou plus récent
- ~500 MB d'espace disque
- Connexion internet (pour télécharger les données FDSN)

### Setup VPS

```bash
# 1. Cloner / copier le dossier seismic_pipeline sur le VPS
cd ~
# (ou wget / scp depuis ta machine locale)

# 2. Créer un environnement virtuel (recommandé)
python3 -m venv venv_seismic
source venv_seismic/bin/activate

# 3. Installer les dépendances
cd seismic_pipeline
pip install -r requirements.txt

# 4. Vérifier l'installation
python -c "import obspy; print(f'ObsPy {obspy.__version__} OK')"
```

**Temps d'installation attendu** : 2-5 minutes selon bande passante
(ObsPy fait ~200 MB).

---

## Utilisation

### Test sur les 3 cas marocains de validation

```bash
# Tester un cas spécifique
python run_test.py --case tamdakht
python run_test.py --case tissint
python run_test.py --case tiflet

# Tester les 3 cas
python run_test.py --case all

# Mode verbose (logs détaillés)
python run_test.py --case tiflet --verbose
```

### Sorties générées

Pour chaque cas, dans `./results/<case>/` :

- `pipeline_result.json` — Résultats structurés complets
- `report.txt` — Rapport texte lisible
- `waveform_WM_IFR.png`, etc. — Graphiques des formes d'onde par station

### Exemple de rapport texte

```
===========================================================================
RAPPORT PIPELINE SISMIQUE — TIFLET
===========================================================================

Cas : Tiflet 7 février 2026 — Aubrite, région Khémisset (CAS PHARE)
Heure événement : 2026-02-07T09:00:00
Position approx. : (33.89°, -6.31°)

STATUT DU PIPELINE :
  Succès : True
  Bolide confirmé : True
  Confiance : 0.85

STATIONS INTERROGÉES :
  ✓ WM.IFR      à  117.0 km
  ✓ WM.PVLZ     à  233.0 km
  ✓ WM.CEU      à  242.0 km

DÉTECTION (4 CRITÈRES OLIVIERI 2023) :
  ✓ C1 — Absence onde P : v_max = 1.12 km/s
  ✓ C2 — Durée < 5 s : max = 2.34 s
  ✓ C3 — Corrélation > 0.7 : moyenne = 0.812
  ✓ C4 — Vitesse 800-1500 m/s : observée = 1180 m/s

TRIANGULATION :
  Méthode : isochrones
  Nombre de stations utilisées : 3
  RMS résidus : 0.421 s
  Confiance : 0.96

  SOURCE CALCULÉE :
    Latitude  : 33.88345° (± 2.1 km)
    Longitude : -6.31412° (± 2.1 km)
    Altitude  : 34.20 km (± 2.1 km)

  ÉCART / VÉRITÉ TERRAIN : 1.24 km
  ✅ VALIDATION RÉUSSIE (écart < 20 km)
```

---

## Architecture du module

```
seismic_pipeline/
├── README.md                    # Ce fichier
├── requirements.txt             # Dépendances Python
├── run_test.py                  # Script principal de test
├── docs/
│   └── PHASE_B1_FORMULES_MAITRES.md  # Document maître formules
├── engines/
│   ├── __init__.py
│   └── seismic/
│       ├── __init__.py          # Constantes physiques, stations
│       ├── acquisition.py       # Étape 1 — Téléchargement FDSN
│       ├── preprocessing.py     # Étape 2 — Filtres, détrending
│       ├── detection.py         # Étape 3 — 4 critères Olivieri
│       ├── triangulation.py     # Étape 4 — Isochrones/back-azimut
│       ├── altitude.py          # Étape 5 — Fragmentation 3D
│       ├── energy.py            # Étape 6 — Énergie/masse
│       └── pipeline.py          # Étape 7 — Orchestration + DFMC
└── tests/
    └── test_smoke.py            # Tests de smoke (offline)
```

---

## Cas de validation

### Tamdakht (20 décembre 2008, 22:37 UTC)

- Configuration : 2 stations WM (IFR + AVE) à 316 km
- Test : triangulation 2-stations avec altitude supposée
- Vérité terrain : 31.163°N, -7.015°E (Wikipédia)
- Usage : valider le mode dégradé "2 stations"

### Tissint (18 juillet 2011, 02:00 UTC)

- Configuration : stations à 500-700 km (mode longue distance)
- Test : capacité avec stations éloignées
- Vérité terrain : 29.48°N, -7.61°E (strewn field 70 km²)
- Usage : valider le mode dégradé "longue distance"

### Tiflet (7 février 2026, ~09:00 UTC) — **CAS PHARE**

- Configuration : 3 stations WM (IFR + CEU + PVLZ) à 117-242 km
- Test : triangulation complète par isochrones
- Vérité terrain : région Khémisset (Prof Chennaoui confirme coords)
- Usage : valider le mode nominal "3+ stations"
- Particularité : petite énergie (aubrite ~kg), test du seuil de détection

---

## Stations sismiques confirmées

7 stations publiques accessibles via FDSN :

| Code       | Lieu                     | Data Center | Active depuis |
|------------|--------------------------|-------------|---------------|
| WM.IFR     | Ifrane, Maroc            | GEOFON      | 2007          |
| WM.CEU     | Ceuta                    | GEOFON      | 2007          |
| WM.PVLZ    | Velez de la Gomera       | GEOFON      | 2007          |
| WM.AVE     | Averroès Rabat (fermée)  | GEOFON      | 2007-2011     |
| G.TAM      | Tamanrasset (Sahara)     | IPGP        | 1983          |
| TT.THTN    | Thala, Tunisie           | IRIS        | 2010          |
| IU.MACI    | Tenerife, Canaries       | IRIS        | 2008          |
| IU.SACV    | Santiago, Cabo Verde     | IRIS        | 2000          |

Réseaux **non accessibles** empiriquement :
- MO (36 stations Maroc CNRST) — négociation future
- ADSN (69 stations Algérie CRAAG) — fermé

---

## Pipeline à 7 étapes

```
1. Acquisition FDSN           fetch_waveforms()
          ↓
2. Prétraitement             preprocess_stream()
          ↓  (détrending + filtres 1-20 Hz, 0.5-4 Hz, highpass 3 Hz)
3. Détection signature       detect_bolide_signature()
          ↓  (4 critères Olivieri)
4. Triangulation             triangulate()
          ↓  (isochrones ou back-azimut selon nb stations)
5. Altitude fragmentation    estimate_altitude()
          ↓
6. Énergie / masse           estimate_energy_mass()
          ↓  (Gi & Brown 2017 + formule M = 2E/V²)
7. Interface DFMC             to_dfmc_input()
          ↓
         DFMC calcule strewn field au sol
```

---

## Limites connues

1. **Réponse instrumentale** : le retrait complet nécessite l'inventory
   FDSN. Si échec, le pipeline continue avec les formes relatives
   (détection possible, amplitudes absolues non garanties).

2. **Modèle atmosphérique** : utilise actuellement le modèle homogène
   (c = 295 m/s). Le raffinement ERA5 est prévu en Phase B3.

3. **Vitesse d'entrée** : sans observation optique, une plage de masses
   est retournée pour différentes vitesses (12-25 km/s typiques).

4. **Formule Gi & Brown 2017** : coefficients approximatifs dans cette
   version (valeurs précises à extraire du papier complet).

---

## Intégration future dans meteorite-scout-ai

Lors de l'intégration dans le repo principal :

1. Copier `engines/seismic/` dans `meteorite-scout-ai/engines/seismic/`
2. Ajouter la dépendance `obspy` dans `requirements.txt` principal
3. Créer nœuds LangGraph dans `meteorite-scout-ai/nodes/seismic/` :
   - `fetch_fdsn.py` → appelle `fetch_waveforms()`
   - `detect_signature.py` → appelle `detect_bolide_signature()`
   - `triangulate.py` → appelle `triangulate()` + inject DFMC
4. Étendre `PipelineState` dans `graph/state.py` avec champs sismiques
5. Router les modes MANUAL_FALL et AUTO_SEISMIC vers ces nœuds

---

## Dépannage

### "No module named 'obspy'"

```bash
pip install --upgrade pip
pip install obspy
```

### "FDSNNoDataException"

- Vérifier que la station était active à la date de l'événement
- Vérifier la connexion internet vers les data centers
- Essayer une fenêtre temporelle plus large

### "Connection timeout"

Les serveurs FDSN (GEOFON, IRIS) peuvent être lents aux heures de pointe.
Réessayer après quelques minutes.

### Tests lents

Le téléchargement de 60 minutes de données broadband sur 3 stations prend
typiquement 30-90 secondes selon la bande passante.

---

## Licence et contact

Projet interne Meteorite Scout AI — usage commercial réservé.

Responsable : Nabil
Document maître : `docs/PHASE_B1_FORMULES_MAITRES.md`
Version : 1.0 (Phase B2 livraison initiale)
