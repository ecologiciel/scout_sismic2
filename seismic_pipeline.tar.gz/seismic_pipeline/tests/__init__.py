"""tests -- Tests du pipeline sismique."""
