"""tests/test_smoke.py -- Tests smoke basiques (offline).

Vérifie que :
  - Tous les modules s'importent correctement
  - Les constantes physiques sont cohérentes
  - Les dataclasses sont instanciables

Pas d'appels réseau (FDSN) — ces tests tournent sans connexion.

Usage :
    cd seismic_pipeline
    python -m pytest tests/test_smoke.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ajouter le parent au path
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_import_constants():
    """Les constantes physiques sont importables."""
    from engines.seismic import (
        C_SOUND_HOMOGENEOUS,
        CROSS_CORR_MIN,
        DURATION_MAX,
        FDSN_CLIENTS,
        FREQ_HIGH_MAX,
        FREQ_HIGH_MIN,
        STATIONS_MAROC,
        V_APPARENT_MAX,
        V_APPARENT_MIN,
    )

    assert C_SOUND_HOMOGENEOUS == 295.0
    assert FREQ_HIGH_MIN == 1.0
    assert FREQ_HIGH_MAX == 20.0
    assert DURATION_MAX == 5.0
    assert V_APPARENT_MIN == 800.0
    assert V_APPARENT_MAX == 1500.0
    assert CROSS_CORR_MIN == 0.7


def test_stations_maroc_complete():
    """Les 7 stations confirmées sont présentes."""
    from engines.seismic import STATIONS_MAROC

    expected = [
        "WM.IFR", "WM.CEU", "WM.PVLZ", "WM.AVE",
        "G.TAM", "TT.THTN", "IU.MACI", "IU.SACV",
    ]
    for code in expected:
        assert code in STATIONS_MAROC, f"Station {code} manquante"
        lat, lon, elev, url, year = STATIONS_MAROC[code]
        assert -90 <= lat <= 90, f"Lat invalide pour {code}"
        assert -180 <= lon <= 180, f"Lon invalide pour {code}"


def test_import_modules():
    """Tous les modules du pipeline s'importent."""
    from engines.seismic import acquisition  # noqa: F401
    from engines.seismic import preprocessing  # noqa: F401
    from engines.seismic import detection  # noqa: F401
    from engines.seismic import triangulation  # noqa: F401
    from engines.seismic import altitude  # noqa: F401
    from engines.seismic import energy  # noqa: F401
    from engines.seismic import pipeline  # noqa: F401


def test_dataclasses_instantiable():
    """Les dataclasses résultat sont instanciables."""
    from engines.seismic.acquisition import AcquisitionResult, StationData
    from engines.seismic.detection import CriteriaCheck, DetectionResult
    from engines.seismic.energy import EnergyMassResult, EnergyResult, MassResult
    from engines.seismic.triangulation import SourcePoint, TriangulationResult

    sd = StationData(
        station_code="WM.IFR", latitude=33.5, longitude=-5.1,
        elevation_m=1664.0, distance_km=100.0,
    )
    assert sd.success is False

    crit = CriteriaCheck(no_p_wave=True, short_duration=True,
                         similar_waveforms=True, low_apparent_velocity=True)
    assert crit.all_passed is True
    assert crit.score == 4

    src = SourcePoint(latitude=33.0, longitude=-6.0, altitude_m=30000.0)
    assert src.latitude == 33.0


def test_haversine_distance():
    """La fonction haversine est correcte."""
    from engines.seismic.acquisition import _haversine_km

    # Distance entre WM.IFR et WM.CEU
    d = _haversine_km(33.517, -5.127, 35.895, -5.281)
    # Distance réelle connue ~265 km
    assert 250 < d < 280, f"Distance attendue ~265 km, obtenue {d}"


def test_station_active_check():
    """Vérification d'activité des stations par date."""
    from obspy import UTCDateTime

    from engines.seismic.acquisition import _is_station_active

    # WM.IFR active depuis 2007
    assert _is_station_active("WM.IFR", UTCDateTime("2026-02-07")) is True
    assert _is_station_active("WM.IFR", UTCDateTime("2005-01-01")) is False

    # WM.AVE active 2007-2011 seulement
    assert _is_station_active("WM.AVE", UTCDateTime("2008-12-20")) is True
    assert _is_station_active("WM.AVE", UTCDateTime("2011-07-18")) is True
    assert _is_station_active("WM.AVE", UTCDateTime("2026-02-07")) is False


def test_energy_to_mass():
    """Conversion énergie → masse (formule 4.4)."""
    from engines.seismic.energy import _energy_to_mass

    # 1 kt TNT = 4.184e12 J
    # Pour 15 km/s : M = 2 * 4.184e12 / (15000)² = 37200 kg
    mass = _energy_to_mass(4.184e12, 15.0)
    assert 36000 < mass < 38000, f"Masse attendue ~37200 kg, obtenue {mass}"


def test_tiflet_coverage():
    """Tiflet 2026 : 3 stations actives à < 250 km."""
    from obspy import UTCDateTime

    from engines.seismic import STATIONS_MAROC
    from engines.seismic.acquisition import (
        _haversine_km,
        _is_station_active,
    )

    tiflet_lat, tiflet_lon = 33.89, -6.31
    event_time = UTCDateTime("2026-02-07T09:00:00")

    close_stations = []
    for code, (lat, lon, _elev, _url, _year) in STATIONS_MAROC.items():
        if _is_station_active(code, event_time):
            dist = _haversine_km(lat, lon, tiflet_lat, tiflet_lon)
            if dist < 300:
                close_stations.append((code, dist))

    assert len(close_stations) >= 3, (
        f"Tiflet doit avoir >=3 stations <300km, trouvé {len(close_stations)}"
    )


if __name__ == "__main__":
    # Exécution directe
    import traceback

    tests = [
        test_import_constants,
        test_stations_maroc_complete,
        test_import_modules,
        test_dataclasses_instantiable,
        test_haversine_distance,
        test_station_active_check,
        test_energy_to_mass,
        test_tiflet_coverage,
    ]
    passed, failed = 0, 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
            passed += 1
        except Exception:
            print(f"  ✗ {t.__name__}")
            traceback.print_exc()
            failed += 1
    print()
    print(f"Résultat : {passed} passés, {failed} échoués")
    sys.exit(0 if failed == 0 else 1)
