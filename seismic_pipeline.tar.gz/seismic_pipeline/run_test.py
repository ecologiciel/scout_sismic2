"""run_test.py -- Script de test du pipeline sismique sur les 3 cas marocains.

Usage :
    python run_test.py --case tamdakht
    python run_test.py --case tissint
    python run_test.py --case tiflet
    python run_test.py --case all

Génère :
    results/<case>/pipeline_result.json    — Résultats structurés
    results/<case>/waveforms_*.png         — Graphiques formes d'onde
    results/<case>/report.txt              — Rapport texte lisible

Chaque cas utilise les paramètres documentés dans :
    docs/PHASE_B1_FORMULES_MAITRES.md

Prérequis (sur VPS) :
    pip install obspy numpy scipy matplotlib

Point d'entrée unique pour validation opérationnelle du pipeline.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

# Ajouter le répertoire courant au PYTHONPATH pour les imports locaux
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Configuration logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("run_test")


# ─────────────────────────────────────────────────────────────────
# Configuration des 3 cas de test marocains
# ─────────────────────────────────────────────────────────────────

@dataclass
class TestCase:
    """Paramètres d'un cas de test."""

    name: str
    description: str
    event_time: str              # ISO UTC
    event_lat: float
    event_lon: float
    expected_lat: Optional[float] = None     # Vérité terrain si connue
    expected_lon: Optional[float] = None
    expected_altitude_km: Optional[float] = None
    expected_energy_kt: Optional[float] = None
    velocity_entry_kms: Optional[float] = None
    window_pre_s: int = 1800
    window_post_s: int = 1800
    require_all_criteria: bool = False   # Tolérant pour Tiflet (petite énergie)


TEST_CASES: dict[str, TestCase] = {
    "tamdakht": TestCase(
        name="tamdakht",
        description="Tamdakht 20 décembre 2008 — H5 chondrite, Haut-Atlas",
        event_time="2008-12-20T22:37:00",
        event_lat=31.163,      # Coordonnées réelles du strewn field
        event_lon=-7.015,
        expected_lat=31.163,
        expected_lon=-7.015,
        expected_altitude_km=30.0,     # Estimation typique
        velocity_entry_kms=None,        # Non documenté précisément
        window_pre_s=1800,
        window_post_s=1800,
    ),

    "tissint": TestCase(
        name="tissint",
        description="Tissint 18 juillet 2011 — Shergottite martien, Anti-Atlas",
        event_time="2011-07-18T02:00:00",
        event_lat=29.48,
        event_lon=-7.61,
        expected_lat=29.48,
        expected_lon=-7.61,
        expected_altitude_km=30.0,
        velocity_entry_kms=None,
        window_pre_s=1800,
        window_post_s=1800,
    ),

    "tiflet": TestCase(
        name="tiflet",
        description="Tiflet 7 février 2026 — Aubrite, région Khémisset (CAS PHARE)",
        event_time="2026-02-07T09:00:00",
        event_lat=33.89,
        event_lon=-6.31,
        expected_lat=33.89,            # Approximatif, Chennaoui confirme
        expected_lon=-6.31,
        expected_altitude_km=35.0,
        velocity_entry_kms=None,
        window_pre_s=1800,
        window_post_s=1800,
        require_all_criteria=False,    # Petite énergie peut ne pas passer C3
    ),
}


# ─────────────────────────────────────────────────────────────────
# Génération rapport texte
# ─────────────────────────────────────────────────────────────────

def generate_text_report(result_dict: dict, test_case: TestCase) -> str:
    """Génère un rapport texte lisible du résultat.

    Args:
        result_dict: Résultat sérialisé (depuis result_to_dict).
        test_case: Cas de test utilisé.

    Returns:
        Rapport texte formaté.
    """
    lines = []
    lines.append("=" * 75)
    lines.append(f"RAPPORT PIPELINE SISMIQUE — {test_case.name.upper()}")
    lines.append("=" * 75)
    lines.append("")
    lines.append(f"Cas : {test_case.description}")
    lines.append(f"Heure événement : {test_case.event_time}")
    lines.append(f"Position approx. : ({test_case.event_lat}°, {test_case.event_lon}°)")
    lines.append("")

    # Vérité terrain
    if test_case.expected_lat and test_case.expected_lon:
        lines.append("VÉRITÉ TERRAIN CONNUE :")
        lines.append(f"  Position : ({test_case.expected_lat}°, {test_case.expected_lon}°)")
        if test_case.expected_altitude_km:
            lines.append(f"  Altitude : ~{test_case.expected_altitude_km} km")
        lines.append("")

    # Statut global
    lines.append("STATUT DU PIPELINE :")
    lines.append(f"  Succès : {result_dict.get('success', False)}")
    lines.append(f"  Bolide confirmé : {result_dict.get('is_bolide', False)}")
    lines.append(f"  Confiance : {result_dict.get('confidence', 0.0):.2f}")
    lines.append(f"  Étapes complétées : {', '.join(result_dict.get('stages_completed', []))}")
    if result_dict.get("error_message"):
        lines.append(f"  ⚠ Message : {result_dict['error_message']}")
    lines.append("")

    # Stations
    if "stations" in result_dict:
        lines.append("STATIONS INTERROGÉES :")
        for s in result_dict["stations"]:
            status = "✓" if s["success"] else "✗"
            lines.append(
                f"  {status} {s['code']:<10} à {s['distance_km']:>6.1f} km   "
                f"{s.get('error', '')}"
            )
        lines.append("")

    # Détection
    if "detection" in result_dict:
        det = result_dict["detection"]
        lines.append("DÉTECTION (4 CRITÈRES OLIVIERI 2023) :")
        crit = det["criteria"]
        c1 = "✓" if crit["no_p_wave"] else "✗"
        c2 = "✓" if crit["short_duration"] else "✗"
        c3 = "✓" if crit["similar_waveforms"] else "✗"
        c4 = "✓" if crit["low_apparent_velocity"] else "✗"
        lines.append(f"  {c1} C1 — Absence onde P : v_max = {crit['max_velocity_kms']:.2f} km/s")
        lines.append(f"  {c2} C2 — Durée < 5 s : max = {crit['max_duration_s']:.2f} s")
        lines.append(f"  {c3} C3 — Corrélation > 0.7 : moyenne = {crit['mean_cross_correlation']:.3f}")
        lines.append(f"  {c4} C4 — Vitesse 800-1500 m/s : observée = {crit['apparent_velocity_ms']:.0f} m/s")
        lines.append("")
        lines.append("  Pics détectés par station :")
        for p in det["station_picks"]:
            if p["detected"]:
                lines.append(
                    f"    ✓ {p['station']:<10} pick={p['pick_time']}  "
                    f"amp={p['amplitude']:.2e}  dur={p['duration_s']:.1f}s  SNR={p['snr']:.1f}"
                )
            else:
                lines.append(f"    ✗ {p['station']:<10} pas de pick")
        lines.append("")

    # Triangulation
    if "triangulation" in result_dict:
        tri = result_dict["triangulation"]
        lines.append("TRIANGULATION :")
        lines.append(f"  Méthode : {tri['method']}")
        lines.append(f"  Nombre de stations utilisées : {tri['n_stations']}")
        lines.append(f"  RMS résidus : {tri['rms_residual_s']:.3f} s")
        lines.append(f"  Confiance : {tri['confidence']:.2f}")

        if tri.get("success") and "source" in tri:
            src = tri["source"]
            lines.append("")
            lines.append("  SOURCE CALCULÉE :")
            lines.append(f"    Latitude  : {src['lat']:.5f}° (± {src['uncertainty_lat_km']:.1f} km)")
            lines.append(f"    Longitude : {src['lon']:.5f}° (± {src['uncertainty_lon_km']:.1f} km)")
            lines.append(f"    Altitude  : {src['altitude_km']:.2f} km (± {src['uncertainty_alt_km']:.1f} km)")
            lines.append(f"    Heure UTC : {src['time_utc']}")

            # Comparaison avec vérité terrain
            if test_case.expected_lat and test_case.expected_lon:
                import math
                R = 6371.0
                dlat = math.radians(src["lat"] - test_case.expected_lat)
                dlon = math.radians(src["lon"] - test_case.expected_lon)
                a = (math.sin(dlat/2)**2
                     + math.cos(math.radians(src["lat"]))
                     * math.cos(math.radians(test_case.expected_lat))
                     * math.sin(dlon/2)**2)
                err_km = R * 2 * math.asin(math.sqrt(a))
                lines.append("")
                lines.append(f"  ÉCART / VÉRITÉ TERRAIN : {err_km:.2f} km")
                if err_km < 20:
                    lines.append("  ✅ VALIDATION RÉUSSIE (écart < 20 km)")
                elif err_km < 50:
                    lines.append("  🟡 VALIDATION ACCEPTABLE (écart < 50 km)")
                else:
                    lines.append("  🔴 VALIDATION ÉCHOUÉE (écart trop élevé)")
        lines.append("")

    # Altitude
    if "altitude" in result_dict:
        alt = result_dict["altitude"]
        lines.append("ALTITUDE :")
        lines.append(f"  Estimée : {alt['altitude_km']:.2f} km (± {alt['uncertainty_km']:.1f} km)")
        lines.append(f"  Plausibilité : {alt['plausibility_score']:.2f}")
        if alt.get("warning"):
            lines.append(f"  ⚠ {alt['warning']}")
        lines.append("")

    # Énergie/masse
    if "energy_mass" in result_dict:
        em = result_dict["energy_mass"]
        lines.append("ÉNERGIE / MASSE :")
        lines.append(f"  Énergie : {em['energy_kt_tnt']:.3e} kt TNT")
        lines.append(f"           = {em['energy_joules']:.3e} J")
        lines.append(f"  Période dominante : {em['period_s']:.3f} s")
        if em.get("below_detection_threshold"):
            lines.append("  ⚠ SOUS seuil de détection (Brown 2007)")
        lines.append("")
        lines.append("  Masse estimée par vitesse d'entrée :")
        for v, m in em.get("mass_by_velocity", {}).items():
            lines.append(f"    V = {v} km/s  →  M = {m:.2f} kg")
        lines.append("")

    # DFMC input
    if "dfmc_input" in result_dict:
        dfmc = result_dict["dfmc_input"]
        lines.append("SORTIE POUR MOTEUR DFMC :")
        lines.append(f"  lat = {dfmc['lat']:.5f}°")
        lines.append(f"  lon = {dfmc['lon']:.5f}°")
        lines.append(f"  alt_m = {dfmc['alt_m']:.0f} m")
        lines.append(f"  velocity_kms = {dfmc['velocity_kms']}")
        lines.append(f"  energy_kt = {dfmc['energy_kt']:.3e}")
        lines.append(f"  → Prêt à injecter dans DFMC pour calcul strewn field")
        lines.append("")

    lines.append("=" * 75)
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────
# Génération graphiques
# ─────────────────────────────────────────────────────────────────

def generate_plots(result, output_dir: Path) -> None:
    """Génère des graphiques PNG des formes d'onde.

    Args:
        result: SeismicPipelineResult.
        output_dir: Répertoire de sortie.
    """
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib non installé — pas de graphiques")
        return

    if not result.preprocessing:
        return

    for station in result.preprocessing.successful_stations:
        from engines.seismic.preprocessing import get_vertical_trace

        tr_raw = get_vertical_trace(station.stream_raw)
        tr_high = get_vertical_trace(station.stream_highfreq)
        tr_low = get_vertical_trace(station.stream_lowfreq)

        if tr_raw is None:
            continue

        fig, axes = plt.subplots(3, 1, figsize=(14, 8), sharex=True)

        # Temps relatif
        def plot_trace(ax, tr, label, color):
            if tr is None:
                return
            t = [i / tr.stats.sampling_rate for i in range(len(tr.data))]
            ax.plot(t, tr.data, color=color, linewidth=0.5)
            ax.set_ylabel(label)
            ax.grid(True, alpha=0.3)

        plot_trace(axes[0], tr_raw, "Raw", "black")
        plot_trace(axes[1], tr_high, "Band 1-20 Hz\n(N-wave)", "red")
        plot_trace(axes[2], tr_low, "Band 0.5-4 Hz\n(Rayleigh)", "blue")

        axes[2].set_xlabel("Temps (s) depuis début fenêtre")
        axes[0].set_title(
            f"{station.station_code} — Distance {station.distance_km:.0f} km"
        )

        # Marquer le pick si détecté
        if result.detection:
            for det in result.detection.successful_detections:
                if det.station_code == station.station_code and det.pick_time:
                    pick_t = float(det.pick_time - tr_raw.stats.starttime)
                    for ax in axes:
                        ax.axvline(pick_t, color="green", linestyle="--",
                                   alpha=0.7, label="Pick")
                    axes[0].legend(loc="upper right")
                    break

        fig.tight_layout()
        output_path = output_dir / f"waveform_{station.station_code.replace('.', '_')}.png"
        fig.savefig(output_path, dpi=100, bbox_inches="tight")
        plt.close(fig)
        logger.info("  Graphique sauvé : %s", output_path)


# ─────────────────────────────────────────────────────────────────
# Point d'entrée principal
# ─────────────────────────────────────────────────────────────────

def run_single_case(case_name: str, output_dir: Path) -> bool:
    """Exécute le pipeline pour un cas unique.

    Args:
        case_name: Nom du cas (doit être dans TEST_CASES).
        output_dir: Répertoire racine de sortie.

    Returns:
        True si succès, False sinon.
    """
    if case_name not in TEST_CASES:
        logger.error("Cas inconnu : %s (disponibles : %s)",
                     case_name, list(TEST_CASES.keys()))
        return False

    test_case = TEST_CASES[case_name]
    case_dir = output_dir / case_name
    case_dir.mkdir(parents=True, exist_ok=True)

    logger.info("")
    logger.info("#" * 75)
    logger.info("# CAS DE TEST : %s", test_case.name.upper())
    logger.info("# %s", test_case.description)
    logger.info("#" * 75)

    from engines.seismic.pipeline import (
        result_to_dict,
        run_seismic_pipeline,
    )

    result = run_seismic_pipeline(
        event_time=test_case.event_time,
        event_lat_approx=test_case.event_lat,
        event_lon_approx=test_case.event_lon,
        velocity_entry_kms=test_case.velocity_entry_kms,
        window_pre=test_case.window_pre_s,
        window_post=test_case.window_post_s,
        require_all_criteria=test_case.require_all_criteria,
    )

    # Sérialisation JSON
    result_dict = result_to_dict(result)
    json_path = case_dir / "pipeline_result.json"
    with open(json_path, "w") as f:
        json.dump(result_dict, f, indent=2, default=str)
    logger.info("Résultats JSON sauvés : %s", json_path)

    # Rapport texte
    report = generate_text_report(result_dict, test_case)
    report_path = case_dir / "report.txt"
    with open(report_path, "w") as f:
        f.write(report)
    logger.info("Rapport texte sauvé : %s", report_path)

    # Affichage console
    print()
    print(report)

    # Graphiques
    generate_plots(result, case_dir)

    return result.success


def main():
    parser = argparse.ArgumentParser(
        description="Test du pipeline sismique Meteorite Scout AI",
    )
    parser.add_argument(
        "--case",
        choices=list(TEST_CASES.keys()) + ["all"],
        default="all",
        help="Cas à tester (tamdakht, tissint, tiflet, ou all)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("./results"),
        help="Répertoire de sortie (défaut : ./results)",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Logs détaillés DEBUG",
    )
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    args.output_dir.mkdir(parents=True, exist_ok=True)

    cases_to_run = list(TEST_CASES.keys()) if args.case == "all" else [args.case]

    results_summary = {}
    for case_name in cases_to_run:
        try:
            success = run_single_case(case_name, args.output_dir)
            results_summary[case_name] = success
        except KeyboardInterrupt:
            logger.warning("Interruption utilisateur")
            break
        except Exception as exc:
            logger.exception("Exception pour cas %s", case_name)
            results_summary[case_name] = False

    # Résumé final
    print()
    print("=" * 75)
    print("RÉSUMÉ DE LA VALIDATION")
    print("=" * 75)
    for case_name, success in results_summary.items():
        status = "✅ SUCCÈS" if success else "❌ ÉCHEC"
        print(f"  {case_name:<12} : {status}")
    print()
    print(f"Résultats détaillés dans : {args.output_dir.absolute()}")
    print("=" * 75)

    return 0 if all(results_summary.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
