"""engines/seismic/triangulation.py -- Localisation de la source bolide.

Étape 4 du pipeline sismique (cf. docs/PHASE_B1_FORMULES_MAITRES.md Ch. 2).

Deux méthodes implémentées :
  - Isochrones (Roubeche 2024) : pour 3+ stations
  - Back-azimut par beamforming (Olivieri 2023) : méthode alternative

La méthode principale est la minimisation des résidus de temps d'arrivée
(Olivieri 2023 formule 2.3.b) : on cherche la trajectoire 3D qui minimise
la somme des carrés des écarts entre temps observés et temps théoriques.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from obspy import UTCDateTime
from scipy.optimize import minimize

from engines.seismic import (
    C_SOUND_HOMOGENEOUS,
    NB_STATIONS_DEGRADED,
    NB_STATIONS_OPTIMAL,
    NB_STATIONS_STANDARD,
)
from engines.seismic.detection import DetectionResult, StationDetection

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────
# Dataclasses résultat
# ─────────────────────────────────────────────────────────────────

@dataclass
class SourcePoint:
    """Point source 3D d'un bolide (fragmentation ou Mach cone)."""

    latitude: float
    longitude: float
    altitude_m: float
    time_utc: Optional[UTCDateTime] = None

    # Incertitudes (1 sigma)
    uncertainty_lat_km: float = 0.0
    uncertainty_lon_km: float = 0.0
    uncertainty_alt_km: float = 0.0


@dataclass
class TriangulationResult:
    """Résultat de la triangulation."""

    source: Optional[SourcePoint] = None
    method_used: str = ""                # "isochrones", "back_azimuth", "degraded"
    n_stations_used: int = 0
    residuals_s: list[float] = field(default_factory=list)
    rms_residual_s: float = 0.0
    success: bool = False
    confidence: float = 0.0              # 0-1
    error_message: str = ""


# ─────────────────────────────────────────────────────────────────
# Fonctions géométriques
# ─────────────────────────────────────────────────────────────────

def _lat_lon_alt_to_xyz(
    lat: float, lon: float, alt_m: float,
) -> tuple[float, float, float]:
    """Convertit (lat, lon, alt) en coordonnées cartésiennes ECEF.

    Args:
        lat: Latitude (degrés).
        lon: Longitude (degrés).
        alt_m: Altitude au-dessus du géoïde (mètres).

    Returns:
        (x, y, z) en mètres.
    """
    R_EARTH = 6371000.0  # m

    phi = math.radians(lat)
    lam = math.radians(lon)
    r = R_EARTH + alt_m

    x = r * math.cos(phi) * math.cos(lam)
    y = r * math.cos(phi) * math.sin(lam)
    z = r * math.sin(phi)
    return x, y, z


def _distance_3d(
    lat1: float, lon1: float, alt1: float,
    lat2: float, lon2: float, alt2: float,
) -> float:
    """Distance 3D entre deux points géographiques (mètres).

    Utilise une projection ECEF pour calculer la distance directe.

    Args:
        lat1, lon1, alt1: Point 1 (degrés, degrés, mètres).
        lat2, lon2, alt2: Point 2.

    Returns:
        Distance 3D en mètres.
    """
    x1, y1, z1 = _lat_lon_alt_to_xyz(lat1, lon1, alt1)
    x2, y2, z2 = _lat_lon_alt_to_xyz(lat2, lon2, alt2)
    return math.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)


def _travel_time_theoretical(
    source_lat: float,
    source_lon: float,
    source_alt_m: float,
    source_time: float,            # secondes depuis t0 de référence
    station_lat: float,
    station_lon: float,
    station_alt_m: float,
    c_sound: float = C_SOUND_HOMOGENEOUS,
) -> float:
    """Calcule le temps d'arrivée théorique à une station.

    Formule 2.3.a du doc maître B1 :
        t_i_calc = t0 + d_i(trajectoire) / c_son

    Modèle d'atmosphère homogène (Olivieri 2023) :
    vitesse du son constante à 295 m/s par défaut.

    Args:
        source_lat, source_lon, source_alt_m: Position source.
        source_time: Temps de la source (secondes relatif).
        station_lat, station_lon, station_alt_m: Position station.
        c_sound: Vitesse du son (m/s).

    Returns:
        Temps d'arrivée théorique à la station (secondes).
    """
    distance = _distance_3d(
        source_lat, source_lon, source_alt_m,
        station_lat, station_lon, station_alt_m,
    )
    return source_time + (distance / c_sound)


# ─────────────────────────────────────────────────────────────────
# Minimisation des résidus (méthode principale)
# ─────────────────────────────────────────────────────────────────

def _residuals_function(
    params: np.ndarray,
    station_data: list[tuple[float, float, float, float]],
    c_sound: float,
) -> float:
    """Fonction objectif à minimiser.

    Somme des carrés des résidus entre temps observés et calculés.

    Args:
        params: [lat, lon, alt_m, t0_relative] de la source candidate.
        station_data: Liste de (lat, lon, alt_m, t_observed_relative).
        c_sound: Vitesse du son.

    Returns:
        Somme des carrés des résidus (à minimiser).
    """
    src_lat, src_lon, src_alt, src_t0 = params
    residuals_sq = 0.0

    for st_lat, st_lon, st_alt, t_obs in station_data:
        t_calc = _travel_time_theoretical(
            src_lat, src_lon, src_alt, src_t0,
            st_lat, st_lon, st_alt,
            c_sound=c_sound,
        )
        residuals_sq += (t_obs - t_calc) ** 2

    return residuals_sq


def _triangulate_isochrones(
    detections: list[StationDetection],
    c_sound: float = C_SOUND_HOMOGENEOUS,
    initial_altitude_m: float = 35000.0,
) -> TriangulationResult:
    """Triangulation par minimisation des résidus (méthode 3+ stations).

    Référence : Olivieri 2023 Sect. Results, Fig. 5.

    Args:
        detections: Au moins 3 stations avec pick_time.
        c_sound: Vitesse du son (m/s).
        initial_altitude_m: Altitude de départ pour l'optimisation.

    Returns:
        TriangulationResult avec source 3D + résidus.
    """
    result = TriangulationResult(method_used="isochrones")

    successful = [d for d in detections if d.detected and d.pick_time]
    if len(successful) < NB_STATIONS_OPTIMAL:
        result.error_message = (
            f"Insuffisant : {len(successful)} stations (min {NB_STATIONS_OPTIMAL})"
        )
        return result

    # Référence temporelle = première arrivée
    t_ref = min(d.pick_time for d in successful)

    # Construire station_data : (lat, lon, alt_m, t_obs_relatif)
    station_data = []
    for d in successful:
        # Récupérer altitude station depuis STATIONS_MAROC
        from engines.seismic import STATIONS_MAROC
        if d.station_code in STATIONS_MAROC:
            station_alt = STATIONS_MAROC[d.station_code][2]
        else:
            station_alt = 0.0
        t_obs = float(d.pick_time - t_ref)
        station_data.append((d.latitude, d.longitude, station_alt, t_obs))

    # Point de départ : centroïde des stations, altitude initiale
    mean_lat = np.mean([d[0] for d in station_data])
    mean_lon = np.mean([d[1] for d in station_data])
    x0 = np.array([mean_lat, mean_lon, initial_altitude_m, 0.0])

    # Bornes
    lat_range = 2.0  # degrés autour du centroïde
    lon_range = 2.0
    bounds = [
        (mean_lat - lat_range, mean_lat + lat_range),
        (mean_lon - lon_range, mean_lon + lon_range),
        (10000.0, 80000.0),      # Altitude 10-80 km
        (-120.0, 120.0),          # t0 dans ±2 min autour de t_ref
    ]

    logger.info(
        "Optimisation triangulation : %d stations, c_sound=%.0f m/s",
        len(successful), c_sound,
    )

    try:
        opt_result = minimize(
            _residuals_function,
            x0=x0,
            args=(station_data, c_sound),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 500, "ftol": 1e-6},
        )

        if not opt_result.success:
            logger.warning("Optimisation non convergée : %s", opt_result.message)

        src_lat, src_lon, src_alt, src_t0 = opt_result.x

        # Calcul des résidus individuels
        residuals = []
        for st_lat, st_lon, st_alt, t_obs in station_data:
            t_calc = _travel_time_theoretical(
                src_lat, src_lon, src_alt, src_t0,
                st_lat, st_lon, st_alt, c_sound=c_sound,
            )
            residuals.append(t_obs - t_calc)

        rms = float(np.sqrt(np.mean(np.array(residuals) ** 2)))

        # Temps absolu de la source
        source_time = t_ref + src_t0

        # Confiance inversement proportionnelle au RMS
        # RMS < 1s = excellent, RMS > 10s = mauvais
        confidence = float(max(0.0, min(1.0, 1.0 - rms / 10.0)))

        result.source = SourcePoint(
            latitude=float(src_lat),
            longitude=float(src_lon),
            altitude_m=float(src_alt),
            time_utc=source_time,
            # Incertitudes approximatives (à raffiner avec bootstrap)
            uncertainty_lat_km=float(rms * c_sound / 1000.0 / 2),
            uncertainty_lon_km=float(rms * c_sound / 1000.0 / 2),
            uncertainty_alt_km=float(rms * c_sound / 1000.0 / 2),
        )
        result.n_stations_used = len(successful)
        result.residuals_s = residuals
        result.rms_residual_s = rms
        result.success = True
        result.confidence = confidence

        logger.info(
            "  ✓ Source : (%.3f°, %.3f°, %.0f m) à %s",
            src_lat, src_lon, src_alt, source_time,
        )
        logger.info("    RMS résidus = %.2f s, confidence = %.2f", rms, confidence)

    except Exception as exc:
        logger.exception("Échec optimisation")
        result.error_message = f"Exception optimisation : {exc}"

    return result


# ─────────────────────────────────────────────────────────────────
# Mode dégradé 2 stations
# ─────────────────────────────────────────────────────────────────

def _triangulate_partial_2_stations(
    detections: list[StationDetection],
    c_sound: float = C_SOUND_HOMOGENEOUS,
    assumed_altitude_m: float = 35000.0,
) -> TriangulationResult:
    """Triangulation partielle avec 2 stations + altitude supposée.

    En l'absence de 3ème station, on fixe l'altitude et on résout en 2D.

    Args:
        detections: Exactement 2 stations avec pick_time.
        c_sound: Vitesse du son.
        assumed_altitude_m: Altitude supposée (défaut 35 km = El-Hakimia).

    Returns:
        TriangulationResult avec confidence réduite.
    """
    result = TriangulationResult(method_used="partial_2_stations")

    successful = [d for d in detections if d.detected and d.pick_time]
    if len(successful) != NB_STATIONS_STANDARD:
        result.error_message = f"Nécessite 2 stations exactement, reçu {len(successful)}"
        return result

    t_ref = min(d.pick_time for d in successful)

    from engines.seismic import STATIONS_MAROC

    station_data = []
    for d in successful:
        if d.station_code in STATIONS_MAROC:
            station_alt = STATIONS_MAROC[d.station_code][2]
        else:
            station_alt = 0.0
        t_obs = float(d.pick_time - t_ref)
        station_data.append((d.latitude, d.longitude, station_alt, t_obs))

    # Point de départ : centroïde
    mean_lat = np.mean([d[0] for d in station_data])
    mean_lon = np.mean([d[1] for d in station_data])
    x0 = np.array([mean_lat, mean_lon, 0.0])  # altitude fixée

    def obj_2d(params, st_data, c, alt_fixed):
        src_lat, src_lon, src_t0 = params
        residuals_sq = 0.0
        for st_lat, st_lon, st_alt, t_obs in st_data:
            t_calc = _travel_time_theoretical(
                src_lat, src_lon, alt_fixed, src_t0,
                st_lat, st_lon, st_alt, c_sound=c,
            )
            residuals_sq += (t_obs - t_calc) ** 2
        return residuals_sq

    bounds = [
        (mean_lat - 2.0, mean_lat + 2.0),
        (mean_lon - 2.0, mean_lon + 2.0),
        (-120.0, 120.0),
    ]

    try:
        opt = minimize(
            obj_2d, x0, args=(station_data, c_sound, assumed_altitude_m),
            method="L-BFGS-B", bounds=bounds,
        )
        src_lat, src_lon, src_t0 = opt.x
        residuals = []
        for st_lat, st_lon, st_alt, t_obs in station_data:
            t_calc = _travel_time_theoretical(
                src_lat, src_lon, assumed_altitude_m, src_t0,
                st_lat, st_lon, st_alt, c_sound=c_sound,
            )
            residuals.append(t_obs - t_calc)
        rms = float(np.sqrt(np.mean(np.array(residuals) ** 2)))

        result.source = SourcePoint(
            latitude=float(src_lat),
            longitude=float(src_lon),
            altitude_m=assumed_altitude_m,
            time_utc=t_ref + src_t0,
            uncertainty_lat_km=25.0,   # Plus élevé avec 2 stations
            uncertainty_lon_km=25.0,
            uncertainty_alt_km=20.0,
        )
        result.n_stations_used = 2
        result.residuals_s = residuals
        result.rms_residual_s = rms
        result.success = True
        result.confidence = float(max(0.0, min(0.6, 0.6 - rms / 20.0)))

        logger.info(
            "  ✓ Mode 2-stations : (%.3f°, %.3f°, %.0f m) confidence=%.2f",
            src_lat, src_lon, assumed_altitude_m, result.confidence,
        )

    except Exception as exc:
        result.error_message = f"Exception 2-stations : {exc}"

    return result


# ─────────────────────────────────────────────────────────────────
# Mode dégradé 1 station
# ─────────────────────────────────────────────────────────────────

def _triangulate_degraded_1_station(
    detections: list[StationDetection],
) -> TriangulationResult:
    """Mode très dégradé avec 1 seule station.

    Sans back-azimut (pas d'array infrasound), seule l'information
    "le bolide est sur un cercle de rayon R autour de la station"
    est disponible. Retourne la position de la station avec grande
    incertitude.

    Args:
        detections: Exactement 1 station.

    Returns:
        TriangulationResult avec confidence très faible.
    """
    result = TriangulationResult(method_used="degraded_1_station")

    successful = [d for d in detections if d.detected and d.pick_time]
    if len(successful) != NB_STATIONS_DEGRADED:
        result.error_message = "Nécessite exactement 1 station"
        return result

    d = successful[0]

    # La position probable est sur un cercle autour de la station
    # Le rayon dépend du délai d'arrivée et de la vitesse du son
    # Sans autre info, on retourne la station avec alerte

    result.source = SourcePoint(
        latitude=d.latitude,
        longitude=d.longitude,
        altitude_m=30000.0,            # Altitude typique fragmentation
        time_utc=d.pick_time,
        uncertainty_lat_km=100.0,      # TRÈS élevée
        uncertainty_lon_km=100.0,
        uncertainty_alt_km=30.0,
    )
    result.n_stations_used = 1
    result.success = True
    result.confidence = 0.2            # Faible par construction

    logger.warning(
        "  ⚠ Mode 1-station dégradé : %s (rayon incertain ~100 km)",
        d.station_code,
    )
    return result


# ─────────────────────────────────────────────────────────────────
# Fonction publique principale
# ─────────────────────────────────────────────────────────────────

def triangulate(
    detection_result: DetectionResult,
    c_sound: float = C_SOUND_HOMOGENEOUS,
    require_criteria_passed: bool = False,
) -> TriangulationResult:
    """Triangule la source du bolide à partir des détections.

    Sélectionne automatiquement la méthode selon le nombre de stations :
      - 3+ stations → isochrones (précision 5-15 km)
      - 2 stations → partiel avec altitude supposée (précision 15-50 km)
      - 1 station → dégradé (précision >100 km)

    Args:
        detection_result: Résultat de detect_bolide_signature.
        c_sound: Vitesse du son (m/s).
        require_criteria_passed: Si True, échoue si les 4 critères ne sont
            pas tous satisfaits. Défaut False (permet validation Tiflet
            même si petite énergie ne passe pas tous les critères).

    Returns:
        TriangulationResult avec source 3D si succès.
    """
    if require_criteria_passed and not detection_result.is_bolide:
        return TriangulationResult(
            success=False,
            error_message="4 critères bolide non satisfaits",
        )

    successful = detection_result.successful_detections
    n_stations = len(successful)

    logger.info("Triangulation avec %d stations...", n_stations)

    if n_stations >= NB_STATIONS_OPTIMAL:
        return _triangulate_isochrones(successful, c_sound=c_sound)
    elif n_stations == NB_STATIONS_STANDARD:
        return _triangulate_partial_2_stations(successful, c_sound=c_sound)
    elif n_stations == NB_STATIONS_DEGRADED:
        return _triangulate_degraded_1_station(successful)
    else:
        return TriangulationResult(
            success=False,
            error_message="Aucune station avec pick détecté",
        )
