"""engines/seismic — Pipeline de détection et triangulation sismique de bolides.

Moteur unique partagé par les nœuds MANUAL_FALL, AUTO_SEISMIC et
ARCHEO_SEISMIC du graphe LangGraph Meteorite Scout AI.

Implémente la méthodologie extraite des publications :
  - Olivieri et al. (2023)  — Italie 61 stations
  - Roubeche et al. (2024)  — El-Hakimia 14 stations
  - Andrade et al. (2023)   — Traspena 3 stations

Référence formules : docs/PHASE_B1_FORMULES_MAITRES.md

Pipeline à 7 étapes :
  1. Acquisition FDSN           → acquisition.fetch_waveforms()
  2. Prétraitement              → preprocessing.preprocess_stream()
  3. Détection signature        → detection.detect_bolide_signature()
  4. Triangulation              → triangulation.triangulate()
  5. Altitude fragmentation     → altitude.estimate_altitude()
  6. Énergie / masse            → energy.estimate_energy_mass()
  7. Injection DFMC             → pipeline.to_dfmc_input()
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────────
# CONSTANTES PHYSIQUES (Chapitre 4 du doc maître B1)
# ─────────────────────────────────────────────────────────────────

# Vitesse du son (m/s)
C_SOUND_SEA_LEVEL: float = 336.0       # Atmosphère standard niveau mer
C_SOUND_HOMOGENEOUS: float = 295.0     # Modèle homogène Olivieri 2023

# Vitesse des ondes Rayleigh couplées (m/s)
V_RAYLEIGH: float = 2000.0             # Olivieri 2023 Ch. 3

# Vitesse apparente attendue signature bolide (m/s)
V_APPARENT_MIN: float = 800.0          # Ch. 1 critère 4
V_APPARENT_MAX: float = 1500.0
V_APPARENT_EXPECTED: float = 1150.0    # Olivieri 2023

# Densités météoroïdes par type (kg/m³)
RHO_CHONDRITE: float = 3300.0          # Ordinaire (défaut)
RHO_CHONDRITE_L5: float = 3500.0       # Andrade 2023 Traspena
RHO_ACHONDRITE: float = 3000.0
RHO_IRON: float = 7800.0

# ─────────────────────────────────────────────────────────────────
# FILTRAGE FRÉQUENTIEL (Chapitre 1)
# ─────────────────────────────────────────────────────────────────

# Bande haute (onde de choc directe, N-wave / W-wave)
FREQ_HIGH_MIN: float = 1.0             # Hz — Olivieri 2023
FREQ_HIGH_MAX: float = 20.0            # Hz
FREQ_HIGHPASS_MIN: float = 3.0         # Hz — Andrade 2023 (passe-haut alternatif)

# Bande basse (ondes Rayleigh couplées)
FREQ_LOW_MIN: float = 0.5              # Hz — Olivieri 2023
FREQ_LOW_MAX: float = 4.0              # Hz

# Bande beamforming infrasound array
FREQ_BEAMFORMING_MIN: float = 1.0      # Hz
FREQ_BEAMFORMING_MAX: float = 10.0     # Hz

# ─────────────────────────────────────────────────────────────────
# DÉTECTION (Chapitre 1)
# ─────────────────────────────────────────────────────────────────

# Durée maximale du train d'onde bolide (s)
DURATION_MAX: float = 5.0              # Ch. 1 critère 2

# Seuil de cross-corrélation inter-stations
CROSS_CORR_MIN: float = 0.7            # Ch. 1 critère 3

# Vitesse ondes P (à exclure pour détection bolide)
V_P_WAVE_MIN: float = 5000.0           # m/s — si détecté, c'est un séisme

# ─────────────────────────────────────────────────────────────────
# BEAMFORMING (Chapitre 2)
# ─────────────────────────────────────────────────────────────────

BEAMFORMING_WINDOW_LENGTH: float = 5.0  # s — Olivieri 2023
BEAMFORMING_WINDOW_OVERLAP: float = 0.95  # 95% overlap

# ─────────────────────────────────────────────────────────────────
# ÉNERGIE (Chapitre 4)
# ─────────────────────────────────────────────────────────────────

# Seuil de détection infrasound (kt TNT)
E_DETECTION_MIN: float = 6e-5          # Brown 2007, cité Pilger 2021
E_DETECTION_OPERATIONAL: float = 1e-3  # Seuil pratique pipeline

# Conversion kt TNT → Joules
KT_TNT_TO_JOULES: float = 4.184e12

# Coefficient de traînée par défaut
GAMMA_DRAG_DEFAULT: float = 1.0        # Sphère

# Coefficient d'ablation chondrites (s²/km²)
SIGMA_ABLATION_CHONDRITE: float = 0.014

# ─────────────────────────────────────────────────────────────────
# CONFIGURATION FDSN (Chapitre 8)
# ─────────────────────────────────────────────────────────────────

# Fenêtre de recherche autour de l'heure estimée (secondes)
FDSN_WINDOW_PRE: int = 1800            # 30 min avant
FDSN_WINDOW_POST: int = 1800           # 30 min après

# Canaux à télécharger
FDSN_CHANNELS_BROADBAND: str = "BH*"   # BHZ, BHE, BHN (broadband)
FDSN_CHANNELS_HIGH_GAIN: str = "HH*"   # Alternative haute sensibilité

# Fréquence d'échantillonnage attendue
SAMPLING_RATE_DEFAULT: int = 100       # Hz — Andrade 2023

# ─────────────────────────────────────────────────────────────────
# STATIONS SISMIQUES PUBLIQUES CONFIRMÉES EMPIRIQUEMENT
# ─────────────────────────────────────────────────────────────────

# Format : code → (latitude, longitude, elevation_m, data_center_url, start_year)
STATIONS_MAROC: dict[str, tuple[float, float, float, str, int | None]] = {
    # Réseau WM — GEOFON (actif depuis 2007 pour les 3 nord)
    "WM.IFR":  (33.517, -5.127, 1664.0, "https://geofon.gfz-potsdam.de", 2007),
    "WM.CEU":  (35.895, -5.281,  320.0, "https://geofon.gfz-potsdam.de", 2007),
    "WM.PVLZ": (35.173, -4.300,  152.0, "https://geofon.gfz-potsdam.de", 2007),
    # WM.AVE : Averroes Rabat — FERMÉE novembre 2011 mais couvre Tamdakht 2008
    "WM.AVE":  (34.000, -6.833,  100.0, "https://geofon.gfz-potsdam.de", None),

    # Réseau G — GEOSCOPE / IPGP (station TAM Sahara algérien)
    "G.TAM":   (22.791,  5.528, 1410.0, "https://ws.ipgp.fr", 1983),

    # Réseau TT — IRIS (station Thala Tunisie)
    "TT.THTN": (35.562,  8.688, 1095.0, "https://service.iris.edu", 2010),

    # Réseau IU — Global Seismographic Network (couverture Sahara occidental)
    "IU.MACI": (28.250, -16.508, 1674.0, "https://service.iris.edu", 2008),
    "IU.SACV": (14.970, -23.610,  400.0, "https://service.iris.edu", 2000),
    # IU.PAB et IU.TOL : Espagne centrale, couvrent le Maroc Nord/Centre
    # Découvertes empiriquement via EarthScope 2026-04-22, ouvertes sans auth
    "IU.PAB":  (39.540,  -4.350, 945.0,  "https://service.iris.edu", 1993),
    "IU.TOL":  (39.880,  -4.050, 480.0,  "https://service.iris.edu", None),
}

# Clients FDSN par data center
FDSN_CLIENTS: dict[str, str] = {
    "GEOFON": "http://geofon.gfz-potsdam.de",
    "IPGP":   "http://ws.ipgp.fr",
    "IRIS":   "http://service.iris.edu",
}

# Mapping station → data center (pour sélection automatique du client)
STATION_TO_CLIENT: dict[str, str] = {
    "WM.IFR":  "GEOFON",
    "WM.CEU":  "GEOFON",
    "WM.PVLZ": "GEOFON",
    "WM.AVE":  "GEOFON",
    "G.TAM":   "IPGP",
    "TT.THTN": "IRIS",
    "IU.MACI": "IRIS",
    "IU.SACV": "IRIS",
    "IU.PAB":  "IRIS",
    "IU.TOL":  "IRIS",
}

# ─────────────────────────────────────────────────────────────────
# SEUILS DE COUVERTURE (Chapitre 8.2)
# ─────────────────────────────────────────────────────────────────

# Distance maximale pour considérer une station comme "proche"
DISTANCE_PROCHE_KM: float = 500.0

# Distance maximale pour inclusion dans la triangulation
DISTANCE_MAX_TRIANGULATION_KM: float = 1500.0

# Nombre minimum de stations pour chaque configuration
NB_STATIONS_OPTIMAL: int = 3           # Triangulation complète
NB_STATIONS_STANDARD: int = 2          # Triangulation partielle
NB_STATIONS_DEGRADED: int = 1          # Back-azimut seul
