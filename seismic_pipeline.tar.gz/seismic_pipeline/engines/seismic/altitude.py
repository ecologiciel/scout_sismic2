"""engines/seismic/altitude.py -- Raffinement de l'altitude de fragmentation.

Étape 5 du pipeline sismique (cf. docs/PHASE_B1_FORMULES_MAITRES.md Ch. 5).

L'altitude est déjà estimée par la triangulation 3D (engines.seismic.triangulation).
Ce module ajoute :
  - Correction des résidus par propagation stratifiée (si profil ERA5 disponible)
  - Validation de plausibilité physique (altitude typique 20-80 km)
  - Estimation d'incertitude par bootstrap sur les temps d'arrivée
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from engines.seismic.triangulation import SourcePoint, TriangulationResult

logger = logging.getLogger(__name__)

# Altitudes typiques de fragmentation de bolides (mètres)
ALTITUDE_TYPICAL_MIN_M: float = 15000.0  # 15 km (Traspena fin visible)
ALTITUDE_TYPICAL_MAX_M: float = 80000.0  # 80 km (début entrée atmosphère)
ALTITUDE_FRAGMENTATION_TYPICAL_M: float = 35000.0  # El-Hakimia


@dataclass
class AltitudeResult:
    """Résultat du raffinement d'altitude."""

    altitude_m: float
    uncertainty_km: float
    plausibility_score: float = 1.0      # 0-1, pénalise altitudes atypiques
    warning: str = ""


def estimate_altitude(
    triangulation: TriangulationResult,
) -> AltitudeResult:
    """Raffine et valide l'altitude de fragmentation.

    Dans cette version initiale, se limite à la validation de plausibilité
    et au report des incertitudes. Un raffinement ERA5 est prévu en phase
    ultérieure (cf. doc maître B1 Ch. 6).

    Args:
        triangulation: Résultat de la triangulation.

    Returns:
        AltitudeResult avec altitude validée.
    """
    if not triangulation.success or triangulation.source is None:
        return AltitudeResult(
            altitude_m=0.0,
            uncertainty_km=0.0,
            plausibility_score=0.0,
            warning="Triangulation échouée, altitude indisponible",
        )

    alt_m = triangulation.source.altitude_m

    # Score de plausibilité
    if ALTITUDE_TYPICAL_MIN_M <= alt_m <= ALTITUDE_TYPICAL_MAX_M:
        plausibility = 1.0
        warning = ""
    elif alt_m < 10000.0:
        plausibility = 0.3
        warning = f"Altitude anormalement basse ({alt_m/1000:.1f} km) — fragmentation < 15 km rare"
    elif alt_m > 90000.0:
        plausibility = 0.5
        warning = f"Altitude anormalement élevée ({alt_m/1000:.1f} km) — entrée typique < 80 km"
    else:
        plausibility = 0.7
        warning = f"Altitude limite ({alt_m/1000:.1f} km)"

    logger.info(
        "Altitude estimée : %.1f km (uncertainty %.1f km, plausibility %.2f)",
        alt_m / 1000.0, triangulation.source.uncertainty_alt_km, plausibility,
    )
    if warning:
        logger.warning(warning)

    return AltitudeResult(
        altitude_m=alt_m,
        uncertainty_km=triangulation.source.uncertainty_alt_km,
        plausibility_score=plausibility,
        warning=warning,
    )
