"""engines/seismic/preprocessing.py -- Prétraitement des formes d'onde.

Étape 2 du pipeline sismique (cf. docs/PHASE_B1_FORMULES_MAITRES.md Ch. 1).

Applique les transformations standards aux formes d'onde brutes :
  - Détrending (suppression tendance linéaire)
  - Retrait de la réponse instrumentale
  - Filtrage passe-bande selon deux bandes de fréquence
  - Préparation pour la détection

Référence formules : Olivieri 2023 (1-20 Hz, 0.5-4 Hz) + Andrade 2023 (3 Hz highpass).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

from obspy import Stream
from obspy.core.trace import Trace

from engines.seismic import (
    FREQ_HIGH_MAX,
    FREQ_HIGH_MIN,
    FREQ_HIGHPASS_MIN,
    FREQ_LOW_MAX,
    FREQ_LOW_MIN,
    SAMPLING_RATE_DEFAULT,
)
from engines.seismic.acquisition import AcquisitionResult, StationData

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────
# Dataclasses résultat
# ─────────────────────────────────────────────────────────────────

@dataclass
class PreprocessedStation:
    """Données prétraitées d'une station."""

    station_code: str
    latitude: float
    longitude: float
    distance_km: float
    stream_raw: Stream                 # Données brutes originales
    stream_highfreq: Stream            # Filtré bande haute (1-20 Hz)
    stream_lowfreq: Stream             # Filtré bande basse (0.5-4 Hz)
    stream_highpass: Stream            # Passe-haut 3 Hz (méthode Andrade)
    sampling_rate: float
    success: bool = True
    error_message: str = ""


@dataclass
class PreprocessingResult:
    """Résultat global du prétraitement."""

    stations: list[PreprocessedStation] = field(default_factory=list)

    @property
    def successful_stations(self) -> list[PreprocessedStation]:
        """Stations prétraitées avec succès."""
        return [s for s in self.stations if s.success]


# ─────────────────────────────────────────────────────────────────
# Fonctions internes
# ─────────────────────────────────────────────────────────────────

def _detrend_stream(stream: Stream) -> Stream:
    """Applique détrending linéaire à un stream.

    Args:
        stream: Stream ObsPy (modifié en place sur une copie).

    Returns:
        Nouveau stream avec détrending appliqué.
    """
    copy = stream.copy()
    copy.detrend(type="linear")
    copy.detrend(type="demean")
    return copy


def _remove_instrument_response(
    stream: Stream,
    client: Optional[object] = None,
) -> Stream:
    """Retire la réponse instrumentale (si métadonnées disponibles).

    Si le retrait échoue (pas d'inventory), retourne le stream inchangé
    avec un warning. Le pipeline peut fonctionner sans cette étape pour
    la détection (les formes relatives sont préservées).

    Args:
        stream: Stream à traiter.
        client: Client FDSN pour fetch inventory (optionnel).

    Returns:
        Stream avec réponse retirée ou inchangé si échec.
    """
    copy = stream.copy()
    try:
        if client is not None:
            # Approche idéale : fetch inventory via le client
            for tr in copy:
                inv = client.get_stations(
                    network=tr.stats.network,
                    station=tr.stats.station,
                    channel=tr.stats.channel,
                    location=tr.stats.location,
                    starttime=tr.stats.starttime,
                    endtime=tr.stats.endtime,
                    level="response",
                )
                tr.remove_response(inventory=inv, output="VEL")
        logger.debug("Réponse instrumentale retirée")
    except Exception as exc:
        logger.warning(
            "Retrait réponse instrumentale échoué (%s). "
            "Les formes relatives sont préservées, détection possible.",
            exc,
        )
    return copy


def _apply_bandpass(
    stream: Stream,
    freqmin: float,
    freqmax: float,
) -> Stream:
    """Applique un filtre passe-bande Butterworth.

    Args:
        stream: Stream à filtrer.
        freqmin: Fréquence minimale (Hz).
        freqmax: Fréquence maximale (Hz).

    Returns:
        Nouveau stream filtré.
    """
    copy = stream.copy()
    try:
        copy.filter(
            "bandpass",
            freqmin=freqmin,
            freqmax=freqmax,
            corners=4,
            zerophase=True,
        )
    except Exception as exc:
        logger.error(
            "Filtrage bandpass [%s, %s] Hz échoué : %s",
            freqmin, freqmax, exc,
        )
    return copy


def _apply_highpass(stream: Stream, freqmin: float) -> Stream:
    """Applique un filtre passe-haut (méthode Andrade 2023).

    Args:
        stream: Stream à filtrer.
        freqmin: Fréquence de coupure basse (Hz).

    Returns:
        Nouveau stream filtré.
    """
    copy = stream.copy()
    try:
        copy.filter(
            "highpass",
            freq=freqmin,
            corners=4,
            zerophase=True,
        )
    except Exception as exc:
        logger.error("Filtrage highpass %s Hz échoué : %s", freqmin, exc)
    return copy


def _get_sampling_rate(stream: Stream) -> float:
    """Retourne la fréquence d'échantillonnage du stream.

    Args:
        stream: Stream ObsPy.

    Returns:
        Fréquence d'échantillonnage (Hz) ou valeur par défaut si erreur.
    """
    if len(stream) == 0:
        return float(SAMPLING_RATE_DEFAULT)
    return float(stream[0].stats.sampling_rate)


# ─────────────────────────────────────────────────────────────────
# Fonctions publiques
# ─────────────────────────────────────────────────────────────────

def preprocess_station(station_data: StationData) -> PreprocessedStation:
    """Prétraite les formes d'onde d'une station unique.

    Applique la séquence :
      1. Détrending linéaire + demean
      2. (Optionnel) Retrait réponse instrumentale
      3. Filtrage bande haute (1-20 Hz) — signal direct Olivieri
      4. Filtrage bande basse (0.5-4 Hz) — ondes Rayleigh Olivieri
      5. Filtrage passe-haut (3 Hz) — méthode Andrade

    Args:
        station_data: Station avec stream brut téléchargé.

    Returns:
        PreprocessedStation avec les 3 versions filtrées.
    """
    if not station_data.success or station_data.stream is None:
        return PreprocessedStation(
            station_code=station_data.station_code,
            latitude=station_data.latitude,
            longitude=station_data.longitude,
            distance_km=station_data.distance_km,
            stream_raw=Stream(),
            stream_highfreq=Stream(),
            stream_lowfreq=Stream(),
            stream_highpass=Stream(),
            sampling_rate=0.0,
            success=False,
            error_message="Pas de données brutes disponibles",
        )

    logger.info("Prétraitement %s...", station_data.station_code)

    try:
        # Étape 1 : détrending
        stream_detrended = _detrend_stream(station_data.stream)

        # Étape 2 : filtrages parallèles
        stream_highfreq = _apply_bandpass(
            stream_detrended, FREQ_HIGH_MIN, FREQ_HIGH_MAX,
        )
        stream_lowfreq = _apply_bandpass(
            stream_detrended, FREQ_LOW_MIN, FREQ_LOW_MAX,
        )
        stream_highpass = _apply_highpass(stream_detrended, FREQ_HIGHPASS_MIN)

        sampling_rate = _get_sampling_rate(station_data.stream)

        logger.info(
            "  ✓ %s prétraité (sample rate = %.0f Hz)",
            station_data.station_code, sampling_rate,
        )

        return PreprocessedStation(
            station_code=station_data.station_code,
            latitude=station_data.latitude,
            longitude=station_data.longitude,
            distance_km=station_data.distance_km,
            stream_raw=station_data.stream,
            stream_highfreq=stream_highfreq,
            stream_lowfreq=stream_lowfreq,
            stream_highpass=stream_highpass,
            sampling_rate=sampling_rate,
            success=True,
        )

    except Exception as exc:
        logger.exception("Erreur prétraitement %s", station_data.station_code)
        return PreprocessedStation(
            station_code=station_data.station_code,
            latitude=station_data.latitude,
            longitude=station_data.longitude,
            distance_km=station_data.distance_km,
            stream_raw=station_data.stream or Stream(),
            stream_highfreq=Stream(),
            stream_lowfreq=Stream(),
            stream_highpass=Stream(),
            sampling_rate=0.0,
            success=False,
            error_message=f"Exception : {exc}",
        )


def preprocess_stream(
    acquisition_result: AcquisitionResult,
) -> PreprocessingResult:
    """Prétraite toutes les stations d'un résultat d'acquisition.

    Args:
        acquisition_result: Résultat de fetch_waveforms.

    Returns:
        PreprocessingResult avec toutes les stations prétraitées.
    """
    logger.info(
        "Prétraitement de %d stations...",
        len(acquisition_result.successful_stations),
    )

    result = PreprocessingResult()
    for station_data in acquisition_result.successful_stations:
        preprocessed = preprocess_station(station_data)
        result.stations.append(preprocessed)

    logger.info(
        "Prétraitement terminé : %d/%d réussis",
        len(result.successful_stations), len(result.stations),
    )

    return result


def get_vertical_trace(stream: Stream) -> Optional[Trace]:
    """Retourne la trace verticale (canal Z) d'un stream.

    La composante verticale est la plus utile pour détecter les signaux
    de chocs atmosphériques (couplage direct).

    Args:
        stream: Stream ObsPy multi-canaux.

    Returns:
        Trace verticale ou None si absente.
    """
    for tr in stream:
        if tr.stats.channel.endswith("Z"):
            return tr
    return None
