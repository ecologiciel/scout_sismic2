"""engines/seismic/detection.py -- Détection de signature bolide.

Étape 3 du pipeline sismique (cf. docs/PHASE_B1_FORMULES_MAITRES.md Ch. 1).

Applique les 4 critères discriminants d'Olivieri 2023 pour distinguer
un signal d'origine bolidique d'un séisme ou d'un autre artefact :

  1. Absence de phases P/S directes (pas d'onde rapide à v > 5 km/s)
  2. Durée du train d'onde courte (< 5 s)
  3. Similarité des formes d'onde entre stations (cross-corr > 0.7)
  4. Vitesse apparente de propagation faible (800-1500 m/s, Mach 3.5)

Pour chaque station, détermine un pic d'arrivée candidat et vérifie
que l'événement global satisfait les 4 critères.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from obspy import UTCDateTime

from engines.seismic import (
    CROSS_CORR_MIN,
    DURATION_MAX,
    V_APPARENT_MAX,
    V_APPARENT_MIN,
    V_P_WAVE_MIN,
)
from engines.seismic.preprocessing import (
    PreprocessedStation,
    PreprocessingResult,
    get_vertical_trace,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────
# Dataclasses résultat
# ─────────────────────────────────────────────────────────────────

@dataclass
class StationDetection:
    """Détection de pic sur une station unique."""

    station_code: str
    latitude: float
    longitude: float
    distance_km: float
    pick_time: Optional[UTCDateTime] = None     # Temps d'arrivée du pic
    pick_amplitude: float = 0.0                  # Amplitude max du pic
    signal_duration_s: float = 0.0               # Durée du transient
    snr: float = 0.0                             # Signal-to-noise ratio
    detected: bool = False                       # Pic trouvé ?
    rejected_reason: str = ""


@dataclass
class CriteriaCheck:
    """Résultat de la vérification des 4 critères."""

    no_p_wave: bool = False              # Critère 1
    short_duration: bool = False         # Critère 2
    similar_waveforms: bool = False      # Critère 3
    low_apparent_velocity: bool = False  # Critère 4

    # Métriques détaillées
    max_velocity_observed_kms: float = 0.0
    max_duration_observed_s: float = 0.0
    mean_cross_correlation: float = 0.0
    apparent_velocity_ms: float = 0.0

    @property
    def all_passed(self) -> bool:
        """True si les 4 critères sont satisfaits."""
        return all([
            self.no_p_wave,
            self.short_duration,
            self.similar_waveforms,
            self.low_apparent_velocity,
        ])

    @property
    def score(self) -> int:
        """Nombre de critères satisfaits (0-4)."""
        return sum([
            self.no_p_wave,
            self.short_duration,
            self.similar_waveforms,
            self.low_apparent_velocity,
        ])


@dataclass
class DetectionResult:
    """Résultat global de la détection."""

    station_detections: list[StationDetection] = field(default_factory=list)
    criteria: CriteriaCheck = field(default_factory=CriteriaCheck)
    is_bolide: bool = False              # Verdict final
    confidence: float = 0.0              # 0-1

    @property
    def successful_detections(self) -> list[StationDetection]:
        """Stations avec pic détecté."""
        return [d for d in self.station_detections if d.detected]


# ─────────────────────────────────────────────────────────────────
# Fonctions internes — Détection de pic sur une station
# ─────────────────────────────────────────────────────────────────

def _sta_lta_trigger(
    data: np.ndarray,
    sampling_rate: float,
    sta_window: float = 0.5,
    lta_window: float = 10.0,
    threshold: float = 3.0,
) -> Optional[int]:
    """Détecte un pic par méthode STA/LTA.

    Calcule le ratio Short-Term Average / Long-Term Average et retourne
    l'indice du premier échantillon dépassant le seuil.

    Args:
        data: Amplitude du signal (numpy array).
        sampling_rate: Fréquence d'échantillonnage (Hz).
        sta_window: Fenêtre courte (secondes).
        lta_window: Fenêtre longue (secondes).
        threshold: Seuil de déclenchement.

    Returns:
        Index du trigger ou None si aucun dépassement.
    """
    try:
        from obspy.signal.trigger import classic_sta_lta, trigger_onset

        nsta = int(sta_window * sampling_rate)
        nlta = int(lta_window * sampling_rate)

        if len(data) < nlta + nsta:
            return None

        cft = classic_sta_lta(data, nsta, nlta)
        triggers = trigger_onset(cft, threshold, threshold * 0.5)

        if len(triggers) > 0:
            return int(triggers[0, 0])
        return None

    except Exception as exc:
        logger.warning("STA/LTA failed: %s", exc)
        return None


def _compute_snr(
    data: np.ndarray,
    pick_index: int,
    sampling_rate: float,
    signal_window: float = 2.0,
    noise_window: float = 10.0,
) -> float:
    """Calcule le SNR autour d'un pick.

    Args:
        data: Signal.
        pick_index: Indice du pick.
        sampling_rate: Fréquence d'échantillonnage.
        signal_window: Fenêtre signal après le pick (s).
        noise_window: Fenêtre bruit avant le pick (s).

    Returns:
        Ratio RMS(signal) / RMS(bruit).
    """
    n_signal = int(signal_window * sampling_rate)
    n_noise = int(noise_window * sampling_rate)

    noise_start = max(0, pick_index - n_noise)
    noise_end = pick_index
    signal_start = pick_index
    signal_end = min(len(data), pick_index + n_signal)

    if noise_end - noise_start < 10 or signal_end - signal_start < 10:
        return 0.0

    noise_rms = np.sqrt(np.mean(data[noise_start:noise_end] ** 2))
    signal_rms = np.sqrt(np.mean(data[signal_start:signal_end] ** 2))

    if noise_rms < 1e-12:
        return 0.0
    return float(signal_rms / noise_rms)


def _estimate_duration(
    data: np.ndarray,
    pick_index: int,
    sampling_rate: float,
    max_duration_s: float = 30.0,
) -> float:
    """Estime la durée du transient après le pick.

    Méthode simple : recherche du moment où l'amplitude retombe sous
    20% du maximum après le pick.

    Args:
        data: Signal.
        pick_index: Indice du pick.
        sampling_rate: Fréquence d'échantillonnage.
        max_duration_s: Durée maximale à scanner.

    Returns:
        Durée du transient (secondes).
    """
    n_max = int(max_duration_s * sampling_rate)
    end_index = min(len(data), pick_index + n_max)

    if end_index <= pick_index:
        return 0.0

    segment = np.abs(data[pick_index:end_index])
    peak_amplitude = np.max(segment)

    if peak_amplitude < 1e-12:
        return 0.0

    threshold = peak_amplitude * 0.2

    # Chercher le dernier échantillon au-dessus du seuil
    above_threshold = np.where(segment > threshold)[0]
    if len(above_threshold) == 0:
        return 0.0

    last_above = above_threshold[-1]
    return float(last_above / sampling_rate)


def detect_station_pick(
    station: PreprocessedStation,
    sta_threshold: float = 3.0,
) -> StationDetection:
    """Détecte un pic candidat sur une station.

    Utilise la bande haute fréquence (1-20 Hz) qui isole la signature
    N-wave/W-wave caractéristique des bolides.

    Args:
        station: Station prétraitée.
        sta_threshold: Seuil STA/LTA pour déclenchement.

    Returns:
        StationDetection avec pick_time si détecté.
    """
    detection = StationDetection(
        station_code=station.station_code,
        latitude=station.latitude,
        longitude=station.longitude,
        distance_km=station.distance_km,
    )

    if not station.success:
        detection.rejected_reason = "Station prétraitement échoué"
        return detection

    # Utiliser la composante verticale en bande haute
    trace = get_vertical_trace(station.stream_highfreq)
    if trace is None:
        detection.rejected_reason = "Pas de composante verticale"
        return detection

    data = trace.data.astype(np.float64)
    sampling_rate = station.sampling_rate

    if len(data) < int(15 * sampling_rate):
        detection.rejected_reason = "Trace trop courte (< 15s)"
        return detection

    # Détection STA/LTA
    pick_index = _sta_lta_trigger(data, sampling_rate, threshold=sta_threshold)

    if pick_index is None:
        detection.rejected_reason = "Aucun dépassement STA/LTA"
        return detection

    # Temps absolu du pick
    pick_time = trace.stats.starttime + (pick_index / sampling_rate)

    # Amplitude du pic (dans les 2s qui suivent)
    window_samples = int(2.0 * sampling_rate)
    end_idx = min(len(data), pick_index + window_samples)
    peak_amplitude = float(np.max(np.abs(data[pick_index:end_idx])))

    # Durée du transient
    duration = _estimate_duration(data, pick_index, sampling_rate)

    # SNR
    snr = _compute_snr(data, pick_index, sampling_rate)

    detection.pick_time = pick_time
    detection.pick_amplitude = peak_amplitude
    detection.signal_duration_s = duration
    detection.snr = snr
    detection.detected = True

    logger.info(
        "  ✓ %s : pick à %s, amp=%.2e, dur=%.1fs, SNR=%.1f",
        station.station_code, pick_time, peak_amplitude, duration, snr,
    )

    return detection


# ─────────────────────────────────────────────────────────────────
# Fonctions internes — Vérification des 4 critères
# ─────────────────────────────────────────────────────────────────

def _check_criterion_1_no_p_wave(
    detections: list[StationDetection],
) -> tuple[bool, float]:
    """Critère 1 : absence d'onde P directe.

    Vérifie que la vitesse apparente entre les premières stations n'excède
    pas la plage compatible avec des ondes de choc atmosphériques.

    Args:
        detections: Liste de détections réussies (min 2).

    Returns:
        (passed, max_velocity_observed_kms)
    """
    if len(detections) < 2:
        return True, 0.0  # Pas assez pour juger, on accepte

    # Trier par distance
    sorted_det = sorted(detections, key=lambda d: d.distance_km)

    max_velocity = 0.0
    for i in range(1, len(sorted_det)):
        d1 = sorted_det[0]
        d2 = sorted_det[i]
        dist_diff_m = abs(d2.distance_km - d1.distance_km) * 1000.0
        time_diff_s = float(d2.pick_time - d1.pick_time)

        if time_diff_s > 0.01:
            velocity = dist_diff_m / time_diff_s
            max_velocity = max(max_velocity, velocity)

    max_velocity_kms = max_velocity / 1000.0
    # Passé si vitesse max < seuil onde P
    passed = max_velocity < V_P_WAVE_MIN
    return passed, max_velocity_kms


def _check_criterion_2_duration(
    detections: list[StationDetection],
) -> tuple[bool, float]:
    """Critère 2 : durée courte du train d'onde.

    Args:
        detections: Liste de détections réussies.

    Returns:
        (passed, max_duration_observed_s)
    """
    if not detections:
        return False, 0.0

    max_duration = max(d.signal_duration_s for d in detections)
    passed = max_duration < DURATION_MAX
    return passed, max_duration


def _check_criterion_3_waveform_similarity(
    preprocessed_stations: list[PreprocessedStation],
    detections: list[StationDetection],
) -> tuple[bool, float]:
    """Critère 3 : similarité des formes d'onde entre stations.

    Calcule la cross-corrélation moyenne entre les signaux autour
    de chaque pick.

    Args:
        preprocessed_stations: Stations prétraitées.
        detections: Détections réussies.

    Returns:
        (passed, mean_cross_correlation)
    """
    if len(detections) < 2:
        return True, 0.0  # Pas assez pour juger

    # Construire dict station_code -> station préprocessée
    station_dict = {s.station_code: s for s in preprocessed_stations}

    correlations = []
    window_s = 3.0  # Fenêtre de comparaison

    for i in range(len(detections)):
        for j in range(i + 1, len(detections)):
            d1, d2 = detections[i], detections[j]
            s1 = station_dict.get(d1.station_code)
            s2 = station_dict.get(d2.station_code)

            if s1 is None or s2 is None:
                continue

            tr1 = get_vertical_trace(s1.stream_highfreq)
            tr2 = get_vertical_trace(s2.stream_highfreq)

            if tr1 is None or tr2 is None:
                continue

            # Extraire fenêtres autour des picks
            try:
                seg1 = tr1.slice(
                    starttime=d1.pick_time - 0.5,
                    endtime=d1.pick_time + window_s,
                ).data
                seg2 = tr2.slice(
                    starttime=d2.pick_time - 0.5,
                    endtime=d2.pick_time + window_s,
                ).data

                # Normaliser longueurs
                min_len = min(len(seg1), len(seg2))
                if min_len < 10:
                    continue
                seg1 = seg1[:min_len].astype(np.float64)
                seg2 = seg2[:min_len].astype(np.float64)

                # Normaliser amplitudes
                if np.std(seg1) < 1e-12 or np.std(seg2) < 1e-12:
                    continue
                seg1 = (seg1 - np.mean(seg1)) / np.std(seg1)
                seg2 = (seg2 - np.mean(seg2)) / np.std(seg2)

                # Cross-corrélation max
                corr = np.correlate(seg1, seg2, mode="full") / min_len
                max_corr = float(np.max(np.abs(corr)))
                correlations.append(max_corr)

            except Exception as exc:
                logger.debug("Corrélation %s-%s échouée: %s",
                             d1.station_code, d2.station_code, exc)
                continue

    if not correlations:
        return False, 0.0

    mean_corr = float(np.mean(correlations))
    passed = mean_corr >= CROSS_CORR_MIN
    return passed, mean_corr


def _check_criterion_4_apparent_velocity(
    detections: list[StationDetection],
) -> tuple[bool, float]:
    """Critère 4 : vitesse apparente dans la plage 800-1500 m/s.

    Formule 1.4 du doc maître :
        v_apparent = Δd / Δt_arrival

    Args:
        detections: Liste de détections réussies.

    Returns:
        (passed, apparent_velocity_ms)
    """
    if len(detections) < 2:
        return True, 0.0  # Pas assez pour juger

    # Trier par temps d'arrivée
    sorted_det = sorted(detections, key=lambda d: d.pick_time)

    # Moyenner sur paires consécutives
    velocities = []
    for i in range(1, len(sorted_det)):
        d1 = sorted_det[0]  # Référence = première arrivée
        d2 = sorted_det[i]
        dist_diff_m = abs(d2.distance_km - d1.distance_km) * 1000.0
        time_diff_s = float(d2.pick_time - d1.pick_time)

        if time_diff_s > 0.01:
            velocity = dist_diff_m / time_diff_s
            velocities.append(velocity)

    if not velocities:
        return False, 0.0

    mean_velocity = float(np.mean(velocities))
    passed = V_APPARENT_MIN <= mean_velocity <= V_APPARENT_MAX
    return passed, mean_velocity


# ─────────────────────────────────────────────────────────────────
# Fonction publique principale
# ─────────────────────────────────────────────────────────────────

def detect_bolide_signature(
    preprocessing_result: PreprocessingResult,
    sta_threshold: float = 3.0,
) -> DetectionResult:
    """Applique les 4 critères de détection bolide sur toutes les stations.

    Pipeline :
      1. Pour chaque station, détecter un pic candidat (STA/LTA)
      2. Vérifier les 4 critères Olivieri 2023 sur l'ensemble

    Args:
        preprocessing_result: Résultat du prétraitement.
        sta_threshold: Seuil STA/LTA pour déclenchement (défaut 3.0).

    Returns:
        DetectionResult avec verdict is_bolide et métriques.
    """
    logger.info("Détection signature bolide (4 critères Olivieri 2023)...")

    # 1. Détection de pics sur chaque station
    station_detections = []
    for station in preprocessing_result.successful_stations:
        detection = detect_station_pick(station, sta_threshold=sta_threshold)
        station_detections.append(detection)

    successful = [d for d in station_detections if d.detected]
    logger.info(
        "  Pics détectés : %d/%d stations",
        len(successful), len(station_detections),
    )

    # 2. Vérification des 4 critères
    criteria = CriteriaCheck()

    if len(successful) == 0:
        logger.warning("Aucun pic détecté — impossible de vérifier les critères")
        return DetectionResult(
            station_detections=station_detections,
            criteria=criteria,
            is_bolide=False,
            confidence=0.0,
        )

    # Critère 1
    c1_passed, max_vel_kms = _check_criterion_1_no_p_wave(successful)
    criteria.no_p_wave = c1_passed
    criteria.max_velocity_observed_kms = max_vel_kms

    # Critère 2
    c2_passed, max_dur = _check_criterion_2_duration(successful)
    criteria.short_duration = c2_passed
    criteria.max_duration_observed_s = max_dur

    # Critère 3
    c3_passed, mean_corr = _check_criterion_3_waveform_similarity(
        preprocessing_result.successful_stations, successful,
    )
    criteria.similar_waveforms = c3_passed
    criteria.mean_cross_correlation = mean_corr

    # Critère 4
    c4_passed, app_vel = _check_criterion_4_apparent_velocity(successful)
    criteria.low_apparent_velocity = c4_passed
    criteria.apparent_velocity_ms = app_vel

    # Verdict final
    is_bolide = criteria.all_passed
    confidence = criteria.score / 4.0

    logger.info(
        "  Critères satisfaits : %d/4 (confidence=%.2f)",
        criteria.score, confidence,
    )
    logger.info("    C1 (no P-wave) : %s (v_max=%.1f km/s)",
                "✓" if c1_passed else "✗", max_vel_kms)
    logger.info("    C2 (short dur) : %s (dur=%.1fs)",
                "✓" if c2_passed else "✗", max_dur)
    logger.info("    C3 (waveform sim) : %s (corr=%.2f)",
                "✓" if c3_passed else "✗", mean_corr)
    logger.info("    C4 (apparent vel) : %s (v=%.0f m/s)",
                "✓" if c4_passed else "✗", app_vel)

    return DetectionResult(
        station_detections=station_detections,
        criteria=criteria,
        is_bolide=is_bolide,
        confidence=confidence,
    )
