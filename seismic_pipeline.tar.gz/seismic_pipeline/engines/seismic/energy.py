"""engines/seismic/energy.py -- Estimation énergie et masse.

Étape 6 du pipeline sismique (cf. docs/PHASE_B1_FORMULES_MAITRES.md Ch. 4).

Trois méthodes implémentées :

  1. Relation période-yield (Brown/Edwards) :
     Utilise la période dominante du signal infrasound pour estimer
     l'énergie libérée par le bolide.

  2. Amplitude-range (Edwards 2006) :
     Relation empirique amplitude/distance pour estimation grossière.

  3. Conversion énergie → masse :
     Formule 4.4 du doc maître : M = 2E / V²_entry

Sans vitesse d'entrée connue (cas typique sans caméra), on retourne
une plage de masses pour différentes vitesses plausibles.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from engines.seismic import (
    KT_TNT_TO_JOULES,
    E_DETECTION_MIN,
    RHO_CHONDRITE,
)
from engines.seismic.detection import DetectionResult, StationDetection
from engines.seismic.preprocessing import PreprocessingResult, get_vertical_trace
from engines.seismic.triangulation import TriangulationResult

logger = logging.getLogger(__name__)

# Vitesses d'entrée typiques pour estimation range de masses
V_ENTRY_CANDIDATES_KMS: list[float] = [12.0, 15.0, 18.0, 20.0, 25.0]

# Coefficients empiriques Gi & Brown 2017 (Eq. 9 — approximation)
# log10(E_kt) = a + b * log10(Period_s) + c * log10(Range_km)
# Valeurs simplifiées (à affiner avec accès au papier complet)
GI_BROWN_A: float = -3.8
GI_BROWN_B: float = 3.34
GI_BROWN_C: float = -0.5


@dataclass
class EnergyResult:
    """Résultat de l'estimation d'énergie."""

    energy_kt_tnt: float = 0.0
    energy_joules: float = 0.0
    method: str = ""                       # "period_yield", "amplitude_range", "dynamic"
    period_s: float = 0.0                  # Période dominante mesurée
    confidence: float = 0.0
    below_detection_threshold: bool = False
    warning: str = ""


@dataclass
class MassResult:
    """Résultat de l'estimation de masse."""

    mass_kg_min: float = 0.0               # Pour vitesse max
    mass_kg_max: float = 0.0               # Pour vitesse min
    mass_kg_nominal: float = 0.0           # Pour vitesse typique 15 km/s
    velocity_assumed_kms: float = 15.0
    density_used_kgm3: float = RHO_CHONDRITE
    mass_by_velocity: dict[float, float] = field(default_factory=dict)


@dataclass
class EnergyMassResult:
    """Résultat combiné énergie + masse."""

    energy: EnergyResult = field(default_factory=EnergyResult)
    mass: MassResult = field(default_factory=MassResult)
    success: bool = False


# ─────────────────────────────────────────────────────────────────
# Mesure de la période dominante
# ─────────────────────────────────────────────────────────────────

def _measure_dominant_period(
    data: np.ndarray,
    sampling_rate: float,
    pick_index: int,
    window_s: float = 3.0,
) -> float:
    """Mesure la période dominante du signal autour d'un pick.

    Utilise la FFT pour identifier la fréquence dominante.

    Args:
        data: Signal temporel.
        sampling_rate: Fréquence d'échantillonnage (Hz).
        pick_index: Indice du pick.
        window_s: Fenêtre d'analyse autour du pick.

    Returns:
        Période dominante (secondes).
    """
    half_window = int(window_s * sampling_rate / 2)
    start = max(0, pick_index - half_window)
    end = min(len(data), pick_index + half_window)

    segment = data[start:end].astype(np.float64)
    if len(segment) < 10:
        return 0.0

    # Retirer moyenne
    segment = segment - np.mean(segment)

    # FFT
    fft_result = np.fft.rfft(segment)
    freqs = np.fft.rfftfreq(len(segment), d=1.0 / sampling_rate)
    magnitudes = np.abs(fft_result)

    # Ignorer DC
    if len(magnitudes) > 1:
        magnitudes[0] = 0

    # Fréquence dominante (pondérée)
    if np.sum(magnitudes) < 1e-12:
        return 0.0

    dominant_freq = freqs[np.argmax(magnitudes)]
    if dominant_freq < 0.1:
        return 0.0

    return float(1.0 / dominant_freq)


# ─────────────────────────────────────────────────────────────────
# Méthode période-yield
# ─────────────────────────────────────────────────────────────────

def _estimate_energy_period_yield(
    detections: list[StationDetection],
    preprocessing_result: PreprocessingResult,
    source_altitude_m: float,
) -> EnergyResult:
    """Estime l'énergie par la méthode période-yield (Brown/Edwards/Gi).

    Référence : doc maître B1 Ch. 4.1.

    Args:
        detections: Stations avec pick détecté.
        preprocessing_result: Pour accès aux streams filtrés.
        source_altitude_m: Altitude de la source (de la triangulation).

    Returns:
        EnergyResult avec énergie estimée en kt TNT.
    """
    result = EnergyResult(method="period_yield")

    if not detections:
        result.warning = "Aucune détection pour mesurer la période"
        return result

    # Construire dict code → station préprocessée
    station_dict = {s.station_code: s for s in preprocessing_result.successful_stations}

    periods = []
    ranges_km = []

    for d in detections:
        if not d.detected or d.pick_time is None:
            continue

        station = station_dict.get(d.station_code)
        if station is None:
            continue

        # Utiliser bande haute fréquence
        trace = get_vertical_trace(station.stream_highfreq)
        if trace is None:
            continue

        data = trace.data.astype(np.float64)

        # Recalculer pick_index dans les données filtrées
        delta_t = float(d.pick_time - trace.stats.starttime)
        pick_index = int(delta_t * station.sampling_rate)

        if not (0 <= pick_index < len(data)):
            continue

        period = _measure_dominant_period(data, station.sampling_rate, pick_index)
        if period > 0:
            periods.append(period)
            ranges_km.append(d.distance_km)

    if not periods:
        result.warning = "Aucune période dominante mesurable"
        return result

    # Moyenne des périodes et distances
    mean_period = float(np.mean(periods))
    mean_range = float(np.mean(ranges_km))

    # Application formule Gi & Brown 2017 Eq. 9 (simplifiée)
    # log10(E_kt) = a + b*log10(P) + c*log10(R)
    if mean_period <= 0 or mean_range <= 0:
        result.warning = "Période ou distance nulle"
        return result

    log_energy_kt = (
        GI_BROWN_A
        + GI_BROWN_B * math.log10(mean_period)
        + GI_BROWN_C * math.log10(mean_range)
    )
    energy_kt = 10.0 ** log_energy_kt
    energy_joules = energy_kt * KT_TNT_TO_JOULES

    result.energy_kt_tnt = energy_kt
    result.energy_joules = energy_joules
    result.period_s = mean_period
    result.confidence = 0.5  # Méthode approximative sans data center complet

    if energy_kt < E_DETECTION_MIN:
        result.below_detection_threshold = True
        result.warning = (
            f"Énergie {energy_kt:.2e} kt sous seuil détection {E_DETECTION_MIN}"
        )

    logger.info(
        "Énergie (période-yield) : %.3e kt TNT (période=%.2fs, range=%.0fkm)",
        energy_kt, mean_period, mean_range,
    )

    return result


# ─────────────────────────────────────────────────────────────────
# Conversion énergie → masse
# ─────────────────────────────────────────────────────────────────

def _energy_to_mass(
    energy_joules: float,
    velocity_kms: float,
) -> float:
    """Convertit une énergie en masse pour une vitesse donnée.

    Formule 4.4 du doc maître B1 :
        M = 2 * E_total / V_entry²

    Args:
        energy_joules: Énergie cinétique totale (J).
        velocity_kms: Vitesse d'entrée (km/s).

    Returns:
        Masse en kg.
    """
    if velocity_kms <= 0 or energy_joules <= 0:
        return 0.0
    v_ms = velocity_kms * 1000.0
    return 2.0 * energy_joules / (v_ms ** 2)


def estimate_mass_range(
    energy_joules: float,
    velocity_candidates_kms: Optional[list[float]] = None,
) -> MassResult:
    """Estime la plage de masses probables pour différentes vitesses d'entrée.

    Args:
        energy_joules: Énergie libérée (J).
        velocity_candidates_kms: Liste de vitesses à tester.

    Returns:
        MassResult avec masses min/max/nominale + dict par vitesse.
    """
    if velocity_candidates_kms is None:
        velocity_candidates_kms = V_ENTRY_CANDIDATES_KMS

    mass_by_v = {}
    for v in velocity_candidates_kms:
        mass_by_v[v] = _energy_to_mass(energy_joules, v)

    nominal_v = 15.0
    return MassResult(
        mass_kg_min=mass_by_v[max(velocity_candidates_kms)],
        mass_kg_max=mass_by_v[min(velocity_candidates_kms)],
        mass_kg_nominal=mass_by_v.get(nominal_v, 0.0),
        velocity_assumed_kms=nominal_v,
        mass_by_velocity=mass_by_v,
    )


# ─────────────────────────────────────────────────────────────────
# Fonction publique principale
# ─────────────────────────────────────────────────────────────────

def estimate_energy_mass(
    detection_result: DetectionResult,
    preprocessing_result: PreprocessingResult,
    triangulation_result: TriangulationResult,
    velocity_entry_kms: Optional[float] = None,
) -> EnergyMassResult:
    """Estime énergie et masse du bolide.

    Pipeline :
      1. Mesurer période dominante sur les stations ayant détecté
      2. Appliquer relation Gi & Brown 2017 pour énergie
      3. Convertir en masse via formule 4.4 (plage si vitesse inconnue)

    Args:
        detection_result: Résultat détection.
        preprocessing_result: Résultat prétraitement (pour streams).
        triangulation_result: Résultat triangulation (pour altitude).
        velocity_entry_kms: Vitesse d'entrée si connue (caméras/témoin).
            Si None, retourne une plage pour vitesses typiques.

    Returns:
        EnergyMassResult combiné.
    """
    result = EnergyMassResult()

    if not triangulation_result.success or triangulation_result.source is None:
        logger.warning("Pas de triangulation disponible pour estimation énergie")
        return result

    source_alt = triangulation_result.source.altitude_m

    # Estimation énergie
    successful = [d for d in detection_result.station_detections if d.detected]
    energy = _estimate_energy_period_yield(
        successful, preprocessing_result, source_alt,
    )
    result.energy = energy

    if energy.energy_joules <= 0:
        logger.warning("Énergie non estimable")
        return result

    # Estimation masse
    if velocity_entry_kms is not None:
        # Vitesse connue → estimation précise
        mass_kg = _energy_to_mass(energy.energy_joules, velocity_entry_kms)
        result.mass = MassResult(
            mass_kg_min=mass_kg,
            mass_kg_max=mass_kg,
            mass_kg_nominal=mass_kg,
            velocity_assumed_kms=velocity_entry_kms,
            mass_by_velocity={velocity_entry_kms: mass_kg},
        )
        logger.info(
            "Masse (vitesse connue %.1f km/s) : %.2f kg",
            velocity_entry_kms, mass_kg,
        )
    else:
        # Plage pour vitesses typiques
        result.mass = estimate_mass_range(energy.energy_joules)
        logger.info(
            "Masse (plage vitesses) : %.2f - %.2f kg (nominal %.2f kg @ 15 km/s)",
            result.mass.mass_kg_min,
            result.mass.mass_kg_max,
            result.mass.mass_kg_nominal,
        )

    result.success = True
    return result
