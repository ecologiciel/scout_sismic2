"""engines/seismic/pipeline.py -- Orchestration du pipeline sismique complet.

Étape 7 : interface avec le moteur DFMC existant.

Fonction unique `run_seismic_pipeline()` qui enchaîne :
  1. Acquisition FDSN
  2. Prétraitement
  3. Détection signature
  4. Triangulation
  5. Altitude fragmentation
  6. Énergie / masse
  7. Préparation input DFMC

Retour compatible avec le state dict du graphe LangGraph existant.
"""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Optional

from obspy import UTCDateTime

from engines.seismic.acquisition import AcquisitionResult, fetch_waveforms
from engines.seismic.altitude import AltitudeResult, estimate_altitude
from engines.seismic.detection import DetectionResult, detect_bolide_signature
from engines.seismic.energy import EnergyMassResult, estimate_energy_mass
from engines.seismic.preprocessing import (
    PreprocessingResult,
    preprocess_stream,
)
from engines.seismic.triangulation import TriangulationResult, triangulate

logger = logging.getLogger(__name__)


@dataclass
class SeismicPipelineResult:
    """Résultat complet du pipeline sismique."""

    # Inputs
    event_time: str = ""
    event_lat_approx: float = 0.0
    event_lon_approx: float = 0.0

    # Résultats par étape
    acquisition: Optional[AcquisitionResult] = None
    preprocessing: Optional[PreprocessingResult] = None
    detection: Optional[DetectionResult] = None
    triangulation: Optional[TriangulationResult] = None
    altitude: Optional[AltitudeResult] = None
    energy_mass: Optional[EnergyMassResult] = None

    # Verdict final
    success: bool = False
    is_bolide: bool = False
    confidence: float = 0.0
    error_message: str = ""

    # Trace d'exécution pour debug
    stages_completed: list[str] = field(default_factory=list)


def run_seismic_pipeline(
    event_time: UTCDateTime | str | datetime,
    event_lat_approx: float,
    event_lon_approx: float,
    station_codes: Optional[list[str]] = None,
    velocity_entry_kms: Optional[float] = None,
    max_distance_km: float = 1500.0,
    window_pre: int = 1800,
    window_post: int = 1800,
    require_all_criteria: bool = False,
) -> SeismicPipelineResult:
    """Exécute le pipeline sismique complet en 7 étapes.

    Point d'entrée unique pour MANUAL_FALL (témoin), AUTO_SEISMIC (scan
    continu), et ARCHEO_SEISMIC (archives historiques).

    Args:
        event_time: Heure UTC approximative de la chute.
        event_lat_approx: Latitude approximative de la zone.
        event_lon_approx: Longitude approximative.
        station_codes: Liste stations à interroger (None = toutes).
        velocity_entry_kms: Vitesse d'entrée si connue (témoin/caméra).
        max_distance_km: Distance max stations.
        window_pre: Secondes avant event_time.
        window_post: Secondes après event_time.
        require_all_criteria: Exige les 4 critères pour triangulation.

    Returns:
        SeismicPipelineResult complet.
    """
    logger.info("=" * 70)
    logger.info("PIPELINE SISMIQUE — Meteorite Scout AI")
    logger.info("=" * 70)
    logger.info("Event : %s à (%.3f°, %.3f°)",
                event_time, event_lat_approx, event_lon_approx)

    result = SeismicPipelineResult(
        event_time=str(event_time),
        event_lat_approx=event_lat_approx,
        event_lon_approx=event_lon_approx,
    )

    # ── ÉTAPE 1 : Acquisition ────────────────────────────────
    try:
        logger.info("\n[1/7] ACQUISITION FDSN")
        acquisition = fetch_waveforms(
            event_time=event_time,
            event_lat=event_lat_approx,
            event_lon=event_lon_approx,
            station_codes=station_codes,
            max_distance_km=max_distance_km,
            window_pre=window_pre,
            window_post=window_post,
        )
        result.acquisition = acquisition
        result.stages_completed.append("acquisition")

        if acquisition.n_successful == 0:
            result.error_message = "Aucune station n'a retourné de données"
            logger.error(result.error_message)
            return result

        logger.info("  → %d stations avec données", acquisition.n_successful)

    except Exception as exc:
        logger.exception("Échec acquisition")
        result.error_message = f"Acquisition failed: {exc}"
        return result

    # ── ÉTAPE 2 : Prétraitement ──────────────────────────────
    try:
        logger.info("\n[2/7] PRÉTRAITEMENT")
        preprocessing = preprocess_stream(acquisition)
        result.preprocessing = preprocessing
        result.stages_completed.append("preprocessing")

        if not preprocessing.successful_stations:
            result.error_message = "Prétraitement échoué sur toutes les stations"
            return result

    except Exception as exc:
        logger.exception("Échec prétraitement")
        result.error_message = f"Preprocessing failed: {exc}"
        return result

    # ── ÉTAPE 3 : Détection signature ────────────────────────
    try:
        logger.info("\n[3/7] DÉTECTION SIGNATURE BOLIDE")
        detection = detect_bolide_signature(preprocessing)
        result.detection = detection
        result.is_bolide = detection.is_bolide
        result.stages_completed.append("detection")

        if len(detection.successful_detections) == 0:
            result.error_message = (
                "Aucun pic détecté sur aucune station. "
                "Vérifier l'heure estimée et la fenêtre temporelle."
            )
            logger.warning(result.error_message)
            return result

    except Exception as exc:
        logger.exception("Échec détection")
        result.error_message = f"Detection failed: {exc}"
        return result

    # ── ÉTAPE 4 : Triangulation ──────────────────────────────
    try:
        logger.info("\n[4/7] TRIANGULATION")
        triangulation = triangulate(
            detection,
            require_criteria_passed=require_all_criteria,
        )
        result.triangulation = triangulation
        result.stages_completed.append("triangulation")

        if not triangulation.success:
            result.error_message = (
                f"Triangulation échouée : {triangulation.error_message}"
            )
            logger.warning(result.error_message)
            # On continue quand même pour remonter info partielle
    except Exception as exc:
        logger.exception("Échec triangulation")
        result.error_message = f"Triangulation failed: {exc}"
        return result

    # ── ÉTAPE 5 : Altitude ───────────────────────────────────
    try:
        logger.info("\n[5/7] ALTITUDE FRAGMENTATION")
        altitude = estimate_altitude(triangulation)
        result.altitude = altitude
        result.stages_completed.append("altitude")
    except Exception as exc:
        logger.exception("Échec altitude")
        # Non bloquant
        result.altitude = AltitudeResult(
            altitude_m=0.0, uncertainty_km=0.0,
            warning=f"Altitude estimation failed: {exc}",
        )

    # ── ÉTAPE 6 : Énergie/masse ──────────────────────────────
    try:
        logger.info("\n[6/7] ÉNERGIE / MASSE")
        if triangulation.success:
            energy_mass = estimate_energy_mass(
                detection, preprocessing, triangulation,
                velocity_entry_kms=velocity_entry_kms,
            )
            result.energy_mass = energy_mass
            result.stages_completed.append("energy_mass")
    except Exception as exc:
        logger.exception("Échec énergie/masse")
        # Non bloquant

    # ── ÉTAPE 7 : Interface DFMC (prep) ──────────────────────
    logger.info("\n[7/7] PRÉPARATION INPUT DFMC")

    result.stages_completed.append("dfmc_prep")
    result.success = triangulation.success
    result.confidence = triangulation.confidence if triangulation.success else 0.0

    logger.info("=" * 70)
    logger.info("PIPELINE TERMINÉ — success=%s, confidence=%.2f",
                result.success, result.confidence)
    logger.info("  Étapes : %s", " → ".join(result.stages_completed))
    logger.info("=" * 70)

    return result


# ─────────────────────────────────────────────────────────────────
# Interface vers DFMC (nœud LangGraph)
# ─────────────────────────────────────────────────────────────────

def to_dfmc_input(result: SeismicPipelineResult) -> Optional[dict[str, Any]]:
    """Convertit le résultat sismique en dict pour le moteur DFMC.

    Mapping compatible avec PipelineState du graphe LangGraph existant
    (cf. meteorite-scout-ai/graph/state.py).

    Args:
        result: Résultat du pipeline sismique.

    Returns:
        Dict avec lat/lon/alt_m/velocity_kms/gamma_deg/delta_deg
        ou None si triangulation échouée.
    """
    if not result.success or result.triangulation is None:
        return None

    source = result.triangulation.source
    if source is None:
        return None

    # Vitesse d'entrée : utiliser celle fournie ou valeur typique
    if result.energy_mass and result.energy_mass.mass.velocity_assumed_kms:
        velocity_kms = result.energy_mass.mass.velocity_assumed_kms
    else:
        velocity_kms = 15.0  # Valeur typique

    # Énergie
    energy_kt = 0.0
    if result.energy_mass and result.energy_mass.energy:
        energy_kt = result.energy_mass.energy.energy_kt_tnt

    return {
        "lat": source.latitude,
        "lon": source.longitude,
        "alt_m": source.altitude_m,
        "velocity_kms": velocity_kms,
        "energy_kt": energy_kt,
        "gamma_deg": 45.0,    # Angle par défaut si non contraint
        "delta_deg": 180.0,   # Azimut par défaut
        "seismic_confidence": result.confidence,
        "seismic_stations_used": result.triangulation.n_stations_used,
        "seismic_rms_residual_s": result.triangulation.rms_residual_s,
        "seismic_source_time": str(source.time_utc) if source.time_utc else "",
    }


def result_to_dict(result: SeismicPipelineResult) -> dict[str, Any]:
    """Sérialise un SeismicPipelineResult en dict JSON-compatible.

    Args:
        result: Résultat à sérialiser.

    Returns:
        Dict avec toutes les infos structurées.
    """
    output = {
        "event_time": result.event_time,
        "event_lat_approx": result.event_lat_approx,
        "event_lon_approx": result.event_lon_approx,
        "success": result.success,
        "is_bolide": result.is_bolide,
        "confidence": result.confidence,
        "error_message": result.error_message,
        "stages_completed": result.stages_completed,
    }

    # Stations
    if result.acquisition:
        output["stations"] = [
            {
                "code": s.station_code,
                "lat": s.latitude,
                "lon": s.longitude,
                "distance_km": round(s.distance_km, 1),
                "success": s.success,
                "error": s.error_message,
            }
            for s in result.acquisition.stations
        ]

    # Détection
    if result.detection:
        output["detection"] = {
            "is_bolide": result.detection.is_bolide,
            "confidence": result.detection.confidence,
            "criteria": {
                "no_p_wave": result.detection.criteria.no_p_wave,
                "short_duration": result.detection.criteria.short_duration,
                "similar_waveforms": result.detection.criteria.similar_waveforms,
                "low_apparent_velocity": result.detection.criteria.low_apparent_velocity,
                "max_velocity_kms": round(result.detection.criteria.max_velocity_observed_kms, 2),
                "max_duration_s": round(result.detection.criteria.max_duration_observed_s, 2),
                "mean_cross_correlation": round(result.detection.criteria.mean_cross_correlation, 3),
                "apparent_velocity_ms": round(result.detection.criteria.apparent_velocity_ms, 1),
            },
            "station_picks": [
                {
                    "station": d.station_code,
                    "pick_time": str(d.pick_time) if d.pick_time else None,
                    "amplitude": d.pick_amplitude,
                    "duration_s": round(d.signal_duration_s, 2),
                    "snr": round(d.snr, 2),
                    "detected": d.detected,
                }
                for d in result.detection.station_detections
            ],
        }

    # Triangulation
    if result.triangulation:
        output["triangulation"] = {
            "success": result.triangulation.success,
            "method": result.triangulation.method_used,
            "n_stations": result.triangulation.n_stations_used,
            "rms_residual_s": round(result.triangulation.rms_residual_s, 3),
            "confidence": round(result.triangulation.confidence, 3),
        }
        if result.triangulation.source:
            output["triangulation"]["source"] = {
                "lat": round(result.triangulation.source.latitude, 5),
                "lon": round(result.triangulation.source.longitude, 5),
                "altitude_km": round(result.triangulation.source.altitude_m / 1000.0, 2),
                "time_utc": str(result.triangulation.source.time_utc),
                "uncertainty_lat_km": round(result.triangulation.source.uncertainty_lat_km, 2),
                "uncertainty_lon_km": round(result.triangulation.source.uncertainty_lon_km, 2),
                "uncertainty_alt_km": round(result.triangulation.source.uncertainty_alt_km, 2),
            }

    # Altitude
    if result.altitude:
        output["altitude"] = {
            "altitude_km": round(result.altitude.altitude_m / 1000.0, 2),
            "uncertainty_km": round(result.altitude.uncertainty_km, 2),
            "plausibility_score": round(result.altitude.plausibility_score, 2),
            "warning": result.altitude.warning,
        }

    # Énergie/masse
    if result.energy_mass and result.energy_mass.success:
        output["energy_mass"] = {
            "energy_kt_tnt": result.energy_mass.energy.energy_kt_tnt,
            "energy_joules": result.energy_mass.energy.energy_joules,
            "period_s": round(result.energy_mass.energy.period_s, 3),
            "below_detection_threshold": result.energy_mass.energy.below_detection_threshold,
            "mass_kg_min": round(result.energy_mass.mass.mass_kg_min, 2),
            "mass_kg_max": round(result.energy_mass.mass.mass_kg_max, 2),
            "mass_kg_nominal": round(result.energy_mass.mass.mass_kg_nominal, 2),
            "mass_by_velocity": {
                str(v): round(m, 2)
                for v, m in result.energy_mass.mass.mass_by_velocity.items()
            },
        }

    # DFMC input
    dfmc_input = to_dfmc_input(result)
    if dfmc_input:
        output["dfmc_input"] = dfmc_input

    return output
