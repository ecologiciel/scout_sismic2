"""engines/seismic/acquisition.py -- Acquisition des formes d'onde FDSN.

Étape 1 du pipeline sismique (cf. docs/PHASE_B1_FORMULES_MAITRES.md Ch. 8.1).

Télécharge les formes d'onde depuis les data centers FDSN (GEOFON, IPGP, IRIS)
pour toutes les stations actives dans une fenêtre temporelle donnée autour
de l'heure estimée d'une chute.

Utilise le client ObsPy FDSN qui implémente le protocole standard.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

from obspy import Stream, UTCDateTime
from obspy.clients.fdsn import Client
from obspy.clients.fdsn.header import FDSNException, FDSNNoDataException

from engines.seismic import (
    FDSN_CHANNELS_BROADBAND,
    FDSN_CLIENTS,
    FDSN_WINDOW_POST,
    FDSN_WINDOW_PRE,
    STATION_TO_CLIENT,
    STATIONS_MAROC,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────
# Dataclasses résultat
# ─────────────────────────────────────────────────────────────────

@dataclass
class StationData:
    """Données téléchargées pour une station."""

    station_code: str                  # ex: "WM.IFR"
    latitude: float
    longitude: float
    elevation_m: float
    distance_km: float                 # Distance à l'événement
    stream: Optional[Stream] = None    # Formes d'onde ObsPy
    success: bool = False
    error_message: str = ""


@dataclass
class AcquisitionResult:
    """Résultat global de l'acquisition multi-stations."""

    event_time: UTCDateTime
    event_lat: float
    event_lon: float
    window_start: UTCDateTime
    window_end: UTCDateTime
    stations: list[StationData] = field(default_factory=list)

    @property
    def successful_stations(self) -> list[StationData]:
        """Retourne uniquement les stations avec données valides."""
        return [s for s in self.stations if s.success]

    @property
    def n_successful(self) -> int:
        """Nombre de stations avec téléchargement réussi."""
        return len(self.successful_stations)


# ─────────────────────────────────────────────────────────────────
# Helpers internes
# ─────────────────────────────────────────────────────────────────

def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Distance haversine entre deux points géographiques (km).

    Args:
        lat1, lon1: Coordonnées point 1 en degrés décimaux.
        lat2, lon2: Coordonnées point 2 en degrés décimaux.

    Returns:
        Distance en kilomètres.
    """
    import math

    R_EARTH_KM = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = (math.sin(dphi / 2) ** 2
         + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2)
    return R_EARTH_KM * 2 * math.asin(math.sqrt(a))


def _is_station_active(
    station_code: str,
    event_time: UTCDateTime,
) -> bool:
    """Vérifie si la station était active à la date de l'événement.

    Args:
        station_code: Code station format "NET.STA".
        event_time: Timestamp de l'événement.

    Returns:
        True si la station était active à cette date.
    """
    if station_code not in STATIONS_MAROC:
        logger.warning("Station inconnue: %s", station_code)
        return False

    _lat, _lon, _elev, _url, start_year = STATIONS_MAROC[station_code]

    # Cas spécial WM.AVE : active de 2007 à novembre 2011
    if station_code == "WM.AVE":
        start = UTCDateTime("2007-01-01")
        end = UTCDateTime("2011-11-30")
        return start <= event_time <= end

    # Cas général : active depuis start_year
    if start_year is None:
        return False

    start = UTCDateTime(f"{start_year}-01-01")
    return event_time >= start


def _get_fdsn_client(station_code: str) -> Optional[Client]:
    """Retourne le client ObsPy FDSN approprié pour une station.

    Args:
        station_code: Code station format "NET.STA".

    Returns:
        Client ObsPy FDSN ou None si station inconnue.
    """
    if station_code not in STATION_TO_CLIENT:
        return None

    client_name = STATION_TO_CLIENT[station_code]
    base_url = FDSN_CLIENTS[client_name]

    try:
        return Client(base_url, timeout=30)
    except Exception as exc:
        logger.error("Impossible de créer client %s : %s", client_name, exc)
        return None


# ─────────────────────────────────────────────────────────────────
# Fonctions publiques
# ─────────────────────────────────────────────────────────────────

def fetch_station_waveform(
    station_code: str,
    event_time: UTCDateTime,
    event_lat: float,
    event_lon: float,
    window_pre: int = FDSN_WINDOW_PRE,
    window_post: int = FDSN_WINDOW_POST,
    channels: str = FDSN_CHANNELS_BROADBAND,
) -> StationData:
    """Télécharge les formes d'onde d'une station unique.

    Args:
        station_code: Code station format "NET.STA" (ex: "WM.IFR").
        event_time: Heure UTC de l'événement.
        event_lat: Latitude de l'événement (pour calcul distance).
        event_lon: Longitude de l'événement.
        window_pre: Secondes avant l'événement à télécharger.
        window_post: Secondes après l'événement.
        channels: Pattern des canaux (défaut "BH*" pour broadband).

    Returns:
        StationData avec stream ObsPy si succès, sinon success=False.
    """
    if station_code not in STATIONS_MAROC:
        return StationData(
            station_code=station_code,
            latitude=0.0,
            longitude=0.0,
            elevation_m=0.0,
            distance_km=float("inf"),
            success=False,
            error_message=f"Station {station_code} inconnue",
        )

    lat, lon, elev, _url, _start = STATIONS_MAROC[station_code]
    distance_km = _haversine_km(lat, lon, event_lat, event_lon)

    # Vérifier activité à la date
    if not _is_station_active(station_code, event_time):
        return StationData(
            station_code=station_code,
            latitude=lat,
            longitude=lon,
            elevation_m=elev,
            distance_km=distance_km,
            success=False,
            error_message=f"Station inactive à {event_time}",
        )

    client = _get_fdsn_client(station_code)
    if client is None:
        return StationData(
            station_code=station_code,
            latitude=lat,
            longitude=lon,
            elevation_m=elev,
            distance_km=distance_km,
            success=False,
            error_message="Impossible de créer client FDSN",
        )

    # Parser code station
    network, station = station_code.split(".")

    # Fenêtre temporelle
    start_time = event_time - window_pre
    end_time = event_time + window_post

    logger.info(
        "Téléchargement %s : %s → %s (%.0f s)",
        station_code, start_time, end_time, window_pre + window_post,
    )

    try:
        stream = client.get_waveforms(
            network=network,
            station=station,
            location="*",
            channel=channels,
            starttime=start_time,
            endtime=end_time,
        )

        if len(stream) == 0:
            return StationData(
                station_code=station_code,
                latitude=lat,
                longitude=lon,
                elevation_m=elev,
                distance_km=distance_km,
                success=False,
                error_message="Stream vide (pas de données)",
            )

        logger.info(
            "  ✓ %s : %d traces, %d échantillons",
            station_code, len(stream), sum(len(tr) for tr in stream),
        )

        return StationData(
            station_code=station_code,
            latitude=lat,
            longitude=lon,
            elevation_m=elev,
            distance_km=distance_km,
            stream=stream,
            success=True,
        )

    except FDSNNoDataException:
        return StationData(
            station_code=station_code,
            latitude=lat,
            longitude=lon,
            elevation_m=elev,
            distance_km=distance_km,
            success=False,
            error_message="Pas de données disponibles sur le serveur",
        )
    except FDSNException as exc:
        return StationData(
            station_code=station_code,
            latitude=lat,
            longitude=lon,
            elevation_m=elev,
            distance_km=distance_km,
            success=False,
            error_message=f"Erreur FDSN : {exc}",
        )
    except Exception as exc:
        logger.exception("Erreur inattendue pour %s", station_code)
        return StationData(
            station_code=station_code,
            latitude=lat,
            longitude=lon,
            elevation_m=elev,
            distance_km=distance_km,
            success=False,
            error_message=f"Exception : {exc}",
        )


def fetch_waveforms(
    event_time: UTCDateTime | str | datetime,
    event_lat: float,
    event_lon: float,
    station_codes: Optional[list[str]] = None,
    max_distance_km: float = 1500.0,
    window_pre: int = FDSN_WINDOW_PRE,
    window_post: int = FDSN_WINDOW_POST,
) -> AcquisitionResult:
    """Télécharge les formes d'onde de plusieurs stations pour un événement.

    Sélectionne automatiquement les stations actives à cette date et situées
    à moins de `max_distance_km` de l'événement.

    Args:
        event_time: Heure UTC de l'événement (UTCDateTime, str ISO, ou datetime).
        event_lat: Latitude de la chute présumée (degrés décimaux).
        event_lon: Longitude de la chute présumée.
        station_codes: Liste de stations à interroger. Si None, utilise toutes
            les stations disponibles dans STATIONS_MAROC.
        max_distance_km: Distance maximale pour inclure une station.
        window_pre: Secondes de données avant l'événement.
        window_post: Secondes de données après l'événement.

    Returns:
        AcquisitionResult avec les données de toutes les stations interrogées.
    """
    # Normaliser event_time
    if isinstance(event_time, str):
        event_time = UTCDateTime(event_time)
    elif isinstance(event_time, datetime):
        event_time = UTCDateTime(event_time)

    # Liste de stations par défaut
    if station_codes is None:
        station_codes = list(STATIONS_MAROC.keys())

    # Filtrer par distance
    candidates = []
    for code in station_codes:
        if code not in STATIONS_MAROC:
            logger.warning("Station ignorée (inconnue) : %s", code)
            continue
        lat, lon, _elev, _url, _start = STATIONS_MAROC[code]
        dist = _haversine_km(lat, lon, event_lat, event_lon)
        if dist <= max_distance_km:
            candidates.append((code, dist))
        else:
            logger.info(
                "Station %s exclue : %.0f km > %.0f km",
                code, dist, max_distance_km,
            )

    # Trier par distance croissante
    candidates.sort(key=lambda x: x[1])

    logger.info(
        "Acquisition pour événement %s à (%.3f, %.3f) : %d stations candidates",
        event_time, event_lat, event_lon, len(candidates),
    )

    # Télécharger en série (éviter surcharge data centers)
    result = AcquisitionResult(
        event_time=event_time,
        event_lat=event_lat,
        event_lon=event_lon,
        window_start=event_time - window_pre,
        window_end=event_time + window_post,
    )

    for code, _dist in candidates:
        station_data = fetch_station_waveform(
            station_code=code,
            event_time=event_time,
            event_lat=event_lat,
            event_lon=event_lon,
            window_pre=window_pre,
            window_post=window_post,
        )
        result.stations.append(station_data)

    logger.info(
        "Acquisition terminée : %d/%d stations réussies",
        result.n_successful, len(candidates),
    )

    return result
