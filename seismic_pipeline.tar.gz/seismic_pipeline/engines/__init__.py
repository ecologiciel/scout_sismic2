"""engines/ -- Moteurs physiques partagés par les nœuds du graphe LangGraph."""
