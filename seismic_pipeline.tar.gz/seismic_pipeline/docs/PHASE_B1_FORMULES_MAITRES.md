# 📐 METEORITE SCOUT AI — PHASE B1

## DOCUMENT MAÎTRE : EXTRACTION DES FORMULES SISMIQUES

> **⚠️ DOCUMENT DE RÉFÉRENCE CRITIQUE**
> Ce document consolide toutes les formules scientifiques extraites des publications
> de référence pour la validation du pipeline sismique de Meteorite Scout AI.
> Il constitue la base technique qui pilotera le développement en production.
>
> **À protéger — À ne jamais modifier sans validation explicite.**

---

## 📋 MÉTADONNÉES

| Champ | Valeur |
|---|---|
| **Phase** | B1 — Extraction formules scientifiques |
| **Date création** | 2026-04-21 |
| **Version** | 1.0 |
| **Statut** | En cours — 3/3 publications extraites |
| **Validation** | À valider par Nabil avant passage Phase B2 |
| **Usage** | Référence pour code production Claude Code |

---

## 📚 PUBLICATIONS DE RÉFÉRENCE

Trois publications constituent le corpus scientifique officiel de validation :

### Publication 1 — Italie 5 mars 2022 (PRISMA/INGV)

- **Référence complète** : Olivieri M., Piccinini D., Saccorotti G., Barghini D., Gardiol D., Pino N.A., Ripepe M., Betti G., Lacanna G., Arcidiaco L. (2023). *The optical, seismic, and infrasound signature of the March 5 2022, bolide over Central Italy.* Scientific Reports 13, 21135.
- **DOI** : 10.1038/s41598-023-48396-8
- **Configuration** : 10 caméras PRISMA + **61 stations sismiques** + 4-element infrasound array
- **Énergie/masse** : 12 kg meteoroid, altitude Mach cone 68 km
- **Pertinence** : Cas de validation méthodologique le plus complet. Triple observation (optique + sismique + infrasound) = vérité terrain imbattable.

### Publication 2 — El-Hakimia Algérie 7 mai 2023 (CRAAG)

- **Référence complète** : Roubeche K. et al. (2025). *The May 7, 2023, El-Hakimia, Algeria, Fireball: First Meteor Characterization Using Infrasound and Seismic Sensors.* Pure and Applied Geophysics.
- **DOI** : 10.1007/s00024-025-03730-1
- **Configuration** : **14 stations sismiques ADSN** + stations infrasound IMS (I48TN, I26DE)
- **Énergie/masse** : 0.178 ± 0.014 kt TNT, masse 0.598 ± 0.048 t à 14.946 ± 1.216 t
- **Fragmentation** : altitude 35 ± 0.6 km
- **Pertinence** : Cas maghrébin le plus proche géographiquement et méthodologiquement. Méthode des isochrones documentée.

### Publication 3 — Traspena Espagne 18 janvier 2021 (USC/SPMN)

- **Référence complète** : Andrade M., Docobo J.A., García-Guinea J., Campo P.P., Tapia M., Sánchez-Muñoz L., Villasante-Marcos V., Peña-Asensio E., Trigo-Rodríguez J.M., Ibáñez-Insa J., Campeny M., Llorca J. (2023). *The Traspena meteorite: heliocentric orbit, atmospheric trajectory, strewn field, and petrography of a new L5 ordinary chondrite.* MNRAS 518(3), 3850-3876.
- **DOI** : 10.1093/mnras/stac2911
- **Configuration** : **3 stations sismiques** IGN Spain + caméras USC
- **Énergie/masse** : masse 2620 kg, diamètre 1.15 m
- **Trajectoire** : altitude 75.10 km → 15.75 km, angle 76.7°, durée 4.84 s
- **Pertinence** : Cas équivalent configurationnel à Tiflet 2026 (3 stations).

---

## 🎯 CAS DE VALIDATION ASSOCIÉS

| Cas Maroc | Publication référence | Configuration |
|---|---|---|
| **Tamdakht 2008** | Olivieri 2023 + Roubeche 2024 | 2 stations WM (IFR+AVE 316 km) |
| **Tissint 2011** | Roubeche 2024 (longue distance) | Stations 500-700 km |
| **Tiflet 2026** | Andrade 2023 + Olivieri 2023 | 3 stations WM (IFR+CEU+PVLZ < 250 km) |

---

# CHAPITRE 1 — DÉTECTION DE LA SIGNATURE SISMIQUE

## 1.1 Signature "bolide" vs "séisme" — les 4 critères discriminants

**Source : Olivieri 2023 Sect. Results**

Un événement sismique d'origine bolidique se distingue d'un séisme classique par **4 caractéristiques simultanées** :

| Critère | Bolide | Séisme |
|---|---|---|
| Phases P/S directes | ❌ Absentes | ✅ Présentes |
| Durée du train d'onde | < 5 secondes | 20+ secondes |
| Similarité formes d'ondes entre stations | Forte (couplage acoustique) | Variable |
| Vitesse apparente de propagation | ~1100-1200 m/s (Mach 3.5) | 5000-8000 m/s |

**Citation directe Olivieri 2023 :**
> *"The combination of these four pieces of evidence (no clear body wave onset, short duration, the lack of spatial attenuation, low propagation velocity) suggests the incompatibility with earthquake-like source."*

**Implémentation pipeline** :
```python
def is_bolide_signature(trace, inter_station_distances, arrival_times):
    """Retourne True si les 4 critères bolide sont satisfaits."""
    # Critère 1 : absence onde P (pas de pic énergétique à v > 5 km/s)
    # Critère 2 : durée du signal < 5s après filtre
    # Critère 3 : cross-correlation inter-stations > 0.7
    # Critère 4 : vitesse apparente entre 800 et 1500 m/s
```

## 1.2 Filtrage fréquentiel

**Source : Olivieri 2023 Sect. Methods + Andrade 2023**

Deux bandes de fréquence à analyser en parallèle :

**Bande haute (onde de choc directe)** :
- Plage : **1 - 20 Hz** (Olivieri)
- Plage alternative : **> 3 Hz** avec passe-haut (Andrade sur Traspena)
- Objectif : isoler le signal N-wave / W-wave

**Bande basse (couplage Rayleigh)** :
- Plage : **0.5 - 4 Hz** (Olivieri)
- Objectif : détecter les ondes Rayleigh précédant l'onde directe
- Ces ondes de surface précèdent l'arrivée directe de quelques secondes

**Citation directe Olivieri 2023 :**
> *"Time–frequency domain analysis reveals that a large part of the energy recorded by seismometers concentrates between 1 and 20 Hz."*

**Citation directe Andrade 2023 :**
> *"The raw data from these nine seismic stations did not show at first glance any notable events compatible with the bolide. In fact, these had to be detrended and 3-Hz high-pass filtered using Obspy/python to find events compatible with the bolide."*

## 1.3 Morphologie du signal — N-wave et W-wave

**Source : Olivieri 2023 Sect. Methods**

Forme d'onde caractéristique (inverted-N en déplacement, W en vélocité) :
- Pulse de haute fréquence avec compression initiale
- Forme abrupte due au choc non-linéaire
- Commune aux événements : météores, sonic booms, explosions atmosphériques, tonnerre

**Implémentation pipeline** :
```python
def detect_n_wave(velocity_trace, sampling_rate=100):
    """Détecte un pattern N-wave caractéristique d'un choc acoustique."""
    # Recherche d'un pic négatif court (<0.5s) suivi d'un pic positif
    # avec transitions abruptes (dérivée élevée aux extrêmes)
```

## 1.4 Vitesse apparente du front d'onde

**Source : Olivieri 2023**

$$v_a = \frac{\Delta d}{\Delta t_{arrival}}$$

Où :
- $\Delta d$ = distance entre deux stations (m)
- $\Delta t_{arrival}$ = différence de temps d'arrivée (s)

**Valeur attendue pour bolide** : 1100-1200 m/s (atmosphère standard)

---

# CHAPITRE 2 — TRIANGULATION MULTI-STATIONS

## 2.1 Beamforming par slowness (arrays infrasound)

**Source : Olivieri 2023 Sect. Methods**

Pour un array d'au moins 3 capteurs alignés, le beamforming fréquentiel fournit le vecteur lenteur horizontale $[s_x, s_y]$.

### Formule 2.1.a — Back-azimut

$$\boxed{f_{bR} = 180° + \arctan\left(\frac{s_x}{s_y}\right)}$$

### Formule 2.1.b — Vitesse apparente

$$\boxed{v_a = \frac{1}{\sqrt{s_x^2 + s_y^2}}}$$

### Formule 2.1.c — Angle d'incidence

$$\boxed{f_i = \arcsin\left(\frac{v_s}{v_a}\right)}$$

Où :
- $v_s$ = vitesse locale du son à l'altitude de la station (~336 m/s au niveau mer)
- $v_a$ = vitesse apparente calculée (formule 2.1.b)

**Paramètres d'analyse recommandés** :
- Intervalle de fréquence : 1-10 Hz
- Fenêtres glissantes : 5 secondes
- Overlap : 95%
- Bibliothèque : **ObsPy** (implémentation de référence)

## 2.2 Méthode des isochrones (multi-stations sismiques)

**Source : Roubeche 2024 Sect. Results**

Pour un réseau de stations sismiques (> 5 stations idéalement), la méthode des isochrones permet de reconstruire la trajectoire du front d'onde.

**Principe** :
1. À chaque station, mesurer le temps d'arrivée $t_i$ du front d'onde
2. Sur une carte, tracer les **isochrones** (courbes de même temps d'arrivée)
3. La trajectoire apparente du bolide est **perpendiculaire aux isochrones**
4. La vitesse apparente du front au sol est obtenue du gradient spatial de $t_i$

**Application El-Hakimia** :
- 14 stations utilisées
- Isochrones ont révélé une trajectoire **ESE-WNW**
- Altitude de fragmentation : 35 ± 0.6 km

> ⚠️ **Note d'implémentation** : Le papier Roubeche 2024 ne fournit pas les formules analytiques d'inversion. La méthode nécessite une optimisation numérique : ajuster la trajectoire hypothétique qui minimise les résidus de temps d'arrivée sur toutes les stations (cf. Olivieri 2023 pour l'approche opposée).

## 2.3 Minimisation des résidus de temps d'arrivée

**Source : Olivieri 2023 Sect. Results + Fig. 5**

Approche inverse : tester plusieurs trajectoires candidates et retenir celle qui minimise les résidus.

### Formule 2.3.a — Temps d'arrivée théorique

$$t_i^{calc} = t_0 + \frac{d_i(\text{trajectoire})}{c_{son}}$$

Où :
- $t_0$ = temps de référence (début de la trajectoire)
- $d_i(\text{trajectoire})$ = distance perpendiculaire entre station $i$ et la trajectoire
- $c_{son}$ = vitesse du son (295 m/s pour modèle homogène)

### Formule 2.3.b — Résidu à minimiser

$$\boxed{R = \sum_{i=1}^{N} \left(t_i^{obs} - t_i^{calc}\right)^2}$$

### Formule 2.3.c — Correction vent stratosphérique

Les vents haute altitude (30-50 km) peuvent faire pivoter le Mach cone.

**Cas Italie 2022** : rotation observée de 6° vers le sud, cohérente avec les vents ERA5 (56-58 m/s NW à 47 km d'altitude).

**Implémentation** :
```python
def correct_mach_cone_rotation(trajectory, wind_profile_era5):
    """Applique la correction vent au Mach cone."""
    # Intégrer le profil vent sur la hauteur de propagation
    # Calculer l'angle de rotation induit
    # Retourner la trajectoire corrigée
```

## 2.4 Triangulation minimale 3 stations

**Source : Andrade 2023 (Traspena)**

**Configuration minimale opérationnelle validée** : 3 stations sismiques + détrending + filtre passe-haut 3 Hz.

**Citation directe Andrade 2023 :**
> *"there are nine seismic stations in the surroundings owned by the Spanish Digital Seismic Network... The raw data from these nine seismic stations did not show at first glance any notable events compatible with the bolide. In fact, these had to be detrended and 3-Hz high-pass filtered using Obspy/python to find events compatible with the bolide."*

**Leçon opérationnelle** : **Le signal peut être invisible sur les données brutes et n'émerger qu'après traitement**. Ne jamais conclure "pas de signal" avant filtrage complet.

**Application Tiflet 2026** : cette configuration 3 stations est directement transposable (IFR + CEU + PVLZ).

---

# CHAPITRE 3 — COUPLAGE ATMOSPHÈRE → SOL

## 3.1 Mécanismes de génération du signal sismique

**Source : Olivieri 2023 + Andrade 2023**

Trois mécanismes distincts génèrent un signal sismique depuis un bolide :

1. **Onde de choc du Mach cone** (trajectoire supersonique)
   - Propagation perpendiculaire à la trajectoire
   - Signature linéaire étendue sur plusieurs stations

2. **Explosion de fragmentation** (point source quasi-sphérique)
   - Propagation omnidirectionnelle depuis le point d'éclat
   - Signature ponctuelle, temps d'arrivée compatible avec vitesse du son

3. **Couplage atmosphère-sol direct**
   - La pression atmosphérique induit des ondes Rayleigh de surface
   - Vitesse caractéristique : ~2000 m/s

## 3.2 Détection des ondes Rayleigh couplées

**Source : Olivieri 2023 + hodogramme station MOMA**

Les ondes Rayleigh précurseurs apparaissent avant l'onde directe, avec :
- Fréquence : 0.5 - 4 Hz (filtrer en conséquence)
- Vitesse : ~2000 m/s
- Particule motion : rétrograde dans le plan vertical-radial

### Formule 3.2 — Distance de couplage

$$\boxed{d_{coupling} = v_{Rayleigh} \times \Delta t_{arrival}}$$

**Exemple Italie 2022** : ondes Rayleigh à 2000 m/s observées ~5s avant l'onde directe → couplage à ~10 km de la station MOMA.

## 3.3 Implication pratique pour le Maroc

Les stations WM (broadband 0.01-50 Hz) captent **les 3 types de signaux**. Aucun besoin d'infrasound dédié pour le pipeline Meteorite Scout AI — les sismomètres captent le couplage acoustique au sol.

---

# CHAPITRE 4 — CALCUL D'ÉNERGIE

## 4.1 Méthode période-yield (AFTAC / Edwards)

**Source : Roubeche 2024 + références implicites**

Relation empirique entre la période du signal infrasound et l'énergie libérée, basée sur les données d'explosions nucléaires AFTAC.

**Relation utilisée dans Roubeche 2024** : non explicitée dans l'abstract mais référencée aux travaux de Brown/Edwards.

**Valeur obtenue El-Hakimia** : 0.178 ± 0.014 kt TNT

## 4.2 Estimation depuis la trajectoire dynamique

**Source : Olivieri 2023 (système différentiel)**

Système d'équations différentielles complet (cas ablation atmosphérique) :

$$\begin{cases}
\dfrac{dH}{dt} = -V\sin\gamma \\[6pt]
M\dfrac{dV}{dt} = -\Gamma S \rho_a V^2 \\[6pt]
\dfrac{dM}{dt} = \sigma M V \dfrac{dV}{dt} \\[6pt]
I = -\tau \dfrac{d}{dt}\left(\tfrac{1}{2} M V^2\right)
\end{cases}$$

**Variables** :
| Symbole | Signification | Unité |
|---|---|---|
| $H$ | altitude | m |
| $V$ | vitesse | m/s |
| $M$ | masse | kg |
| $S$ | section efficace | m² |
| $\gamma$ | inclinaison trajectoire | rad |
| $\Gamma$ | coefficient traînée | — |
| $\rho_a$ | densité air | kg/m³ |
| $\sigma$ | coefficient ablation | s²/km² |
| $\tau$ | efficacité lumineuse | — |
| $I$ | intensité lumineuse | W |

**Énergie cinétique à t** :

$$\boxed{E_k(t) = \frac{1}{2} M(t) V(t)^2}$$

**Énergie totale libérée** :

$$\boxed{E_{total} = E_k(t_0) - E_k(t_f)}$$

## 4.3 Paramètres physiques par défaut

**Source : Olivieri 2023 + Andrade 2023 + Consolmagno 2008**

| Paramètre | Valeur | Source |
|---|---|---|
| Densité chondrite ordinaire | 3.3 ± 0.2 g/cm³ | Consolmagno 2008 |
| Densité Traspena (L5) | 3.5 g/cm³ | Andrade 2023 |
| Coefficient traînée $\Gamma$ | 1.0 (sphère) | Physique standard |
| Vitesse entrée typique | 11-72 km/s | Observations globales |
| Vitesse son (niveau mer) | 336 m/s | Standard Atmosphere |
| Vitesse son (modèle homogène) | 295 m/s | Olivieri 2023 |

## 4.4 Relations énergie → masse

**Source : Roubeche 2024**

À partir de l'énergie et de la vitesse d'entrée estimée, la masse est calculée par :

$$\boxed{M = \frac{2 E_{total}}{V_{entry}^2}}$$

**Validation croisée El-Hakimia** :
- Énergie : 0.178 kt TNT = 7.45 × 10¹¹ J
- Plage de masse : 0.598 à 14.946 tonnes (selon vitesse et composition)
- Facteur 25× entre les deux estimations → **l'incertitude sur la vitesse est dominante**

**Implication pratique** : sans contrainte optique (caméras) pour la vitesse, l'incertitude sur la masse est d'un ordre de grandeur. Les témoignages visuels sont donc précieux pour contraindre $V_{entry}$.

---

# CHAPITRE 5 — ALTITUDE DE FRAGMENTATION

## 5.1 Méthode par intersection back-azimut

**Source : Olivieri 2023 Fig. 6 + discussion**

**Procédure** :
1. Mesurer le back-azimut $f_{bR}$ depuis un array infrasound (formule 2.1.a)
2. Mesurer l'angle d'incidence $f_i$ (formule 2.1.c)
3. Projeter un rayon 3D depuis l'array avec ces angles
4. Calculer l'intersection avec la trajectoire optique (ou présumée)
5. L'altitude d'intersection = altitude de fragmentation

**Application Italie 2022** : back-azimut 25°, angle 46° → altitude 68 km.

## 5.2 Méthode par inversion multi-stations

**Source : Roubeche 2024**

Pour un réseau dense (14 stations El-Hakimia), inverser le système surdéterminé des temps d'arrivée pour trouver :
- $(x_0, y_0)$ = coordonnées géographiques de la source
- $h_0$ = altitude de la source
- $t_0$ = temps de fragmentation

**Résultat El-Hakimia** : source à 35 ± 0.6 km d'altitude.

## 5.3 Méthode par propagation ray tracing

**Source : Roubeche 2024 Fig. 5 (propagation modeling)**

Pour les sources ponctuelles (fragmentations), modéliser la propagation acoustique dans une atmosphère stratifiée (ERA5) :
- Calculer les trajectoires des rayons acoustiques depuis l'altitude supposée
- Ajuster l'altitude pour que les rayons atteignent les stations aux temps observés

**Avantage** : prend en compte la réfraction par gradients température/vent.
**Limite** : sensible à la qualité du modèle atmosphérique.

---

# CHAPITRE 6 — STRATIFICATION ATMOSPHÉRIQUE

## 6.1 Modèles de référence

**Source : Olivieri 2023 + Roubeche 2024**

| Modèle | Résolution | Usage |
|---|---|---|
| US Standard Atmosphere 1976 | Mondiale, statique | Approximation rapide |
| ERA5 (ECMWF) | 0.25°, horaire, jusqu'à 80 km | **Référence pour correction vent** |
| NRLMSISE-00 | Mondiale, statique | Haute altitude (> 80 km) |

**Recommandation Meteorite Scout AI** : utiliser **ERA5** pour toutes les corrections de propagation, disponible via API Copernicus CDS (déjà intégré dans le pipeline DFMC).

## 6.2 Profils cruciaux pour la propagation

**Source : Olivieri 2023 Sect. Discussion**

Les variables à extraire d'ERA5 pour chaque événement :
- Température vs altitude
- Pression vs altitude
- Densité air vs altitude (calculée)
- Vent horizontal (composantes u, v) vs altitude
- **Vitesse du son** : $c(z) = \sqrt{\gamma \cdot R \cdot T(z)}$

Où $\gamma = 1.4$, $R = 287$ J/(kg·K).

## 6.3 Leçon d'Olivieri 2023

> *"with respect to the travel times computed for a homogeneous model, the resulting travel times give much worse fit to the data."*

**Conclusion** : un modèle atmosphérique homogène (c=295 m/s constant) peut donner **de meilleurs résultats** qu'un modèle stratifié imparfait. Pour une implémentation prudente, commencer par le modèle homogène, puis raffiner avec ERA5 si données de qualité.

---

# CHAPITRE 7 — CHIFFRES DE VALIDATION ATTENDUS

## 7.1 Italie 5 mars 2022 (Olivieri 2023)

| Paramètre | Valeur publiée | Tolérance acceptable |
|---|---|---|
| Début visible | 91.22 ± 0.01 km | ± 1% |
| Fin visible | 31.5 ± 0.1 km | ± 1% |
| Vitesse entrée | 15.5 ± 0.1 km/s | ± 2% |
| Azimut trajectoire | 101° | ± 2° |
| Altitude Mach cone | 68 km | ± 3 km |
| Back-azimut array | 25° ± 1° | ± 3° |
| Angle incidence | 46° | ± 5° |
| Vitesse apparente sismique | 1200 m/s | ± 10% |
| Masse initiale | 12 ± 4 kg | ± 30% |

## 7.2 El-Hakimia 7 mai 2023 (Roubeche 2024)

| Paramètre | Valeur publiée | Tolérance acceptable |
|---|---|---|
| Heure fragmentation | 23:00:07 UTC | ± 1 s |
| Altitude fragmentation | 35 ± 0.6 km | ± 2 km |
| Énergie explosion | 0.178 ± 0.014 kt | ± 20% |
| Masse (min) | 0.598 ± 0.048 t | facteur 1.5 |
| Masse (max) | 14.946 ± 1.216 t | facteur 1.5 |
| Trajectoire | ESE-WNW | ± 10° |

## 7.3 Traspena 18 janvier 2021 (Andrade 2023)

| Paramètre | Valeur publiée | Tolérance acceptable |
|---|---|---|
| Durée visible | 4.84 s | ± 0.1 s |
| Altitude début | 75.10 km | ± 1% |
| Altitude fin | 15.75 km | ± 1% |
| Vitesse entrée | non fournie (cam) | — |
| Vitesse fin | 2.38 km/s | ± 5% |
| Angle entrée | 76.7° | ± 1° |
| Diamètre meteoroïde | 1.15 m | ± 10% |
| Masse meteoroïde | 2620 kg | ± 20% |

---

# CHAPITRE 8 — SYNTHÈSE OPÉRATIONNELLE

## 8.1 Pipeline sismique unifié

```
┌───────────────────────────────────────────────────────────┐
│  ÉTAPE 1 — ACQUISITION                                    │
│  Télécharger formes d'onde FDSN                           │
│  Fenêtre : ±1h autour de l'heure estimée                  │
│  Canaux : BHZ, BHE, BHN (broadband)                       │
└───────────────────────────────────────────────────────────┘
                             ↓
┌───────────────────────────────────────────────────────────┐
│  ÉTAPE 2 — PRÉ-TRAITEMENT                                 │
│  • Détrending                                             │
│  • Retrait réponse instrumentale                          │
│  • Filtrage passe-bande 1-20 Hz (signal direct)           │
│  • Filtrage passe-bande 0.5-4 Hz (ondes Rayleigh)         │
└───────────────────────────────────────────────────────────┘
                             ↓
┌───────────────────────────────────────────────────────────┐
│  ÉTAPE 3 — DÉTECTION SIGNATURE                            │
│  Vérifier les 4 critères (Olivieri) :                     │
│  1. Absence onde P claire                                 │
│  2. Durée < 5s                                            │
│  3. Cross-corrélation inter-stations > 0.7                │
│  4. Vitesse apparente 800-1500 m/s                        │
└───────────────────────────────────────────────────────────┘
                             ↓
┌───────────────────────────────────────────────────────────┐
│  ÉTAPE 4 — TRIANGULATION                                  │
│  Si 3+ stations : méthode isochrones (Roubeche)           │
│  Si 2 stations : intersection rayons + contrainte vent    │
│  Si 1 station : back-azimut + mode dégradé                │
└───────────────────────────────────────────────────────────┘
                             ↓
┌───────────────────────────────────────────────────────────┐
│  ÉTAPE 5 — ALTITUDE DE FRAGMENTATION                      │
│  Minimisation résidus temps d'arrivée (Olivieri)          │
│  Correction vent ERA5 (Roubeche ray tracing)              │
└───────────────────────────────────────────────────────────┘
                             ↓
┌───────────────────────────────────────────────────────────┐
│  ÉTAPE 6 — ESTIMATION ÉNERGIE/MASSE                       │
│  Relation période-yield (Brown/Edwards)                   │
│  OU système différentiel Olivieri si vitesse connue       │
└───────────────────────────────────────────────────────────┘
                             ↓
┌───────────────────────────────────────────────────────────┐
│  ÉTAPE 7 — INJECTION DFMC                                 │
│  Transmettre (lat, lon, alt, énergie, vitesse)            │
│  au moteur DFMC pour calcul strewn field                  │
└───────────────────────────────────────────────────────────┘
```

## 8.2 Matrice capacité/configuration

| Configuration | Triangulation | Altitude | Énergie | Précision GPS |
|---|---|---|---|---|
| 3+ stations < 500 km | ✅ Isochrones | ✅ Inversion | ✅ Multi-source | **5-15 km²** |
| 2 stations < 500 km | 🟡 Partielle | 🟡 Contrainte | 🟡 Estimée | 15-50 km² |
| 1 station < 500 km | 🟠 Back-azimut seul | 🟠 Hypothèse | 🟠 Approx. | 50-100 km² |
| 1 station > 500 km | 🔴 Incertain | 🔴 Indirect | 🟠 Possible | > 100 km² |

## 8.3 Seuils de détection minimaux

**Source : Brown et al. 2007 (cité Pilger 2021)**

- **Seuil théorique minimal** : $E_{min} = 6 \times 10^{-5}$ kt TNT ≈ 250 MJ
- **Seuil pratique Meteorite Scout AI** : 0.001 kt (pour marges de confiance)

**Application Tiflet 2026 (aubrite ~kg)** : énergie probable 10⁻⁴ à 10⁻³ kt → **à la limite de détectabilité**. Cas critique de test du seuil.

---

# CHAPITRE 9 — POINTS DE VIGILANCE

## 9.1 Limites méthodologiques assumées

1. **Sensibilité au modèle atmosphérique** : ERA5 imparfait en haute altitude. Toujours comparer résultats "modèle homogène" vs "modèle ERA5" et garder le meilleur résidu.

2. **Incertitude sur la vitesse d'entrée** : sans observation optique, $V_{entry}$ est mal contrainte → facteur ×25 d'incertitude sur la masse. Les témoignages visuels sont à collecter systématiquement.

3. **Pré-traitement crucial** : Andrade 2023 rappelle que le signal peut être invisible sur données brutes. Ne jamais conclure "rien détecté" avant détrending + filtrage passe-haut 3 Hz minimum.

4. **Faux positifs possibles** : quarry blasts, tonnerre, chutes d'avion peuvent produire des signatures similaires. Critère discriminant : **cohérence avec trajectoire linéaire** (bolide) vs **source ponctuelle** (explosion).

## 9.2 Cas limites à documenter en production

- Chute nocturne sans témoignage visuel → pas de contrainte $V_{entry}$
- Station unique avec bolide de faible énergie → détection à la limite
- Zone frontière atmosphérique avec turbulences élevées → correction vent imprécise
- Événement masqué par séisme local dans la même fenêtre temporelle

## 9.3 Extensions futures (non phase B1)

- Intégration des données infrasound IMS (via VDEC CTBTO)
- Machine learning pour discrimination automatique bolide/séisme (template matching)
- Relation période-yield révisée (Silber 2025)
- Accès réseau MO (36 stations marocaines) pour triangulation dense

---

# CHAPITRE 10 — RÉFÉRENCES BIBLIOGRAPHIQUES

## 10.1 Publications de référence (corpus B1)

1. **Olivieri M. et al.** (2023). *The optical, seismic, and infrasound signature of the March 5 2022, bolide over Central Italy.* Scientific Reports 13, 21135. DOI: 10.1038/s41598-023-48396-8

2. **Roubeche K. et al.** (2025). *The May 7, 2023, El-Hakimia, Algeria, Fireball: First Meteor Characterization Using Infrasound and Seismic Sensors.* Pure and Applied Geophysics. DOI: 10.1007/s00024-025-03730-1

3. **Andrade M. et al.** (2023). *The Traspena meteorite: heliocentric orbit, atmospheric trajectory, strewn field, and petrography of a new L5 ordinary chondrite.* MNRAS 518(3), 3850-3876. DOI: 10.1093/mnras/stac2911

## 10.2 Publications complémentaires citées

4. Brown P.G. et al. (2007). *Seuil de détection min 6×10⁻⁵ kt TNT pour infrasound.*

5. Edwards W.N., Eaton D.W., Brown P.G. (2008). *Seismic observations of meteors: Coupling theory and observations.* Rev. Geophys. DOI: 10.1029/2007RG000253

6. Gi N., Brown P.G. (2017). *Refinement of Bolide Characteristics from Infrasound measurements.* (78 bolides, 179 waveforms, équation 9 période-yield)

7. McFadden L., Brown P.G., Vida D., Spurný P. (2021). *Fireball characteristics derivable from acoustic data.* J. Atmos. Sol. Terr. Phys. 216, 105587. (Code BAM)

8. Silber E.A., Trigo-Rodríguez J.M. et al. (2025). *Multi-parameter constraints on empirical infrasound period-yield relations for bolides and implications for planetary defense.* Astronomical Journal. (Formules énergie les plus récentes)

9. Peña-Asensio E., Trigo-Rodríguez J.M. et al. (2023). *Identifying meteorite droppers among the population of bright 'sporadic' bolides imaged by the Spanish Meteor Network during the spring of 2022.* MNRAS 520(4), 5173-5182. (Pipeline Python 3D-FireTOC)

10. Anghel S. et al. (2021). *Energy signature of ton TNT-class impacts: analysis of the 2018 December 22 fireball over Western Pyrenees.* MNRAS 508(4), 5716-5733. (Cas Pyrénées — comparaison dynamique/photométrique/sismique/infrasound)

## 10.3 Outils logiciels référencés

- **ObsPy** (Beyreuther 2010, Krischer 2015) — Toolkit Python standard
- **3D-FireTOC** (Peña-Asensio 2021) — Pipeline Python SPMN
- **BAM (Bolide Acoustic Modeling)** (McFadden 2021) — Code UWO

---

# ANNEXE A — GLOSSAIRE

| Terme | Définition |
|---|---|
| **Back-azimut** | Angle entre le nord et la direction de la source, vu depuis la station |
| **Beamforming** | Technique de combinaison de signaux multi-capteurs pour extraire direction/vitesse |
| **Isochrones** | Courbes reliant les points ayant le même temps d'arrivée du front d'onde |
| **Mach cone** | Cône de choc généré par un objet supersonique, angle dépendant du rapport V/c_son |
| **N-wave / W-wave** | Forme caractéristique d'onde de choc acoustique (déplacement/vélocité) |
| **Onde Rayleigh** | Onde sismique de surface, particule en mouvement rétrograde elliptique |
| **Slowness** | Inverse de la vitesse, vecteur utilisé en beamforming |
| **Strewn field** | Zone géographique où tombent les fragments après fragmentation |
| **Ablation** | Perte de masse du meteoroide par vaporisation atmosphérique |
| **FDSN** | Federation of Digital Seismograph Networks, protocole standard accès données |
| **EIDA** | European Integrated Data Archive, fédération européenne FDSN |

---

# ANNEXE B — ÉTAT D'AVANCEMENT

| Chapitre | Source | Statut |
|---|---|---|
| Ch. 1 Détection | Olivieri 2023 + Andrade 2023 | ✅ Complet |
| Ch. 2 Triangulation | Olivieri 2023 + Roubeche 2024 + Andrade 2023 | ✅ Complet |
| Ch. 3 Couplage | Olivieri 2023 | ✅ Complet |
| Ch. 4 Énergie | Olivieri 2023 + Roubeche 2024 | ✅ Complet (partiel sur formule Brown) |
| Ch. 5 Altitude | Olivieri 2023 + Roubeche 2024 | ✅ Complet |
| Ch. 6 Atmosphère | Olivieri 2023 + Roubeche 2024 | ✅ Complet |
| Ch. 7 Validation | 3 publications | ✅ Complet |
| Ch. 8 Pipeline | Synthèse | ✅ Complet |
| Ch. 9 Vigilance | Synthèse | ✅ Complet |

**Points à approfondir en Phase B2 (développement)** :
- Extraction détaillée de la formule période-yield Gi & Brown 2017 (Eq. 9)
- Paramètres exacts du ray tracing Roubeche 2024
- Extraction complète du code BAM (McFadden 2021) via GitHub

---

# ANNEXE C — VALIDATION DU DOCUMENT

**Décisions à valider par Nabil** :

- [ ] Les 3 publications sélectionnées couvrent-elles suffisamment les besoins ?
- [ ] Le pipeline unifié (Ch. 8) correspond-il à la vision produit ?
- [ ] Les tolérances de validation (Ch. 7) sont-elles acceptables ?
- [ ] La matrice capacité/configuration (8.2) reflète-t-elle ta stratégie commerciale ?
- [ ] Les extensions futures identifiées sont-elles pertinentes ?

**Prochaines étapes après validation** :
1. Phase B2 — Implémentation Python du pipeline unifié
2. Phase B3 — Tests sur cas historiques (Tamdakht, Tissint)
3. Phase B4 — Test Tiflet 2026 en conditions opérationnelles
4. Phase C — Rédaction spec production définitive

---

**FIN DU DOCUMENT MAÎTRE PHASE B1 — v1.0**
