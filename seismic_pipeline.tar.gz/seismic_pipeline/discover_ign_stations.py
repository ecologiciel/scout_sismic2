"""discover_ign_stations.py — Découverte automatique des stations IGN Espagne.

Utilise le nouveau client FDSN "IGN" d'ObsPy 1.5.0 pour récupérer la liste
des stations actives du réseau ES (Spanish Digital Seismic Network) et
calcule leur distance aux 3 cas de test marocains (Tiflet, Tamdakht, Tissint).

Usage :
    python discover_ign_stations.py
"""
from __future__ import annotations

import logging
import math

from obspy import UTCDateTime
from obspy.clients.fdsn import Client

logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Cas de test marocains
CAS_TESTS = {
    "TIFLET":   (33.89, -6.31),
    "TAMDAKHT": (31.16, -7.02),
    "TISSINT":  (29.48, -7.61),
}


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Distance haversine entre 2 points (en km)."""
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def main() -> None:
    """Découvre les stations ES proches du Maroc."""
    logger.info("=" * 70)
    logger.info("DÉCOUVERTE STATIONS IGN Espagne (réseau ES)")
    logger.info("=" * 70)

    # Connexion au serveur IGN
    logger.info("Connexion au client FDSN 'IGN'...")
    try:
        client = Client("IGN")
    except Exception as exc:
        logger.error("Échec connexion client IGN : %s", exc)
        logger.info("Tentative URL directe...")
        client = Client("http://fdsnws.sismologia.ign.es")

    # Requête des stations ES actives aujourd'hui
    logger.info("Récupération inventaire réseau ES...")
    try:
        inv = client.get_stations(
            network="ES",
            level="station",
            starttime=UTCDateTime("2020-01-01"),
            endtime=UTCDateTime("2026-12-31"),
        )
    except Exception as exc:
        logger.error("Échec requête stations : %s", exc)
        return

    # Collecte toutes les stations
    stations = []
    for net in inv:
        for sta in net:
            stations.append({
                "code": f"{net.code}.{sta.code}",
                "lat": sta.latitude,
                "lon": sta.longitude,
                "elev": sta.elevation,
                "start": sta.start_date,
                "end": sta.end_date,
            })

    logger.info("Nombre de stations ES trouvées : %d", len(stations))

    # Calcul distances et tri par cas
    for cas_nom, (ev_lat, ev_lon) in CAS_TESTS.items():
        logger.info("")
        logger.info("─" * 70)
        logger.info("STATIONS ES PROCHES DE %s (%.3f°, %.3f°)", cas_nom, ev_lat, ev_lon)
        logger.info("─" * 70)

        stations_with_dist = []
        for sta in stations:
            dist = haversine_km(sta["lat"], sta["lon"], ev_lat, ev_lon)
            stations_with_dist.append((dist, sta))

        stations_with_dist.sort(key=lambda x: x[0])

        # Affichage top 15 stations les plus proches
        print(f"\n{'Code':<12} {'Dist (km)':<12} {'Lat':<10} {'Lon':<10} {'Elev':<8} {'Actif'}")
        print("─" * 70)
        for dist, sta in stations_with_dist[:15]:
            end_date = sta["end"] if sta["end"] else "ongoing"
            print(
                f"{sta['code']:<12} {dist:<12.1f} "
                f"{sta['lat']:<10.3f} {sta['lon']:<10.3f} "
                f"{sta['elev']:<8.0f} {end_date}"
            )

    logger.info("")
    logger.info("=" * 70)
    logger.info("DÉCOUVERTE TERMINÉE")
    logger.info("=" * 70)


if __name__ == "__main__":
    main()
