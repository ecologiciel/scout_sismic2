"""discover_ign_stations.py — Découverte des stations IGN Espagne (réseau ES).

Version robuste avec 4 stratégies en cascade :
  1. ObsPy Client "IGN" standard
  2. ObsPy Client avec service_mappings explicites (bypass bug découverte)
  3. Requête HTTP XML directe via urllib
  4. Requête HTTP format texte (fallback ultime)

Calcule les distances aux 3 cas marocains et affiche les stations pertinentes.
"""
from __future__ import annotations

import logging
import math
import urllib.request
from io import StringIO, BytesIO
from typing import Optional

from obspy import UTCDateTime, read_inventory
from obspy.clients.fdsn import Client

logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# URL base IGN Espagne
IGN_BASE_URL = "http://fdsnws.sismologia.ign.es"

# Cas de test marocains
CAS_TESTS = {
    "TIFLET":   (33.89, -6.31),
    "TAMDAKHT": (31.16, -7.02),
    "TISSINT":  (29.48, -7.61),
}


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Distance haversine entre 2 points (en km)."""
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def try_strategy_1_obspy_default() -> Optional[object]:
    """Stratégie 1 : Client('IGN') standard."""
    logger.info("→ Stratégie 1 : ObsPy Client('IGN')")
    try:
        client = Client("IGN", timeout=30)
        inv = client.get_stations(
            network="ES", level="station",
            starttime=UTCDateTime("2020-01-01"),
        )
        logger.info("  ✓ Stratégie 1 réussie")
        return inv
    except Exception as exc:
        logger.warning("  ✗ Stratégie 1 échouée : %s", str(exc)[:150])
        return None


def try_strategy_2_obspy_mappings() -> Optional[object]:
    """Stratégie 2 : Client avec service_mappings explicites."""
    logger.info("→ Stratégie 2 : ObsPy avec service_mappings explicites")
    try:
        service_mappings = {
            "station":     f"{IGN_BASE_URL}/fdsnws/station/1",
            "dataselect":  f"{IGN_BASE_URL}/fdsnws/dataselect/1",
        }
        client = Client(
            base_url=IGN_BASE_URL,
            service_mappings=service_mappings,
            timeout=30,
        )
        inv = client.get_stations(
            network="ES", level="station",
            starttime=UTCDateTime("2020-01-01"),
        )
        logger.info("  ✓ Stratégie 2 réussie")
        return inv
    except Exception as exc:
        logger.warning("  ✗ Stratégie 2 échouée : %s", str(exc)[:150])
        return None


def try_strategy_3_raw_http_xml() -> Optional[object]:
    """Stratégie 3 : HTTP direct XML."""
    logger.info("→ Stratégie 3 : Requête HTTP directe XML")
    url = (
        f"{IGN_BASE_URL}/fdsnws/station/1/query"
        "?network=ES"
        "&level=station"
        "&format=xml"
    )
    logger.info("  URL : %s", url)
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0 (MeteoriteScout/1.0)"},
        )
        with urllib.request.urlopen(req, timeout=60) as response:
            xml_data = response.read()
            logger.info("  ✓ Reçu %d octets XML", len(xml_data))
        inv = read_inventory(BytesIO(xml_data), format="STATIONXML")
        logger.info("  ✓ Stratégie 3 réussie")
        return inv
    except Exception as exc:
        logger.warning("  ✗ Stratégie 3 échouée : %s", str(exc)[:200])
        return None


def try_strategy_4_text_format() -> Optional[list]:
    """Stratégie 4 : Format texte pipe-separated."""
    logger.info("→ Stratégie 4 : HTTP direct format=text")
    url = (
        f"{IGN_BASE_URL}/fdsnws/station/1/query"
        "?network=ES"
        "&level=station"
        "&format=text"
    )
    logger.info("  URL : %s", url)
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0 (MeteoriteScout/1.0)"},
        )
        with urllib.request.urlopen(req, timeout=60) as response:
            text_data = response.read().decode("utf-8", errors="ignore")
            logger.info("  ✓ Reçu %d octets texte", len(text_data))

        # Parse pipe-separated
        stations = []
        for line in text_data.split("\n"):
            if line.startswith("#") or not line.strip():
                continue
            parts = line.split("|")
            if len(parts) >= 5:
                try:
                    stations.append({
                        "code": f"{parts[0].strip()}.{parts[1].strip()}",
                        "lat": float(parts[2]),
                        "lon": float(parts[3]),
                        "elev": float(parts[4]),
                        "start": parts[-2] if len(parts) >= 7 else "?",
                        "end": parts[-1] if len(parts) >= 7 else "",
                    })
                except (ValueError, IndexError):
                    continue

        logger.info("  ✓ Stratégie 4 réussie — %d stations parsées", len(stations))
        return stations
    except Exception as exc:
        logger.warning("  ✗ Stratégie 4 échouée : %s", str(exc)[:200])
        return None


def extract_stations_from_inventory(inv) -> list:
    """Convertit un Inventory ObsPy en liste de dicts."""
    stations = []
    for net in inv:
        for sta in net:
            stations.append({
                "code": f"{net.code}.{sta.code}",
                "lat": sta.latitude,
                "lon": sta.longitude,
                "elev": sta.elevation,
                "start": str(sta.start_date) if sta.start_date else "?",
                "end": str(sta.end_date) if sta.end_date else "",
            })
    return stations


def display_results(stations: list) -> None:
    """Affiche les stations proches de chaque cas marocain."""
    if not stations:
        logger.error("Aucune station trouvée")
        return

    logger.info("")
    logger.info("═" * 70)
    logger.info("TOTAL STATIONS ES RÉSEAU : %d", len(stations))
    logger.info("═" * 70)

    for cas_nom, (ev_lat, ev_lon) in CAS_TESTS.items():
        logger.info("")
        logger.info("─" * 70)
        logger.info("STATIONS ES PROCHES DE %s (%.3f°, %.3f°)", cas_nom, ev_lat, ev_lon)
        logger.info("─" * 70)

        stations_with_dist = []
        for sta in stations:
            dist = haversine_km(sta["lat"], sta["lon"], ev_lat, ev_lon)
            stations_with_dist.append((dist, sta))

        stations_with_dist.sort(key=lambda x: x[0])

        print(f"\n{'Code':<14} {'Dist(km)':<10} {'Lat':<10} {'Lon':<10} {'Elev':<8}")
        print("─" * 70)
        for dist, sta in stations_with_dist[:15]:
            print(
                f"{sta['code']:<14} {dist:<10.1f} "
                f"{sta['lat']:<10.3f} {sta['lon']:<10.3f} "
                f"{sta['elev']:<8.0f}"
            )


def main() -> None:
    """Point d'entrée avec fallback de stratégies."""
    logger.info("=" * 70)
    logger.info("DÉCOUVERTE STATIONS IGN Espagne (réseau ES)")
    logger.info("=" * 70)

    # Essayer 4 stratégies en cascade
    inv = try_strategy_1_obspy_default()
    if inv:
        display_results(extract_stations_from_inventory(inv))
        return

    inv = try_strategy_2_obspy_mappings()
    if inv:
        display_results(extract_stations_from_inventory(inv))
        return

    inv = try_strategy_3_raw_http_xml()
    if inv:
        display_results(extract_stations_from_inventory(inv))
        return

    stations = try_strategy_4_text_format()
    if stations:
        display_results(stations)
        return

    logger.error("")
    logger.error("=" * 70)
    logger.error("ÉCHEC : Aucune stratégie n'a contacté le serveur IGN")
    logger.error("=" * 70)
    logger.error("Causes possibles :")
    logger.error("  - Serveur IGN en maintenance")
    logger.error("  - URL périmée")
    logger.error("  - Blocage réseau")


if __name__ == "__main__":
    main()
